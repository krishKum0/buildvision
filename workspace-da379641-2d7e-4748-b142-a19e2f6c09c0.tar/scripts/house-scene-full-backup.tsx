"use client";

import { Suspense, useEffect, useMemo, useRef, useState, useCallback } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import {
  OrbitControls, ContactShadows, Grid, GizmoHelper, GizmoViewport, Sky,
  AdaptiveDpr, AdaptiveEvents, PerformanceMonitor,
} from "@react-three/drei";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import * as THREE from "three";
import type { FloorPlanResult, MaterialsConfig, RoomType } from "@/lib/types";

/* ---------------- Constants ---------------- */
const WALL_HEIGHT = 9.5;
const WALL_THICK = 0.6;
const SLAB_THICK = 0.45;
const DOOR_W = 3.6;
const DOOR_H = 7;
const WIN_H = 3.0;
const WIN_W = 3.2;
const WIN_SILL = 3.2;

const ROOM_COLORS_3D: Record<RoomType, string> = {
  master: "#d9b98a", bedroom: "#e0c79a", living: "#cdbfa0", dining: "#d8c8a0",
  kitchen: "#c79a6b", bath: "#bcd0d6", pooja: "#e6c46b", study: "#c2c8d4",
  guest: "#d0c0cc", balcony: "#bcd0a8", utility: "#b8b6ae", storage: "#a89e8e",
  staircase: "#9a948a", parking: "#a6a6a0", garden: "#7fa866", terrace: "#b8b0a0",
};

export type CameraPreset = "default" | "front" | "rear" | "left" | "right" | "top";

interface SceneProps {
  floorPlan: FloorPlanResult;
  materials: MaterialsConfig;
  activeFloor: number;
  showWalls: boolean;
  showRoof: boolean;
  showInterior: boolean;
  orbitAutoRotate: boolean;
  cameraPreset?: CameraPreset;
  wireframe?: boolean;
}

/* ---------------- Helpers ---------------- */
const safe = (n: number, fallback = 0.1) => (Number.isFinite(n) && n > 0.01 ? n : fallback);

function computeCamera(plotW: number, plotD: number, floors: number, preset: CameraPreset) {
  const totalH = floors * WALL_HEIGHT;
  const maxDim = Math.max(plotW, plotD);
  const dist = Math.max(maxDim * 1.4, totalH * 1.6, 55);
  const cx = 0, cy = totalH / 2, cz = 0;
  switch (preset) {
    case "front":  return { pos: [0, totalH * 0.55 + 6, dist * 1.05] as [number, number, number], target: [cx, cy, cz] as [number, number, number] };
    case "rear":   return { pos: [0, totalH * 0.55 + 6, -dist * 1.05] as [number, number, number], target: [cx, cy, cz] as [number, number, number] };
    case "left":   return { pos: [-dist * 1.05, totalH * 0.55 + 6, 0] as [number, number, number], target: [cx, cy, cz] as [number, number, number] };
    case "right":  return { pos: [dist * 1.05, totalH * 0.55 + 6, 0] as [number, number, number], target: [cx, cy, cz] as [number, number, number] };
    case "top":    return { pos: [0.001, dist * 1.25, 0.001] as [number, number, number], target: [cx, 0, cz] as [number, number, number] };
    default:       return { pos: [dist * 0.7, totalH + dist * 0.5, dist * 0.85] as [number, number, number], target: [cx, cy, cz] as [number, number, number] };
  }
}

/* ---------------- Scene root ---------------- */
export function HouseScene(props: SceneProps) {
  const { floorPlan, cameraPreset = "default" } = props;
  const cam = computeCamera(floorPlan.plotW, floorPlan.plotD, floorPlan.floors, cameraPreset);
  const [dpr, setDpr] = useState<[number, number]>([1, 1.8]);

  return (
    <Canvas
      shadows
      camera={{ position: cam.pos, fov: 38, near: 0.1, far: 2000 }}
      dpr={dpr}
      gl={{ antialias: true, powerPreference: "high-performance", alpha: false, stencil: false }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.05;
      }}
    >
      <color attach="background" args={["#dde3dc"]} />
      <fog attach="fog" args={["#dde3dc", 160, 420]} />

      <ambientLight intensity={0.6} />
      <hemisphereLight args={["#fff6e0", "#9a8460", 0.9]} />
      <directionalLight
        position={[60, 90, 35]}
        intensity={2.0}
        color="#fff2d0"
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-near={1}
        shadow-camera-far={400}
        shadow-camera-left={-130}
        shadow-camera-right={130}
        shadow-camera-top={130}
        shadow-camera-bottom={-130}
        shadow-bias={-0.0004}
        shadow-normalBias={0.04}
      />
      <directionalLight position={[-40, 30, -20]} intensity={0.35} color="#a8c0d8" />

      <Sky sunPosition={[60, 90, 35]} turbidity={6} rayleigh={1.5} />

      <Suspense fallback={null}>
        <House {...props} />
      </Suspense>

      <ContactShadows position={[0, 0.02, 0]} opacity={0.45} scale={320} blur={2.4} far={60} resolution={1024} />
      <Grid
        position={[0, 0.01, 0]}
        args={[400, 400]}
        cellSize={5}
        cellThickness={0.6}
        cellColor="#9a8460"
        sectionSize={20}
        sectionThickness={1}
        sectionColor="#b0703b"
        fadeDistance={280}
        infiniteGrid
      />

      <CameraRig preset={cameraPreset} plotW={floorPlan.plotW} plotD={floorPlan.plotD} floors={floorPlan.floors} />
      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.08}
        minDistance={15}
        maxDistance={280}
        maxPolarAngle={Math.PI / 2.05}
        autoRotate={props.orbitAutoRotate}
        autoRotateSpeed={0.7}
        target={cam.target}
      />

      <GizmoHelper alignment="bottom-right" margin={[70, 70]}>
        <GizmoViewport axisColors={["#b45309", "#3b7a3b", "#6c4a2f"]} labelColor="white" />
      </GizmoHelper>

      <PerformanceMonitor onChange={({ factor }) => setDpr([0.5, Math.min(2, factor * 1.5)])} />
      <AdaptiveDpr pixelated />
      <AdaptiveEvents />
    </Canvas>
  );
}

/* ---------------- Camera rig (animates camera on preset change) ---------------- */
function CameraRig({ preset, plotW, plotD, floors }: { preset: CameraPreset; plotW: number; plotD: number; floors: number }) {
  const { camera } = useThree();
  const controls = useThree((s) => s.controls) as OrbitControlsImpl | null;
  const target = useMemo(() => computeCamera(plotW, plotD, floors, preset), [plotW, plotD, floors, preset]);

  useEffect(() => {
    const startPos = camera.position.clone();
    const endPos = new THREE.Vector3(...target.pos);
    const startTarget = controls ? controls.target.clone() : new THREE.Vector3(0, floors * WALL_HEIGHT / 2, 0);
    const endTarget = new THREE.Vector3(...target.target);
    const duration = 700;
    const startTime = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - startTime) / duration);
      const e = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      camera.position.lerpVectors(startPos, endPos, e);
      if (controls) {
        controls.target.lerpVectors(startTarget, endTarget, e);
        controls.update();
      }
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, camera, controls, floors]);

  return null;
}

/* ---------------- House root ---------------- */
function House({ floorPlan, materials, activeFloor, showWalls, showRoof, showInterior, wireframe }: Omit<SceneProps, "orbitAutoRotate" | "cameraPreset"> & { wireframe?: boolean }) {
  const { plotW, plotD, setbacks } = floorPlan;
  const ox = -plotW / 2;
  const oz = -plotD / 2;
  const buildX = ox + setbacks.sides;
  const buildZ = oz + setbacks.front;
  const buildW = plotW - setbacks.sides * 2;
  const buildD = plotD - setbacks.front - setbacks.rear;
  const floors = floorPlan.floors;

  return (
    <group>
      {/* Outer grass border */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.05, 0]} receiveShadow>
        <planeGeometry args={[plotW * 1.6, plotD * 1.6]} />
        <meshStandardMaterial color="#6f835a" roughness={1} />
      </mesh>
      {/* Plot ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[plotW, plotD]} />
        <meshStandardMaterial color="#8a9a6a" roughness={1} />
      </mesh>
      {/* Buildable footprint slab */}
      <mesh position={[0, 0.03, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[buildW + 0.2, buildD + 0.2]} />
        <meshStandardMaterial color={materials.floorTile} roughness={0.92} />
      </mesh>

      <SetbackMarker x={buildX} z={buildZ} w={buildW} d={buildD} />

      {/* Floors */}
      {Array.from({ length: floors }).map((_, f) => {
        const yBase = f * WALL_HEIGHT;
        const visible = activeFloor === -1 || activeFloor === f;
        const dim = activeFloor !== -1 && activeFloor !== f;
        return (
          <group key={f} visible={visible}>
            <FloorLevel
              floor={f}
              yBase={yBase}
              rooms={floorPlan.rooms.filter((r) => r.floor === f)}
              buildX={buildX} buildZ={buildZ} buildW={buildW} buildD={buildD}
              materials={materials}
              showWalls={showWalls}
              showInterior={showInterior}
              isTop={f === floors - 1}
              showRoof={showRoof && f === floors - 1}
              dim={dim}
              wireframe={wireframe}
            />
          </group>
        );
      })}
    </group>
  );
}

/* ---------------- Setback boundary (all 4 sides, simple posts + thin border boxes) ---------------- */
function SetbackMarker({ x, z, w, d }: { x: number; z: number; w: number; d: number }) {
  const h = 0.5;
  const post = 0.18;
  const step = 5;
  const xs = Math.max(2, Math.round(w / step));
  const zs = Math.max(2, Math.round(d / step));
  const posts: { p: [number, number, number] }[] = [];
  for (let i = 0; i <= xs; i++) {
    const px = x + (i * w) / xs;
    posts.push({ p: [px, h / 2, z] });
    posts.push({ p: [px, h / 2, z + d] });
  }
  for (let j = 1; j < zs; j++) {
    const pz = z + (j * d) / zs;
    posts.push({ p: [x, h / 2, pz] });
    posts.push({ p: [x + w, h / 2, pz] });
  }
  return (
    <group>
      {posts.map((pp, i) => (
        <mesh key={i} position={pp.p} castShadow>
          <boxGeometry args={[post, h, post]} />
          <meshStandardMaterial color="#7a6a4a" roughness={0.95} />
        </mesh>
      ))}
      {/* Boundary border (4 thin boxes) */}
      <mesh position={[x + w / 2, 0.04, z]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[w, 0.15]} />
        <meshStandardMaterial color="#b0703b" transparent opacity={0.7} />
      </mesh>
      <mesh position={[x + w / 2, 0.04, z + d]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[w, 0.15]} />
        <meshStandardMaterial color="#b0703b" transparent opacity={0.7} />
      </mesh>
      <mesh position={[x, 0.04, z + d / 2]} rotation={[-Math.PI / 2, 0, Math.PI / 2]} receiveShadow>
        <planeGeometry args={[d, 0.15]} />
        <meshStandardMaterial color="#b0703b" transparent opacity={0.7} />
      </mesh>
      <mesh position={[x + w, 0.04, z + d / 2]} rotation={[-Math.PI / 2, 0, Math.PI / 2]} receiveShadow>
        <planeGeometry args={[d, 0.15]} />
        <meshStandardMaterial color="#b0703b" transparent opacity={0.7} />
      </mesh>
    </group>
  );
}

/* ---------------- Floor level ---------------- */
function FloorLevel({
  floor, yBase, rooms, buildX, buildZ, buildW, buildD, materials, showWalls, showInterior, isTop, showRoof, dim, wireframe,
}: {
  floor: number; yBase: number; rooms: any[]; buildX: number; buildZ: number;
  buildW: number; buildD: number; materials: MaterialsConfig;
  showWalls: boolean; showInterior: boolean; isTop: boolean; showRoof: boolean; dim?: boolean; wireframe?: boolean;
}) {
  const matRef = useRef<THREE.MeshStandardMaterial>(null);
  useFrame(() => {
    if (matRef.current) {
      const targetOpacity = dim ? 0.18 : 1;
      matRef.current.opacity = THREE.MathUtils.lerp(matRef.current.opacity, targetOpacity, 0.18);
      matRef.current.transparent = matRef.current.opacity < 0.98;
      matRef.current.depthWrite = matRef.current.opacity > 0.5;
    }
  });

  return (
    <group>
      {/* Floor slab */}
      <mesh position={[buildX + buildW / 2, yBase, buildZ + buildD / 2]} receiveShadow castShadow>
        <boxGeometry args={[buildW, SLAB_THICK, buildD]} />
        <meshStandardMaterial ref={matRef} color={materials.floorTile} roughness={0.85} wireframe={wireframe} />
      </mesh>

      {/* Exterior perimeter walls */}
      {showWalls && (
        <ExteriorWalls
          buildX={buildX} buildZ={buildZ} buildW={buildW} buildD={buildD}
          yBase={yBase} materials={materials} wireframe={wireframe}
        />
      )}

      {/* Rooms: floor tiles + interior walls + furniture */}
      {rooms.map((r) => (
        <Room3D
          key={r.id}
          room={r}
          yBase={yBase}
          materials={materials}
          showWalls={showWalls}
          showInterior={showInterior}
          buildX={buildX} buildZ={buildZ} buildW={buildW} buildD={buildD}
          wireframe={wireframe}
        />
      ))}

      {/* Roof on top floor */}
      {isTop && showRoof && (
        <Roof yTop={yBase + WALL_HEIGHT} buildX={buildX} buildZ={buildZ} buildW={buildW} buildD={buildD} color={materials.exteriorPaint} />
      )}
    </group>
  );
}

/* ---------------- Exterior perimeter walls ---------------- */
function ExteriorWalls({ buildX, buildZ, buildW, buildD, yBase, materials, wireframe }: {
  buildX: number; buildZ: number; buildW: number; buildD: number;
  yBase: number; materials: MaterialsConfig; wireframe?: boolean;
}) {
  const exteriorColor = materials.exteriorPaint;
  // South wall (front, road side) has the door
  return (
    <group>
      {/* North wall (back) - windows */}
      <WallWithWindows
        cx={buildX + buildW / 2} cz={buildZ} width={buildW} thickness={WALL_THICK}
        yBase={yBase} color={exteriorColor} windowsCount={Math.max(2, Math.floor(buildW / 8))}
        orientation="north" wireframe={wireframe}
      />
      {/* South wall (front, with door) */}
      <WallWithDoor
        cx={buildX + buildW / 2} cz={buildZ + buildD} width={buildW} thickness={WALL_THICK}
        yBase={yBase} color={exteriorColor}
        windowsPerSide={Math.max(1, Math.floor(buildW / 12))} wireframe={wireframe}
      />
      {/* East wall */}
      <WallWithWindows
        cx={buildX + buildW} cz={buildZ + buildD / 2} width={buildD} thickness={WALL_THICK}
        yBase={yBase} color={exteriorColor} windowsCount={Math.max(2, Math.floor(buildD / 8))}
        orientation="east" wireframe={wireframe}
      />
      {/* West wall */}
      <WallWithWindows
        cx={buildX} cz={buildZ + buildD / 2} width={buildD} thickness={WALL_THICK}
        yBase={yBase} color={exteriorColor} windowsCount={Math.max(2, Math.floor(buildD / 8))}
        orientation="west" wireframe={wireframe}
      />
    </group>
  );
}

/* ---------------- Wall with windows (perimeter) ----------------
 * Coordinate system: wall runs along its own axis at fixed cx/cz.
 * Local coordinate: wall runs from -width/2 to +width/2 relative to wall center.
 * offset = position of segment center along wall axis (relative to wall center)
 */
function WallWithWindows({ cx, cz, width, thickness, yBase, color, windowsCount, orientation, wireframe }: {
  cx: number; cz: number; width: number; thickness: number; yBase: number;
  color: string; windowsCount: number; orientation: "north" | "east" | "west"; wireframe?: boolean;
}) {
  const isXAxis = orientation === "north"; // north/south walls run along X
  const winSpacing = width / Math.max(1, windowsCount);
  const winW = Math.min(WIN_W, winSpacing * 0.55);

  // Compute pillar segments between windows
  const segs: { center: number; len: number }[] = [];
  let cursor = -width / 2;
  for (let i = 0; i < windowsCount; i++) {
    const winCenter = -width / 2 + winSpacing * (i + 0.5);
    const leftEnd = winCenter - winW / 2;
    const rightStart = winCenter + winW / 2;
    if (leftEnd > cursor + 0.01) {
      segs.push({ center: (cursor + leftEnd) / 2, len: leftEnd - cursor });
    }
    cursor = rightStart;
  }
  if (cursor < width / 2 - 0.01) {
    segs.push({ center: (cursor + width / 2) / 2, len: width / 2 - cursor });
  }

  // Sill band: below window, full wall width
  const sillY = yBase + WIN_SILL / 2;
  const sillH = WIN_SILL;
  // Lintel band: above window, full wall width
  const lintelY = yBase + WIN_SILL + WIN_H + (WALL_HEIGHT - WIN_SILL - WIN_H) / 2;
  const lintelH = WALL_HEIGHT - WIN_SILL - WIN_H;

  return (
    <group>
      {/* Sill band (full width, below windows) */}
      <WallBox cx={cx} cz={cz} offset={0} len={width} thickness={thickness}
        y={sillY} h={sillH} color={color} isXAxis={isXAxis} wireframe={wireframe} />
      {/* Lintel band (full width, above windows) */}
      <WallBox cx={cx} cz={cz} offset={0} len={width} thickness={thickness}
        y={lintelY} h={lintelH} color={color} isXAxis={isXAxis} wireframe={wireframe} />
      {/* Pillar segments at window-mid height */}
      {segs.map((s, i) => (
        <WallBox key={`p${i}`} cx={cx} cz={cz} offset={s.center} len={s.len} thickness={thickness}
          y={yBase + WIN_SILL + WIN_H / 2} h={WIN_H} color={color} isXAxis={isXAxis} wireframe={wireframe} />
      ))}
      {/* Windows */}
      {Array.from({ length: windowsCount }).map((_, i) => {
        const winCenter = -width / 2 + winSpacing * (i + 0.5);
        return (
          <WindowPane
            key={`w${i}`}
            cx={cx} cz={cz} offset={winCenter} len={winW} thickness={thickness + 0.05}
            y={yBase + WIN_SILL + WIN_H / 2} h={WIN_H} isXAxis={isXAxis}
          />
        );
      })}
    </group>
  );
}

/* ---------------- Wall with door (south side) ---------------- */
function WallWithDoor({ cx, cz, width, thickness, yBase, color, windowsPerSide, wireframe }: {
  cx: number; cz: number; width: number; thickness: number; yBase: number;
  color: string; windowsPerSide: number; wireframe?: boolean;
}) {
  const isXAxis = true; // south wall runs along X
  const doorW = Math.min(DOOR_W, width * 0.22);
  const doorLeft = -doorW / 2;
  const doorRight = doorW / 2;

  // Side wall regions: left of door (from -width/2 to doorLeft), right of door (from doorRight to width/2)
  const leftStart = -width / 2;
  const leftEnd = doorLeft;
  const rightStart = doorRight;
  const rightEnd = width / 2;
  const leftLen = leftEnd - leftStart; // positive
  const rightLen = rightEnd - rightStart; // positive
  const leftCenter = (leftStart + leftEnd) / 2;
  const rightCenter = (rightStart + rightEnd) / 2;

  // Windows on each side
  const winSpacingLeft = leftLen / Math.max(1, windowsPerSide);
  const winSpacingRight = rightLen / Math.max(1, windowsPerSide);
  const winWLeft = Math.min(WIN_W, winSpacingLeft * 0.55);
  const winWRight = Math.min(WIN_W, winSpacingRight * 0.55);

  // Pillars on left side
  const leftPillars: { center: number; len: number }[] = [];
  let lc = leftStart;
  for (let i = 0; i < windowsPerSide; i++) {
    const wc = leftStart + winSpacingLeft * (i + 0.5);
    const le = wc - winWLeft / 2;
    const rs = wc + winWLeft / 2;
    if (le > lc + 0.01) leftPillars.push({ center: (lc + le) / 2, len: le - lc });
    lc = rs;
  }
  if (lc < leftEnd - 0.01) leftPillars.push({ center: (lc + leftEnd) / 2, len: leftEnd - lc });

  // Pillars on right side
  const rightPillars: { center: number; len: number }[] = [];
  let rc = rightStart;
  for (let i = 0; i < windowsPerSide; i++) {
    const wc = rightStart + winSpacingRight * (i + 0.5);
    const le = wc - winWRight / 2;
    const rs = wc + winWRight / 2;
    if (le > rc + 0.01) rightPillars.push({ center: (rc + le) / 2, len: le - rc });
    rc = rs;
  }
  if (rc < rightEnd - 0.01) rightPillars.push({ center: (rc + rightEnd) / 2, len: rightEnd - rc });

  const sillY = yBase + WIN_SILL / 2;
  const lintelY = yBase + WIN_SILL + WIN_H + (WALL_HEIGHT - WIN_SILL - WIN_H) / 2;
  const lintelH = WALL_HEIGHT - WIN_SILL - WIN_H;

  return (
    <group>
      {/* Sill band on left side (below windows) */}
      {leftLen > 0.01 && (
        <WallBox cx={cx} cz={cz} offset={leftCenter} len={leftLen} thickness={thickness}
          y={sillY} h={WIN_SILL} color={color} isXAxis={isXAxis} wireframe={wireframe} />
      )}
      {/* Sill band on right side */}
      {rightLen > 0.01 && (
        <WallBox cx={cx} cz={cz} offset={rightCenter} len={rightLen} thickness={thickness}
          y={sillY} h={WIN_SILL} color={color} isXAxis={isXAxis} wireframe={wireframe} />
      )}
      {/* Lintel band on left side (above windows) */}
      {leftLen > 0.01 && (
        <WallBox cx={cx} cz={cz} offset={leftCenter} len={leftLen} thickness={thickness}
          y={lintelY} h={lintelH} color={color} isXAxis={isXAxis} wireframe={wireframe} />
      )}
      {/* Lintel band on right side */}
      {rightLen > 0.01 && (
        <WallBox cx={cx} cz={cz} offset={rightCenter} len={rightLen} thickness={thickness}
          y={lintelY} h={lintelH} color={color} isXAxis={isXAxis} wireframe={wireframe} />
      )}
      {/* Lintel above door (full door width + small overhang) */}
      <WallBox cx={cx} cz={cz} offset={0} len={doorW + 0.4} thickness={thickness}
        y={yBase + DOOR_H + (WALL_HEIGHT - DOOR_H) / 2} h={WALL_HEIGHT - DOOR_H}
        color={color} isXAxis={isXAxis} wireframe={wireframe} />
      {/* Pillar segments on left side at window height */}
      {leftPillars.map((s, i) => (
        <WallBox key={`lp${i}`} cx={cx} cz={cz} offset={s.center} len={s.len} thickness={thickness}
          y={yBase + WIN_SILL + WIN_H / 2} h={WIN_H} color={color} isXAxis={isXAxis} wireframe={wireframe} />
      ))}
      {/* Pillar segments on right side at window height */}
      {rightPillars.map((s, i) => (
        <WallBox key={`rp${i}`} cx={cx} cz={cz} offset={s.center} len={s.len} thickness={thickness}
          y={yBase + WIN_SILL + WIN_H / 2} h={WIN_H} color={color} isXAxis={isXAxis} wireframe={wireframe} />
      ))}
      {/* Windows on left side */}
      {Array.from({ length: windowsPerSide }).map((_, i) => {
        const wc = leftStart + winSpacingLeft * (i + 0.5);
        return (
          <WindowPane key={`lw${i}`} cx={cx} cz={cz} offset={wc} len={winWLeft}
            thickness={thickness + 0.05} y={yBase + WIN_SILL + WIN_H / 2} h={WIN_H} isXAxis={isXAxis} />
        );
      })}
      {/* Windows on right side */}
      {Array.from({ length: windowsPerSide }).map((_, i) => {
        const wc = rightStart + winSpacingRight * (i + 0.5);
        return (
          <WindowPane key={`rw${i}`} cx={cx} cz={cz} offset={wc} len={winWRight}
            thickness={thickness + 0.05} y={yBase + WIN_SILL + WIN_H / 2} h={WIN_H} isXAxis={isXAxis} />
        );
      })}
      {/* Door */}
      <DoorPanel cx={cx} cz={cz} offset={0} width={doorW} thickness={thickness + 0.08} y={yBase} h={DOOR_H} />
    </group>
  );
}

/* ---------------- A single wall box (oriented) ---------------- */
function WallBox({ cx, cz, offset, len, thickness, y, h, color, isXAxis, wireframe }: {
  cx: number; cz: number; offset: number; len: number; thickness: number;
  y: number; h: number; color: string; isXAxis: boolean; wireframe?: boolean;
}) {
  // Clamp to safe positive numbers — never produce NaN geometry
  const L = safe(len);
  const H = safe(h);
  const T = safe(thickness);
  if (len <= 0.01 || h <= 0.01) return null;
  const pos: [number, number, number] = isXAxis ? [cx + offset, y, cz] : [cx, y, cz + offset];
  const geom: [number, number, number] = isXAxis ? [L, H, T] : [T, H, L];
  return (
    <mesh position={pos} castShadow receiveShadow>
      <boxGeometry args={geom} />
      <meshStandardMaterial color={color} roughness={0.92} wireframe={wireframe} polygonOffset polygonOffsetFactor={1} polygonOffsetUnits={1} />
    </mesh>
  );
}

/* ---------------- Window pane with frame ---------------- */
function WindowPane({ cx, cz, offset, len, thickness, y, h, isXAxis }: {
  cx: number; cz: number; offset: number; len: number; thickness: number;
  y: number; h: number; isXAxis: boolean;
}) {
  const L = safe(len, 0.3);
  const H = safe(h, 0.3);
  const T = safe(thickness, 0.4);
  const pos: [number, number, number] = isXAxis ? [cx + offset, y, cz] : [cx, y, cz + offset];
  const frameGeom: [number, number, number] = isXAxis ? [L + 0.2, H + 0.2, T] : [T, H + 0.2, L + 0.2];
  const glassGeom: [number, number, number] = isXAxis ? [L, H, T] : [T, H, L];
  // Mullions (vertical dividers) - 2 panes per window
  const mullionGeom: [number, number, number] = isXAxis ? [0.08, H, T + 0.02] : [T + 0.02, H, 0.08];
  const mullionPos: [number, number, number] = isXAxis ? [0, 0, 0] : [0, 0, 0];
  return (
    <group position={pos}>
      {/* Outer frame */}
      <mesh castShadow>
        <boxGeometry args={frameGeom} />
        <meshStandardMaterial color="#f8f4ec" roughness={0.85} />
      </mesh>
      {/* Glass */}
      <mesh>
        <boxGeometry args={glassGeom} />
        <meshStandardMaterial color="#a8c8d8" metalness={0.2} roughness={0.1} transparent opacity={0.5} />
      </mesh>
      {/* Vertical mullion (center divider) */}
      <mesh position={mullionPos}>
        <boxGeometry args={mullionGeom} />
        <meshStandardMaterial color="#f8f4ec" roughness={0.85} />
      </mesh>
      {/* Horizontal rail (middle) */}
      <mesh>
        <boxGeometry args={isXAxis ? [L, 0.08, T + 0.02] : [T + 0.02, 0.08, L]} />
        <meshStandardMaterial color="#f8f4ec" roughness={0.85} />
      </mesh>
    </group>
  );
}

/* ---------------- Door panel with frame ---------------- */
function DoorPanel({ cx, cz, offset, width, thickness, y, h }: {
  cx: number; cz: number; offset: number; width: number; thickness: number; y: number; h: number;
}) {
  const W = safe(width, 0.5);
  const H = safe(h, 1);
  const T = safe(thickness, 0.4);
  const pos: [number, number, number] = [cx + offset, y + H / 2, cz];
  return (
    <group position={pos}>
      {/* Door frame */}
      <mesh castShadow>
        <boxGeometry args={[W + 0.4, H + 0.2, T]} />
        <meshStandardMaterial color="#5a4326" roughness={0.8} />
      </mesh>
      {/* Door panel */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[W - 0.1, H - 0.1, T - 0.05]} />
        <meshStandardMaterial color="#7a5a36" roughness={0.7} />
      </mesh>
      {/* Door handle */}
      <mesh position={[W / 2 - 0.4, -0.2, T / 2 + 0.04]}>
        <sphereGeometry args={[0.1, 12, 12]} />
        <meshStandardMaterial color="#d4a14a" metalness={0.7} roughness={0.3} />
      </mesh>
      {/* Step */}
      <mesh position={[0, -H / 2 + 0.05, T / 2 + 0.15]}>
        <boxGeometry args={[W + 0.6, 0.1, 0.3]} />
        <meshStandardMaterial color="#9a8460" roughness={0.9} />
      </mesh>
    </group>
  );
}

/* ---------------- Room 3D (interior walls + furniture) ---------------- */
function Room3D({ room, yBase, materials, showWalls, showInterior, buildX, buildZ, buildW, buildD, wireframe }: {
  room: any; yBase: number; materials: MaterialsConfig;
  showWalls: boolean; showInterior: boolean;
  buildX: number; buildZ: number; buildW: number; buildD: number; wireframe?: boolean;
}) {
  const cx = room.x + room.w / 2;
  const cz = room.z + room.d / 2;
  const floorColor = ROOM_COLORS_3D[room.type as RoomType] ?? materials.floorTile;

  const isOnPerimeter = useCallback((side: "north" | "south" | "east" | "west") => {
    const tol = 0.4;
    const north = Math.abs(room.z - buildZ) < tol;
    const south = Math.abs(room.z + room.d - (buildZ + buildD)) < tol;
    const west = Math.abs(room.x - buildX) < tol;
    const east = Math.abs(room.x + room.w - (buildX + buildW)) < tol;
    return { north, south, east, west }[side];
  }, [room, buildX, buildZ, buildW, buildD]);

  if (room.type === "parking" || room.type === "garden" || room.type === "terrace") {
    return (
      <group>
        <mesh position={[cx, yBase + SLAB_THICK / 2 + 0.05, cz]} receiveShadow>
          <boxGeometry args={[Math.max(0.1, room.w), 0.1, Math.max(0.1, room.d)]} />
          <meshStandardMaterial color={room.type === "garden" ? "#7fa866" : "#9a9690"} roughness={1} />
        </mesh>
        {room.type === "garden" &&
          Array.from({ length: Math.max(2, Math.round(room.w / 6)) }).map((_, i) => {
            const n = Math.max(2, Math.round(room.w / 6));
            return (
              <mesh key={i} position={[room.x + (i + 0.5) * (room.w / n), yBase + 0.6, room.z + room.d * 0.5]} castShadow>
                <sphereGeometry args={[0.7, 8, 8]} />
                <meshStandardMaterial color="#5a8a4a" roughness={1} />
              </mesh>
            );
          })}
        {room.type === "parking" && (
          <>
            <mesh position={[cx, yBase + 0.5, cz]} castShadow>
              <boxGeometry args={[2, 1.2, 4]} />
              <meshStandardMaterial color="#5a6066" metalness={0.4} roughness={0.4} />
            </mesh>
            <mesh position={[cx, yBase + 0.11, cz]} rotation={[-Math.PI / 2, 0, 0]}>
              <planeGeometry args={[0.2, Math.max(0.5, room.d - 1)]} />
              <meshStandardMaterial color="#f4e8c8" />
            </mesh>
          </>
        )}
      </group>
    );
  }

  return (
    <group>
      {/* Room floor tile */}
      {showInterior && (
        <mesh position={[cx, yBase + SLAB_THICK / 2 + 0.03, cz]} receiveShadow>
          <boxGeometry args={[Math.max(0.1, room.w - 0.2), 0.06, Math.max(0.1, room.d - 0.2)]} />
          <meshStandardMaterial color={floorColor} roughness={0.85} />
        </mesh>
      )}

      {/* Interior walls (only sides NOT on building perimeter) */}
      {showWalls && (
        <group>
          {!isOnPerimeter("north") && (
            <InteriorWall cx={cx} cz={cz} w={room.w} d={room.d} side="north" y={yBase + WALL_HEIGHT / 2} color={materials.walls} wireframe={wireframe} />
          )}
          {!isOnPerimeter("south") && (
            <InteriorWall cx={cx} cz={cz} w={room.w} d={room.d} side="south" y={yBase + WALL_HEIGHT / 2} color={materials.walls} wireframe={wireframe} />
          )}
          {!isOnPerimeter("east") && (
            <InteriorWall cx={cx} cz={cz} w={room.w} d={room.d} side="east" y={yBase + WALL_HEIGHT / 2} color={materials.walls} wireframe={wireframe} />
          )}
          {!isOnPerimeter("west") && (
            <InteriorWall cx={cx} cz={cz} w={room.w} d={room.d} side="west" y={yBase + WALL_HEIGHT / 2} color={materials.walls} wireframe={wireframe} />
          )}
        </group>
      )}

      {/* Furniture */}
      {showInterior && room.type === "master" && (
        <BedGroup x={cx} z={cz - room.d / 2 + 2.5} y={yBase + SLAB_THICK / 2} />
      )}
      {showInterior && room.type === "living" && (
        <SofaGroup x={cx} z={cz - room.d / 2 + 3} y={yBase + SLAB_THICK / 2} color={materials.furniture} />
      )}
      {showInterior && room.type === "kitchen" && (
        <KitchenCounter x={room.x + room.w - 1} z={room.z + 1} y={yBase + SLAB_THICK / 2} color={materials.kitchenCabinet} />
      )}
      {showInterior && room.type === "dining" && (
        <DiningTable x={cx} z={cz} y={yBase + SLAB_THICK / 2} />
      )}
      {showInterior && room.type === "staircase" && (
        <Staircase x={cx} z={cz} y={yBase + SLAB_THICK / 2} w={room.w} d={room.d} />
      )}
      {showInterior && room.type === "bath" && (
        <BathFixtures x={room.x + 1} z={room.z + 1} y={yBase + SLAB_THICK / 2} />
      )}
      {showInterior && room.type === "pooja" && (
        <PoojaUnit x={cx} z={cz - room.d / 2 + 1} y={yBase + SLAB_THICK / 2} />
      )}
    </group>
  );
}

/* ---------------- Interior wall (single box) ---------------- */
function InteriorWall({ cx, cz, w, d, side, y, color, wireframe }: {
  cx: number; cz: number; w: number; d: number; side: "north" | "south" | "east" | "west";
  y: number; color: string; wireframe?: boolean;
}) {
  const t = WALL_THICK;
  const W = safe(w);
  const D = safe(d);
  let geom: [number, number, number];
  let pos: [number, number, number];
  if (side === "north") { geom = [W, WALL_HEIGHT, t]; pos = [cx, y, cz - D / 2]; }
  else if (side === "south") { geom = [W, WALL_HEIGHT, t]; pos = [cx, y, cz + D / 2]; }
  else if (side === "east") { geom = [t, WALL_HEIGHT, D]; pos = [cx + W / 2, y, cz]; }
  else { geom = [t, WALL_HEIGHT, D]; pos = [cx - W / 2, y, cz]; }
  return (
    <mesh position={pos} castShadow receiveShadow>
      <boxGeometry args={geom} />
      <meshStandardMaterial color={color} roughness={0.92} wireframe={wireframe} polygonOffset polygonOffsetFactor={1} polygonOffsetUnits={1} />
    </mesh>
  );
}

/* ---------------- Roof ---------------- */
function Roof({ yTop, buildX, buildZ, buildW, buildD, color }: {
  yTop: number; buildX: number; buildZ: number; buildW: number; buildD: number; color: string;
}) {
  return (
    <group>
      {/* Main roof slab */}
      <mesh position={[buildX + buildW / 2, yTop + 0.35, buildZ + buildD / 2]} castShadow receiveShadow>
        <boxGeometry args={[buildW, 0.7, buildD]} />
        <meshStandardMaterial color={color} roughness={0.88} />
      </mesh>
      <Parapet x={buildX} z={buildZ} w={buildW} d={buildD} y={yTop + 1.05} />
      {/* Water tank */}
      <mesh position={[buildX + buildW - 3, yTop + 2.0, buildZ + 3]} castShadow>
        <cylinderGeometry args={[1.4, 1.4, 2.2, 24]} />
        <meshStandardMaterial color="#8aa0b0" roughness={0.7} />
      </mesh>
      <mesh position={[buildX + buildW - 3, yTop + 3.15, buildZ + 3]} castShadow>
        <cylinderGeometry args={[1.45, 1.45, 0.2, 24]} />
        <meshStandardMaterial color="#5a6770" roughness={0.6} />
      </mesh>
      {/* Solar panel */}
      <mesh position={[buildX + 4, yTop + 0.78, buildZ + buildD - 4]} rotation={[-Math.PI / 12, 0, 0]} castShadow>
        <boxGeometry args={[5, 0.15, 3]} />
        <meshStandardMaterial color="#1a2a3a" metalness={0.5} roughness={0.3} />
      </mesh>
    </group>
  );
}

function Parapet({ x, z, w, d, y }: { x: number; z: number; w: number; d: number; y: number }) {
  const t = 0.3;
  const h = 1.0;
  return (
    <group>
      <mesh position={[x + w / 2, y, z]} castShadow>
        <boxGeometry args={[w, h, t]} />
        <meshStandardMaterial color="#d8cdb6" roughness={0.9} />
      </mesh>
      <mesh position={[x + w / 2, y, z + d]} castShadow>
        <boxGeometry args={[w, h, t]} />
        <meshStandardMaterial color="#d8cdb6" roughness={0.9} />
      </mesh>
      <mesh position={[x, y, z + d / 2]} castShadow>
        <boxGeometry args={[t, h, d]} />
        <meshStandardMaterial color="#d8cdb6" roughness={0.9} />
      </mesh>
      <mesh position={[x + w, y, z + d / 2]} castShadow>
        <boxGeometry args={[t, h, d]} />
        <meshStandardMaterial color="#d8cdb6" roughness={0.9} />
      </mesh>
    </group>
  );
}

/* ---------------- Furniture ---------------- */
function BedGroup({ x, z, y }: { x: number; z: number; y: number }) {
  return (
    <group position={[x, y, z]}>
      <mesh position={[0, 0.6, 0]} castShadow receiveShadow>
        <boxGeometry args={[4.5, 0.6, 6]} />
        <meshStandardMaterial color="#b9a986" roughness={0.9} />
      </mesh>
      <mesh position={[0, 1.0, -2]} castShadow>
        <boxGeometry args={[4.5, 0.8, 0.6]} />
        <meshStandardMaterial color="#9a8560" roughness={0.9} />
      </mesh>
      <mesh position={[-1.2, 1.05, -1.4]} castShadow>
        <boxGeometry args={[1.6, 0.25, 1]} />
        <meshStandardMaterial color="#f4ecd8" roughness={0.9} />
      </mesh>
      <mesh position={[1.2, 1.05, -1.4]} castShadow>
        <boxGeometry args={[1.6, 0.25, 1]} />
        <meshStandardMaterial color="#f4ecd8" roughness={0.9} />
      </mesh>
      <mesh position={[-2.5, 0.9, -2.2]} castShadow>
        <boxGeometry args={[1, 0.8, 1]} />
        <meshStandardMaterial color="#8a7a5a" />
      </mesh>
      <mesh position={[2.5, 0.9, -2.2]} castShadow>
        <boxGeometry args={[1, 0.8, 1]} />
        <meshStandardMaterial color="#8a7a5a" />
      </mesh>
    </group>
  );
}

function SofaGroup({ x, z, y, color }: { x: number; z: number; y: number; color: string }) {
  return (
    <group position={[x, y, z]}>
      <mesh position={[0, 0.5, 0]} castShadow receiveShadow>
        <boxGeometry args={[6, 0.8, 2.2]} />
        <meshStandardMaterial color={color} roughness={0.95} />
      </mesh>
      <mesh position={[0, 1.1, -1]} castShadow>
        <boxGeometry args={[6, 1.2, 0.5]} />
        <meshStandardMaterial color={color} roughness={0.95} />
      </mesh>
      <mesh position={[-2, 1.0, 0]} castShadow>
        <boxGeometry args={[1.5, 0.3, 1.8]} />
        <meshStandardMaterial color={color} roughness={0.95} />
      </mesh>
      <mesh position={[0, 1.0, 0]} castShadow>
        <boxGeometry args={[1.5, 0.3, 1.8]} />
        <meshStandardMaterial color={color} roughness={0.95} />
      </mesh>
      <mesh position={[2, 1.0, 0]} castShadow>
        <boxGeometry args={[1.5, 0.3, 1.8]} />
        <meshStandardMaterial color={color} roughness={0.95} />
      </mesh>
      <mesh position={[0, 0.4, 2.5]} castShadow>
        <boxGeometry args={[2.5, 0.5, 1.2]} />
        <meshStandardMaterial color="#6e5236" roughness={0.85} />
      </mesh>
    </group>
  );
}

function KitchenCounter({ x, z, y, color }: { x: number; z: number; y: number; color: string }) {
  return (
    <group position={[x, y, z]}>
      <mesh position={[0, 1.0, 0]} castShadow receiveShadow>
        <boxGeometry args={[1, 2, 6]} />
        <meshStandardMaterial color={color} roughness={0.85} />
      </mesh>
      <mesh position={[-3, 1.0, 0]} castShadow>
        <boxGeometry args={[5, 2, 1]} />
        <meshStandardMaterial color={color} roughness={0.85} />
      </mesh>
      <mesh position={[0, 2.05, 0]} castShadow>
        <boxGeometry args={[1.2, 0.1, 6.2]} />
        <meshStandardMaterial color="#3a332c" roughness={0.4} metalness={0.2} />
      </mesh>
      <mesh position={[-3, 2.05, 0]} castShadow>
        <boxGeometry args={[5.2, 0.1, 1.2]} />
        <meshStandardMaterial color="#3a332c" roughness={0.4} metalness={0.2} />
      </mesh>
      <mesh position={[0, 2.12, -1.5]}>
        <boxGeometry args={[0.7, 0.05, 1]} />
        <meshStandardMaterial color="#9aa3ab" metalness={0.7} roughness={0.3} />
      </mesh>
    </group>
  );
}

function DiningTable({ x, z, y }: { x: number; z: number; y: number }) {
  return (
    <group position={[x, y, z]}>
      <mesh position={[0, 1.0, 0]} castShadow receiveShadow>
        <boxGeometry args={[4, 0.15, 2]} />
        <meshStandardMaterial color="#6e5236" roughness={0.85} />
      </mesh>
      {[[-1.8, -0.9], [1.8, -0.9], [-1.8, 0.9], [1.8, 0.9]].map(([lx, lz], i) => (
        <mesh key={i} position={[lx, 0.5, lz]} castShadow>
          <boxGeometry args={[0.15, 1, 0.15]} />
          <meshStandardMaterial color="#5a4326" />
        </mesh>
      ))}
      {[[-1.5, -1.5], [1.5, -1.5], [-1.5, 1.5], [1.5, 1.5]].map(([lx, lz], i) => (
        <group key={i} position={[lx, 0, lz]}>
          <mesh position={[0, 0.5, 0]} castShadow>
            <boxGeometry args={[0.7, 0.1, 0.7]} />
            <meshStandardMaterial color="#8a7a5a" />
          </mesh>
          <mesh position={[0, 0.95, -0.3]} castShadow>
            <boxGeometry args={[0.7, 0.9, 0.1]} />
            <meshStandardMaterial color="#8a7a5a" />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function Staircase({ x, z, y, w, d }: { x: number; z: number; y: number; w: number; d: number }) {
  const steps = 10;
  const stepH = WALL_HEIGHT / steps;
  const stepD = d / steps;
  return (
    <group position={[x, y, z]}>
      {Array.from({ length: steps }).map((_, i) => (
        <mesh key={i} position={[0, stepH * (i + 0.5), -d / 2 + stepD * (i + 0.5)]} castShadow receiveShadow>
          <boxGeometry args={[Math.max(0.5, w - 0.4), stepH, stepD + 0.05]} />
          <meshStandardMaterial color="#9a8460" roughness={0.9} />
        </mesh>
      ))}
    </group>
  );
}

function BathFixtures({ x, z, y }: { x: number; z: number; y: number }) {
  return (
    <group position={[x, y, z]}>
      <mesh position={[1.5, 0.5, 1]} castShadow receiveShadow>
        <boxGeometry args={[2.5, 1, 1.4]} />
        <meshStandardMaterial color="#f0ece4" roughness={0.4} />
      </mesh>
      <mesh position={[0, 0.9, 0]} castShadow>
        <cylinderGeometry args={[0.5, 0.4, 0.2, 16]} />
        <meshStandardMaterial color="#f0ece4" roughness={0.4} />
      </mesh>
      <mesh position={[0, 0.4, 0]} castShadow>
        <boxGeometry args={[0.6, 0.8, 0.5]} />
        <meshStandardMaterial color="#9a9690" />
      </mesh>
      <mesh position={[3, 0.4, 0.5]} castShadow>
        <boxGeometry args={[0.6, 0.8, 0.9]} />
        <meshStandardMaterial color="#f8f8f4" roughness={0.5} />
      </mesh>
    </group>
  );
}

function PoojaUnit({ x, z, y }: { x: number; z: number; y: number }) {
  return (
    <group position={[x, y, z]}>
      <mesh position={[0, 1.5, 0]} castShadow>
        <boxGeometry args={[3, 3, 0.6]} />
        <meshStandardMaterial color="#8a5a2b" roughness={0.8} />
      </mesh>
      <mesh position={[0, 1.5, 0.35]}>
        <boxGeometry args={[2.6, 2.6, 0.05]} />
        <meshStandardMaterial color="#e6c46b" metalness={0.5} roughness={0.4} emissive="#9a7822" emissiveIntensity={0.3} />
      </mesh>
    </group>
  );
}
