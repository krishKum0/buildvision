"use client";

import { Canvas } from "@react-three/fiber";

export function HouseSceneTest() {
  return (
    <Canvas
      shadows
      camera={{ position: [10, 8, 12], fov: 45 }}
      dpr={[1, 1.8]}
    >
      <color attach="background" args={["#dde3dc"]} />
      <ambientLight intensity={0.6} />
      <directionalLight position={[5, 10, 5]} intensity={1.2} castShadow />
      <mesh position={[0, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[4, 4, 4]} />
        <meshStandardMaterial color="#b45309" />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]} receiveShadow>
        <planeGeometry args={[30, 30]} />
        <meshStandardMaterial color="#8a9a6a" />
      </mesh>
    </Canvas>
  );
}
