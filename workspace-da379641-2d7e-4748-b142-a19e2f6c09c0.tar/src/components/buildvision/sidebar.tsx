"use client";

import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard, Ruler, Sparkles, Map, Box, Compass, Palette,
  Layers, FileStack, Calculator, History, Download, LogOut, Plus,
} from "lucide-react";
import type { ViewKey } from "@/lib/types";

const NAV: { group: string; items: { key: ViewKey; label: string; icon: any }[] }[] = [
  { group: "Workspace", items: [
    { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { key: "history", label: "Projects & History", icon: History },
  ]},
  { group: "Design", items: [
    { key: "plot", label: "Plot Input", icon: Ruler },
    { key: "design", label: "AI Generator", icon: Sparkles },
    { key: "floorplan", label: "2D Floor Plan", icon: Map },
    { key: "viewer3d", label: "3D Viewer", icon: Box },
  ]},
  { group: "Customise", items: [
    { key: "vastu", label: "Vastu Planning", icon: Compass },
    { key: "materials", label: "Materials & Colour", icon: Palette },
  ]},
  { group: "Engineering", items: [
    { key: "soil", label: "Soil & Foundation", icon: Layers },
    { key: "structure", label: "Structural Plan", icon: FileStack },
    { key: "cost", label: "Cost Estimate", icon: Calculator },
    { key: "exports", label: "Export & Share", icon: Download },
  ]},
];

export function NavList({ onNavigate }: { onNavigate?: () => void }) {
  const view = useAppStore((s) => s.view);
  const setView = useAppStore((s) => s.setView);
  const newProject = useAppStore((s) => s.newProject);
  const project = useAppStore((s) => s.project);
  const floorPlan = useAppStore((s) => s.floorPlan);

  // Navigation is unlocked as soon as a floor plan exists — not only after a
  // project is saved to the database. This lets users iterate in 3D / Vastu /
  // Materials / Engineering views without first having to save.
  const unlocked = !!project || !!floorPlan;

  return (
    <div className="flex flex-col h-full">
      <div className="p-3">
        <Button className="w-full justify-start gap-2" onClick={() => { newProject(); onNavigate?.(); }}>
          <Plus className="w-4 h-4" /> New Project
        </Button>
      </div>
      <nav className="flex-1 overflow-y-auto bv-scroll px-3 pb-4 space-y-5">
        {NAV.map((section) => (
          <div key={section.group} className="space-y-1">
            <p className="px-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">
              {section.group}
            </p>
            {section.items.map((item) => {
              const Icon = item.icon;
              const active = view === item.key;
              const disabled = !["plot", "dashboard", "history"].includes(item.key) && !unlocked;
              return (
                <button
                  key={item.key}
                  onClick={() => { if (!disabled) { setView(item.key); onNavigate?.(); } }}
                  className={cn(
                    "w-full flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm transition-colors text-left",
                    active
                      ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                      : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
                    disabled && "opacity-50 cursor-not-allowed"
                  )}
                  title={disabled ? "Start a New Project or generate a design first" : item.label}
                >
                  <Icon className={cn("w-4 h-4 shrink-0", active && "text-primary")} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>
        ))}
      </nav>
    </div>
  );
}

export function Sidebar() {
  const user = useAppStore((s) => s.user);
  const setUser = useAppStore((s) => s.setUser);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
    useAppStore.getState().resetSession();
  }

  return (
    <aside className="hidden md:flex flex-col w-64 shrink-0 border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
      <div className="p-5 border-b border-sidebar-border">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-primary text-primary-foreground grid place-items-center shadow">
            <Compass className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <p className="font-semibold text-sm leading-none tracking-tight">BuildVision 360°</p>
            <p className="text-[10px] text-muted-foreground mt-1">AI Architectural Studio</p>
          </div>
        </div>
      </div>

      <NavList />

      <UserBar onLogout={logout} name={user?.name} role={user?.role} />
    </aside>
  );
}

export function UserBar({ name, role, onLogout, onClose }: { name?: string; role?: string; onLogout: () => void; onClose?: () => void }) {
  return (
    <div className="p-3 border-t border-sidebar-border">
      <div className="flex items-center gap-2.5 px-1.5 py-1.5 rounded-md">
        <div className="w-8 h-8 rounded-full bg-primary/15 text-primary grid place-items-center font-semibold text-xs">
          {name?.[0]?.toUpperCase() ?? "U"}
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium truncate leading-none">{name}</p>
          <p className="text-[10px] text-muted-foreground mt-0.5 capitalize">{role}</p>
        </div>
        {onClose && (
          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={onClose}>✕</Button>
        )}
        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={onLogout} title="Sign out">
          <LogOut className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
