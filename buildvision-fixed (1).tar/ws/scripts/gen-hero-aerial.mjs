// gen-hero-aerial.mjs
// Retry script for hero-aerial.jpg — the API rejected 1440x720 (720 is not a
// multiple of 32). 1344x768 is a valid landscape size (both 1344 and 768 are
// multiples of 32, total pixels < 2^22) and is in the SDK's documented list.

import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const OUT_DIR = path.join(path.dirname(new URL(import.meta.url).pathname), '..', 'public', 'concepts');
const MAX_RETRIES = 3;
const ITEM = {
  name: 'hero-aerial.jpg',
  size: '1344x768',
  prompt:
    'Aerial top-down drone view of a residential plot with a modern house, garden, parking, compound wall, surrounding neighborhood, architectural site plan photography, high quality, detailed',
};

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });
  const zai = await ZAI.create();
  let lastErr = null;
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const response = await zai.images.generations.create({
        prompt: ITEM.prompt,
        size: ITEM.size,
      });
      if (
        !response ||
        !response.data ||
        !response.data[0] ||
        !response.data[0].base64
      ) {
        throw new Error('Invalid response: missing data[0].base64');
      }
      const rawBuffer = Buffer.from(response.data[0].base64, 'base64');
      const outPath = path.join(OUT_DIR, ITEM.name);
      const jpegBuffer = await sharp(rawBuffer)
        .flatten({ background: '#ffffff' })
        .jpeg({ quality: 85, mozjpeg: true })
        .toBuffer();
      fs.writeFileSync(outPath, jpegBuffer);
      const stat = fs.statSync(outPath);
      console.log(
        `OK  ${ITEM.name}  ${stat.size.toLocaleString()} bytes  (attempt ${attempt})`
      );
      return;
    } catch (err) {
      lastErr = err;
      console.error(`attempt ${attempt}/${MAX_RETRIES} failed: ${err.message}`);
      if (attempt < MAX_RETRIES) await sleep(1500 * attempt);
    }
  }
  console.error(`FAIL ${ITEM.name} -> ${lastErr ? lastErr.message : 'unknown'}`);
  process.exit(2);
}

main().catch((e) => {
  console.error('Fatal:', e);
  process.exit(1);
});
