// gen-images.mjs
// Task ID 5 — AI BuildVision 360°
// Generates architectural concept images via z-ai-web-dev-sdk and saves them
// (converted to JPEG via sharp) into public/concepts/.
//
// Run: bun run scripts/gen-images.mjs   (or: node scripts/gen-images.mjs)

import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const OUT_DIR = path.join(path.dirname(new URL(import.meta.url).pathname), '..', 'public', 'concepts');
const MAX_RETRIES = 3;

const IMAGES = [
  {
    name: 'modern-villa.jpg',
    size: '1024x1024',
    prompt:
      'Modern minimalist two-story residential villa exterior, terracotta and warm white walls, large glass windows, flat roof with timber cladding, landscaped garden, golden hour architectural photography, clean lines, high quality, detailed',
  },
  {
    name: 'traditional-house.jpg',
    size: '1024x1024',
    prompt:
      'Traditional Indian independent house exterior with courtyard, sloped tiled roof, warm sandstone walls, arched windows, lush garden, daylight architectural photography, high quality, detailed',
  },
  {
    name: 'contemporary-glass.jpg',
    size: '1024x1024',
    prompt:
      'Contemporary luxury villa with floor-to-ceiling glass, natural stone and charcoal cladding, cantilevered upper floor, infinity pool, modern architecture dusk photography, high quality, detailed',
  },
  {
    name: 'elevation-blueprint.jpg',
    size: '1024x1024',
    prompt:
      'Architectural elevation drawing of a modern house, clean technical blueprint style, white background with terracotta line work, dimensioned, professional CAD aesthetic, high quality, detailed',
  },
  {
    name: 'interior-living.jpg',
    size: '1024x1024',
    prompt:
      'Warm modern interior living room, oak wood flooring, cream walls, large window with natural light, minimalist furniture, indoor plant, architectural interior photography, high quality, detailed',
  },
  {
    // NOTE: 1440x720 is rejected by the API (720 is not a multiple of 32).
    // 1344x768 is the valid landscape size (both dims are multiples of 32).
    name: 'hero-aerial.jpg',
    size: '1344x768',
    prompt:
      'Aerial top-down drone view of a residential plot with a modern house, garden, parking, compound wall, surrounding neighborhood, architectural site plan photography, high quality, detailed',
  },
];

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function generateOne(zai, item) {
  let lastErr = null;
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const response = await zai.images.generations.create({
        prompt: item.prompt,
        size: item.size,
      });

      if (
        !response ||
        !response.data ||
        !Array.isArray(response.data) ||
        response.data.length === 0 ||
        !response.data[0].base64
      ) {
        throw new Error('Invalid response: missing data[0].base64');
      }

      const rawBuffer = Buffer.from(response.data[0].base64, 'base64');
      const outPath = path.join(OUT_DIR, item.name);

      // Convert to JPEG (quality 85) — works whether source bytes are PNG or JPEG.
      const jpegBuffer = await sharp(rawBuffer)
        .flatten({ background: '#ffffff' })
        .jpeg({ quality: 85, mozjpeg: true })
        .toBuffer();
      fs.writeFileSync(outPath, jpegBuffer);

      const stat = fs.statSync(outPath);
      return {
        success: true,
        name: item.name,
        path: outPath,
        size: item.size,
        bytes: stat.size,
        attempts: attempt,
      };
    } catch (err) {
      lastErr = err;
      console.error(
        `  [${item.name}] attempt ${attempt}/${MAX_RETRIES} failed: ${err.message}`
      );
      if (attempt < MAX_RETRIES) {
        await sleep(1500 * attempt); // light exponential backoff
      }
    }
  }
  return {
    success: false,
    name: item.name,
    size: item.size,
    error: lastErr ? lastErr.message : 'unknown error',
  };
}

async function main() {
  if (!fs.existsSync(OUT_DIR)) {
    fs.mkdirSync(OUT_DIR, { recursive: true });
  }

  console.log('Initializing z-ai-web-dev-sdk ...');
  const zai = await ZAI.create();
  console.log('SDK ready. Generating 6 architectural concept images.\n');

  const results = [];
  for (const item of IMAGES) {
    console.log(`Generating: ${item.name} (${item.size}) ...`);
    const res = await generateOne(zai, item);
    if (res.success) {
      console.log(
        `  OK  ${res.name}  ${res.bytes.toLocaleString()} bytes  (attempts=${res.attempts})`
      );
    } else {
      console.log(`  FAIL ${res.name}  error: ${res.error}`);
    }
    results.push(res);
  }

  console.log('\n=== SUMMARY ===');
  const ok = results.filter((r) => r.success);
  const fail = results.filter((r) => !r.success);
  for (const r of ok) {
    console.log(`OK   ${r.path}  ${r.bytes} bytes`);
  }
  for (const r of fail) {
    console.log(`FAIL ${r.name}  -> ${r.error}`);
  }
  console.log(
    `\nTotal: ${ok.length}/${results.length} succeeded, ${fail.length} failed.`
  );

  // Write a small JSON report next to the script for traceability.
  const reportPath = path.join(OUT_DIR, 'gen-report.json');
  fs.writeFileSync(
    reportPath,
    JSON.stringify(
      {
        generatedAt: new Date().toISOString(),
        total: results.length,
        succeeded: ok.length,
        failed: fail.length,
        items: results.map((r) =>
          r.success
            ? { name: r.name, size: r.size, path: r.path, bytes: r.bytes, attempts: r.attempts, ok: true }
            : { name: r.name, size: r.size, error: r.error, ok: false }
        ),
      },
      null,
      2
    )
  );
  console.log(`Report written: ${reportPath}`);
}

main().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
