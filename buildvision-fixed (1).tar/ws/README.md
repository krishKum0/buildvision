# AI BuildVision 360°

Next.js 16 + Prisma (SQLite) + Three.js app.

## Run locally
```bash
cp .env.example .env     # then edit AUTH_SECRET
npm install              # (or bun install) — also runs `prisma generate`
npm run db:push          # creates/updates the SQLite DB at db/custom.db
npm run dev              # http://localhost:3000
```
Click **Continue with demo account** on the login screen to try it.

## Notes
- AI concept text uses `z-ai-web-dev-sdk`. If the SDK has no credentials/config, the app automatically falls back to built-in rule-based descriptions, so everything still works.
- Production: `npm run build && npm start`.
