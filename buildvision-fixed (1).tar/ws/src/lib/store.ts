// AI BuildVision 360° — client state store (Zustand)

import { create } from "zustand";
import type {
  PlotConfig,
  DesignConfig,
  FloorPlanResult,
  VastuConfig,
  MaterialsConfig,
  SoilReport,
  StructureConfig,
  Project,
  User,
  ViewKey,
  RoomSpec,
} from "./types";
import {
  defaultRoomSpecs,
  generateFloorPlan,
  generateStructure,
  computePlotArea,
  computeBuildableArea,
} from "./geometry";

export interface MaterialPreset {
  id: string;
  label: string;
  swatch: string[];
  materials: MaterialsConfig;
}

export const MATERIAL_PRESETS: MaterialPreset[] = [
  {
    id: "warm-wood",
    label: "White & Warm Wood",
    swatch: ["#F4EDE2", "#C9A063", "#8A5A2B", "#3E2C1A"],
    materials: {
      walls: "#F4EDE2", ceiling: "#FBF7F0", floorTile: "#D9C7A8", bedroomFloor: "#A9763F",
      kitchenCabinet: "#8A5A2B", bathroomTile: "#CBB58E", doorFinish: "#6E4418",
      exteriorPaint: "#E8DCC6", furniture: "#B07D45", lighting: "warm",
    },
  },
  {
    id: "cream-beige",
    label: "Cream & Beige",
    swatch: ["#F6EFE2", "#E3CFAC", "#C9A874", "#7C6A4E"],
    materials: {
      walls: "#F6EFE2", ceiling: "#FFFDF6", floorTile: "#E3CFAC", bedroomFloor: "#C9A874",
      kitchenCabinet: "#B89A66", bathroomTile: "#D8C49A", doorFinish: "#7C6A4E",
      exteriorPaint: "#EFE2CC", furniture: "#A88A56", lighting: "warm",
    },
  },
  {
    id: "grey-white",
    label: "Grey & White",
    swatch: ["#F2F2F0", "#C9CCCE", "#8B9094", "#3B4146"],
    materials: {
      walls: "#F2F2F0", ceiling: "#FFFFFF", floorTile: "#C9CCCE", bedroomFloor: "#8B9094",
      kitchenCabinet: "#5A6066", bathroomTile: "#A9AEAF", doorFinish: "#3B4146",
      exteriorPaint: "#DDE0E1", furniture: "#6E7479", lighting: "neutral",
    },
  },
  {
    id: "terracotta-brown",
    label: "Earthy Terracotta",
    swatch: ["#F0E2D2", "#C2703B", "#8A3B1F", "#4A2114"],
    materials: {
      walls: "#F0E2D2", ceiling: "#FAF1E5", floorTile: "#C2703B", bedroomFloor: "#8A3B1F",
      kitchenCabinet: "#6E2C16", bathroomTile: "#D89971", doorFinish: "#4A2114",
      exteriorPaint: "#C2703B", furniture: "#8A3B1F", lighting: "warm",
    },
  },
  {
    id: "muted-green",
    label: "White & Muted Green",
    swatch: ["#F3F2EA", "#A9B79A", "#6E8265", "#33402E"],
    materials: {
      walls: "#F3F2EA", ceiling: "#FBFAF3", floorTile: "#C2CBB6", bedroomFloor: "#6E8265",
      kitchenCabinet: "#4A5A40", bathroomTile: "#A9B79A", doorFinish: "#33402E",
      exteriorPaint: "#D9DEC9", furniture: "#5C6B4F", lighting: "cool",
    },
  },
  {
    id: "sandstone-charcoal",
    label: "Sandstone & Charcoal",
    swatch: ["#EDE3D2", "#C9A86B", "#6E5B3C", "#2A2622"],
    materials: {
      walls: "#EDE3D2", ceiling: "#F7F0E2", floorTile: "#C9A86B", bedroomFloor: "#6E5B3C",
      kitchenCabinet: "#2A2622", bathroomTile: "#B9A075", doorFinish: "#3A332C",
      exteriorPaint: "#C9A86B", furniture: "#5C4A36", lighting: "warm",
    },
  },
];

export const DEFAULT_MATERIALS: MaterialsConfig = MATERIAL_PRESETS[0].materials;

export const DEFAULT_PLOT: PlotConfig = {
  length: 50,
  width: 40,
  unit: "ft",
  shape: "rectangle",
  roadDirection: "N",
  floors: 2,
  parking: true,
  parkingArea: 200,
  garden: true,
  setbackFront: 12,
  setbackRear: 6,
  setbackSides: 4,
  buildableArea: 0,
  plotArea: 0,
};

export const DEFAULT_DESIGN: DesignConfig = {
  style: "modern",
  roof: "flat",
  palette: "warm-wood",
  rooms: defaultRoomSpecs(),
  designSeed: 17,
};

export const DEFAULT_VASTU: VastuConfig = {
  enabled: true,
  rotation: 0,
  suggestions: [],
};

export const DEFAULT_SOIL: SoilReport = {
  hasReport: false,
  location: "",
  waterTableDepth: 0,
  bearingCapacityKPa: 0,
  settlementMm: 0,
  layers: [],
  foundationType: "",
  notes: "",
};

export const DEFAULT_STRUCTURE: StructureConfig = {
  columns: [],
  beams: [],
  slabThicknessMm: 125,
  notes: "",
};

interface AppState {
  user: User | null;
  authLoading: boolean;
  view: ViewKey;
  // current working project (in-memory, synced to server on save)
  project: Project | null;
  projects: Project[];
  // editable building blocks
  plot: PlotConfig;
  design: DesignConfig;
  vastu: VastuConfig;
  materials: MaterialsConfig;
  soil: SoilReport;
  structure: StructureConfig;
  floorPlan: FloorPlanResult | null;
  generating: boolean;
  // nav helpers
  setView: (v: ViewKey) => void;
  setUser: (u: User | null) => void;
  setAuthLoading: (b: boolean) => void;
  setProjects: (p: Project[]) => void;
  setGenerating: (b: boolean) => void;
  loadProject: (p: Project) => void;
  newProject: () => void;
  resetSession: () => void;
  setPlot: (p: Partial<PlotConfig>) => void;
  setDesign: (d: Partial<DesignConfig>) => void;
  setVastu: (v: Partial<VastuConfig>) => void;
  setMaterials: (m: Partial<MaterialsConfig>) => void;
  setSoil: (s: Partial<SoilReport>) => void;
  setRooms: (r: RoomSpec[]) => void;
  regenerate: () => void;
  recomputePlot: () => void;
  applyPreset: (id: string) => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  user: null,
  authLoading: true,
  view: "login",
  project: null,
  projects: [],
  plot: { ...DEFAULT_PLOT, plotArea: computePlotArea(DEFAULT_PLOT), buildableArea: computeBuildableArea(DEFAULT_PLOT) },
  design: { ...DEFAULT_DESIGN },
  vastu: { ...DEFAULT_VASTU },
  materials: { ...DEFAULT_MATERIALS },
  soil: { ...DEFAULT_SOIL },
  structure: { ...DEFAULT_STRUCTURE },
  floorPlan: null,
  generating: false,

  setView: (v) => set({ view: v }),
  setUser: (u) => set({ user: u }),
  setAuthLoading: (b) => set({ authLoading: b }),
  setProjects: (p) => set({ projects: p }),
  setGenerating: (b) => set({ generating: b }),

  loadProject: (p) =>
    set({
      project: p,
      plot: p.plot,
      design: p.design,
      vastu: p.vastu,
      materials: p.materials,
      soil: p.soil,
      structure: p.structure,
      floorPlan: p.floorPlan,
      view: "floorplan",
    }),

  newProject: () =>
    set({
      project: null,
      plot: { ...DEFAULT_PLOT, plotArea: computePlotArea(DEFAULT_PLOT), buildableArea: computeBuildableArea(DEFAULT_PLOT) },
      design: { ...DEFAULT_DESIGN, rooms: defaultRoomSpecs(), designSeed: Math.floor(Math.random() * 9999) },
      vastu: { ...DEFAULT_VASTU },
      materials: { ...DEFAULT_MATERIALS },
      soil: { ...DEFAULT_SOIL },
      structure: { ...DEFAULT_STRUCTURE },
      floorPlan: null,
      view: "plot",
    }),

  resetSession: () =>
    set({
      user: null,
      project: null,
      projects: [],
      plot: { ...DEFAULT_PLOT, plotArea: computePlotArea(DEFAULT_PLOT), buildableArea: computeBuildableArea(DEFAULT_PLOT) },
      design: { ...DEFAULT_DESIGN },
      vastu: { ...DEFAULT_VASTU },
      materials: { ...DEFAULT_MATERIALS },
      soil: { ...DEFAULT_SOIL },
      structure: { ...DEFAULT_STRUCTURE },
      floorPlan: null,
      view: "login",
    }),

  setPlot: (p) => set((s) => ({ plot: { ...s.plot, ...p } })),
  setDesign: (d) => set((s) => ({ design: { ...s.design, ...d } })),
  setVastu: (v) => set((s) => ({ vastu: { ...s.vastu, ...v } })),
  setMaterials: (m) => set((s) => ({ materials: { ...s.materials, ...m } })),
  setSoil: (so) => set((s) => ({ soil: { ...s.soil, ...so } })),
  setRooms: (r) => set((s) => ({ design: { ...s.design, rooms: r } })),

  recomputePlot: () =>
    set((s) => ({
      plot: {
        ...s.plot,
        plotArea: computePlotArea(s.plot),
        buildableArea: computeBuildableArea(s.plot),
      },
    })),

  regenerate: () => {
    const { plot, design, vastu, structure: prevStruct } = get();
    const fp = generateFloorPlan(plot, design, vastu);
    const st = generateStructure(plot, fp);
    set({ floorPlan: fp, structure: st });
    void prevStruct;
  },

  applyPreset: (id) => {
    const preset = MATERIAL_PRESETS.find((p) => p.id === id);
    if (preset) set({ materials: { ...preset.materials } });
  },
}));
