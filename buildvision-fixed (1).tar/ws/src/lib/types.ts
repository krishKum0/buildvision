// AI BuildVision 360° — shared domain types

export type Unit = "ft" | "m";
export type PlotShape = "rectangle" | "square" | "lshape" | "irregular";
export type RoadDirection = "N" | "NE" | "E" | "SE" | "S" | "SW" | "W" | "NW";

export interface PlotConfig {
  length: number; // along X (e.g. east-west depth from road)
  width: number; // along Z (north-south)
  unit: Unit;
  shape: PlotShape;
  roadDirection: RoadDirection;
  floors: number;
  parking: boolean;
  parkingArea: number; // sq units
  garden: boolean;
  setbackFront: number;
  setbackRear: number;
  setbackSides: number;
  buildableArea: number; // computed
  plotArea: number; // computed
}

export type RoomType =
  | "master"
  | "bedroom"
  | "living"
  | "dining"
  | "kitchen"
  | "bath"
  | "pooja"
  | "study"
  | "guest"
  | "balcony"
  | "utility"
  | "storage"
  | "staircase"
  | "parking"
  | "garden"
  | "terrace";

export interface RoomSpec {
  type: RoomType;
  label: string;
  count: number;
  minArea: number; // sq units
}

export interface Room {
  id: string;
  type: RoomType;
  label: string;
  x: number; // origin (plot units, lower-left)
  z: number;
  w: number; // width along X
  d: number; // depth along Z
  floor: number; // 0-indexed
  vastu?: string; // assigned zone label e.g. "SW"
}

export interface FloorPlanResult {
  rooms: Room[];
  floors: number;
  unit: Unit;
  plotW: number;
  plotD: number;
  setbacks: { front: number; rear: number; sides: number };
  notes: string[];
}

export type HouseStyle = "modern" | "minimalist" | "contemporary" | "traditional";
export type RoofType = "flat" | "sloped" | "terrace";
export type MaterialPalette =
  | "warm-wood"
  | "cream-beige"
  | "grey-white"
  | "terracotta-brown"
  | "muted-green"
  | "sandstone-charcoal";

export interface DesignConfig {
  style: HouseStyle;
  roof: RoofType;
  palette: MaterialPalette;
  rooms: RoomSpec[];
  designSeed: number;
  conceptText?: string;
}

export interface VastuConfig {
  enabled: boolean;
  rotation: number; // degrees, compass rotation for plot orientation
  suggestions: { zone: string; direction: string; room: RoomType; note: string }[];
}

export interface MaterialsConfig {
  walls: string; // color hex
  ceiling: string;
  floorTile: string;
  bedroomFloor: string;
  kitchenCabinet: string;
  bathroomTile: string;
  doorFinish: string;
  exteriorPaint: string;
  furniture: string;
  lighting: "warm" | "neutral" | "cool";
}

export interface SoilLayer {
  name: string;
  depthFrom: number;
  depthTo: number;
  bearingKPa: number;
  color: string;
}

export interface SoilReport {
  hasReport: boolean;
  location: string;
  waterTableDepth: number;
  bearingCapacityKPa: number;
  settlementMm: number;
  layers: SoilLayer[];
  foundationType: string;
  notes: string;
}

export interface StructureConfig {
  columns: { x: number; z: number; size: number }[];
  beams: { x: number; z: number; length: number; axis: "x" | "z" }[];
  slabThicknessMm: number;
  notes: string;
}

export interface Project {
  id: string;
  name: string;
  plot: PlotConfig;
  design: DesignConfig;
  floorPlan: FloorPlanResult;
  vastu: VastuConfig;
  materials: MaterialsConfig;
  soil: SoilReport;
  structure: StructureConfig;
  status: string;
  conceptImg?: string;
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: string;
}

export type ViewKey =
  | "login"
  | "dashboard"
  | "plot"
  | "design"
  | "floorplan"
  | "viewer3d"
  | "vastu"
  | "materials"
  | "soil"
  | "structure"
  | "cost"
  | "history"
  | "exports";
