// AI BuildVision 360° — lightweight HMAC cookie session + scrypt password hashing
import { cookies } from "next/headers";
import crypto from "crypto";
import { db } from "./db";

const COOKIE = "bv_session";
const SECRET = process.env.AUTH_SECRET || "buildvision-360-dev-secret-change-me";
if (process.env.NODE_ENV === "production" && !process.env.AUTH_SECRET) {
  console.warn("[auth] AUTH_SECRET is not set — using an insecure default. Set it in .env.");
}

type SessionPayload = { uid: string; iat: number };

function b64url(s: string | Buffer) {
  return Buffer.from(s as any)
    .toString("base64")
    .replace(/=+$/, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");
}
function b64urlDecode(s: string): Buffer {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  return Buffer.from(s.replace(/-/g, "+").replace(/_/g, "/") + pad, "base64");
}

export function signToken(payload: SessionPayload): string {
  const body = b64url(JSON.stringify(payload));
  const sig = crypto.createHmac("sha256", SECRET).update(body).digest();
  return `${body}.${b64url(sig)}`;
}

export function verifyToken(token: string): SessionPayload | null {
  try {
    const [body, sig] = token.split(".");
    if (!body || !sig) return null;
    const expected = crypto.createHmac("sha256", SECRET).update(body).digest();
    const ok = crypto.timingSafeEqual(b64urlDecode(sig), expected);
    if (!ok) return null;
    return JSON.parse(b64urlDecode(body).toString("utf8")) as SessionPayload;
  } catch {
    return null;
  }
}

export function hashPassword(pw: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(pw, salt, 32).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(pw: string, stored: string): boolean {
  try {
    const [, salt, hash] = stored.split("$");
    const check = crypto.scryptSync(pw, salt, 32).toString("hex");
    return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(check, "hex"));
  } catch {
    return false;
  }
}

export async function setSessionCookie(uid: string) {
  const token = signToken({ uid, iat: Date.now() });
  (await cookies()).set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function clearSessionCookie() {
  (await cookies()).delete(COOKIE);
}

export async function getCurrentUser() {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  const payload = verifyToken(token);
  if (!payload) return null;
  const user = await db.user.findUnique({
    where: { id: payload.uid },
    select: { id: true, email: true, name: true, role: true },
  });
  return user;
}
