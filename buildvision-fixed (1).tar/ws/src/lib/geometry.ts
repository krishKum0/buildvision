// AI BuildVision 360° — rule-based constrained geometry & layout engine
// Generates measurable, editable floor plans (NOT just images) from plot + design config.

import type {
  PlotConfig,
  DesignConfig,
  FloorPlanResult,
  Room,
  RoomType,
  RoomSpec,
  VastuConfig,
  StructureConfig,
  RoadDirection,
} from "./types";

// ---------- Plot area / buildable area ----------
export function computePlotArea(plot: PlotConfig): number {
  if (plot.shape === "rectangle" || plot.shape === "square") {
    return round(plot.length * plot.width, 1);
  }
  if (plot.shape === "lshape") {
    // approx L = main body minus notch (half of body)
    return round(plot.length * plot.width * 0.75, 1);
  }
  // irregular — use product as upper bound, scaled
  return round(plot.length * plot.width * 0.85, 1);
}

export function computeBuildableArea(plot: PlotConfig): number {
  const depth = plot.length - plot.setbackFront - plot.setbackRear;
  const width = plot.width - plot.setbackSides * 2;
  return round(Math.max(depth, 0) * Math.max(width, 0), 1);
}

// ---------- Vastu zone mapping ----------
// 8 zones on a compass. Map RoadDirection -> which side faces road.
// We assign recommended rooms to zones per Vastu preferences (configurable).
export const VASTU_RULES: Record<string, { direction: string; room: RoomType; note: string }> = {
  NE: { direction: "North-East", room: "pooja", note: "Pooja / prayer — auspicious, morning light" },
  E: { direction: "East", room: "living", note: "Living / entrance — prosperity, sunrise" },
  SE: { direction: "South-East", room: "kitchen", note: "Kitchen — Agni corner" },
  S: { direction: "South", room: "bedroom", note: "Bedrooms acceptable" },
  SW: { direction: "South-West", room: "master", note: "Master bedroom — stability, earth element" },
  W: { direction: "West", room: "study", note: "Study / children's room" },
  NW: { direction: "North-West", room: "guest", note: "Guest room / parking — air element" },
  N: { direction: "North", room: "utility", note: "Utility / storage — water flow" },
};

// Build zone rectangles over the plot (X = east-west, Z = north-south)
// roadDirection determines which plot edge faces the road (front setback).
export function buildVastuZones(plot: PlotConfig) {
  // 3x3 grid over plot bounds; center ignored; corners + edges = 8 zones
  const x = [0, plot.width / 3, (plot.width * 2) / 3, plot.width];
  const z = [0, plot.length / 3, (plot.length * 2) / 3, plot.length];
  const labels = [
    ["NW", "N", "NE"],
    ["W", "C", "E"],
    ["SW", "S", "SE"],
  ];
  const zones: { zone: string; direction: string; x: number; z: number; w: number; d: number }[] = [];
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      const zone = labels[i][j];
      if (zone === "C") continue;
      zones.push({
        zone,
        direction: VASTU_RULES[zone].direction,
        x: x[j],
        z: z[i],
        w: x[j + 1] - x[j],
        d: z[i + 1] - z[i],
      });
    }
  }
  return zones;
}

// ---------- Layout generator ----------
// Strategy: divide buildable footprint into a structural grid of columns (bays).
// Place rooms into bays by priority based on Vastu (if enabled) or rule defaults.
// This is deterministic + measurable + editable.

function seedRand(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function defaultZoneFor(type: RoomType): string | null {
  switch (type) {
    case "master": return "SW";
    case "kitchen": return "SE";
    case "pooja": return "NE";
    case "living": return "E";
    case "guest": return "NW";
    case "study": return "W";
    case "bedroom": return "S";
    case "utility": return "N";
    default: return null;
  }
}

export function generateFloorPlan(
  plot: PlotConfig,
  design: DesignConfig,
  vastu: VastuConfig
): FloorPlanResult {
  const rng = seedRand(design.designSeed || 1);
  const rooms: Room[] = [];
  const notes: string[] = [];

  const bx = plot.setbackSides;
  const bz = plot.setbackFront; // road side = front
  const bw = plot.width - plot.setbackSides * 2;
  const bd = plot.length - plot.setbackFront - plot.setbackRear;
  notes.push(`Buildable footprint: ${round(bw, 1)} × ${round(bd, 1)} ${plot.unit}`);

  // Parking & garden reserve (ground floor only)
  let reserveX = 0;
  let reserveD = 0;
  if (plot.parking) {
    reserveD = Math.min(Math.max(plot.parkingArea / bw, 12), bd * 0.4);
    notes.push(`Parking reserve: ${round(bw, 1)} × ${round(reserveD, 1)} ${plot.unit} (front)`);
  }
  let gardenD = 0;
  if (plot.garden) {
    gardenD = Math.min(bd * 0.18, 10);
    notes.push(`Garden reserve: rear strip ${round(gardenD, 1)} ${plot.unit}`);
  }

  // Structural bay grid: split buildable width into 2 or 3 bays
  const bays = bw >= 36 ? 3 : 2;
  const bayW = bw / bays;

  // Vertical segmentation per floor: front reserve (parking) + living band + rear band (garden)
  const usableD = bd - reserveD - gardenD;
  // split usable depth into front band (public) and rear band (private)
  const frontBandD = usableD * (vastu.enabled ? 0.45 : 0.5);
  const rearBandD = usableD - frontBandD;

  // Expand specs into individual room requests with target areas
  const requests: { type: RoomType; label: string; area: number; floor: number; zone?: string }[] = [];
  for (const spec of design.rooms) {
    for (let k = 0; k < spec.count; k++) {
      // distribute across floors for bedrooms (each floor gets some)
      let floor = 0;
      if (spec.type === "master") floor = Math.min(1, plot.floors - 1);
      else if (spec.type === "bedroom") floor = Math.min(1 + k, plot.floors - 1);
      else if (spec.type === "terrace" && plot.floors > 1) floor = plot.floors - 1;
      else if (spec.type === "balcony") floor = Math.min(1, plot.floors - 1);
      requests.push({
        type: spec.type,
        label: spec.count > 1 ? `${spec.label} ${k + 1}` : spec.label,
        area: spec.minArea,
        floor,
        zone: vastu.enabled ? defaultZoneFor(spec.type) ?? undefined : undefined,
      });
    }
  }

  // Per-floor room placement
  const floorsToBuild = Math.max(1, plot.floors);
  for (let f = 0; f < floorsToBuild; f++) {
    const floorReqs = requests.filter((r) => r.floor === f);
    // sort: large fixed rooms first
    const order: RoomType[] = ["parking", "garden", "staircase", "master", "living", "kitchen", "dining", "pooja", "bedroom", "guest", "study", "bath", "utility", "storage", "balcony", "terrace"];
    floorReqs.sort((a, b) => order.indexOf(a.type) - order.indexOf(b.type));

    // zones for this floor
    const zones = vastu.enabled ? buildVastuZones({ ...plot }) : null;

    let placedCount = 0;
    for (const req of floorReqs) {
      // Parking/garden only ground floor fixed reserves
      if (req.type === "parking" && f === 0) {
        rooms.push({
          id: rid(), type: "parking", label: "Parking", floor: 0,
          x: bx, z: bz, w: bw, d: reserveD, vastu: "Front reserve",
        });
        continue;
      }
      if (req.type === "garden" && f === 0 && plot.garden) {
        rooms.push({
          id: rid(), type: "garden", label: "Garden", floor: 0,
          x: bx, z: bz + bd - gardenD, w: bw, d: gardenD, vastu: "Rear reserve",
        });
        continue;
      }
      if (req.type === "terrace" && f === floorsToBuild - 1 && plot.floors > 1) {
        rooms.push({
          id: rid(), type: "terrace", label: "Open Terrace", floor: f,
          x: bx, z: bz + reserveD, w: bw, d: bd - reserveD - gardenD, vastu: "Roof",
        });
        continue;
      }
      if (req.type === "staircase") {
        // place staircase at side band, full depth of usable
        rooms.push({
          id: rid(), type: "staircase", label: "Staircase", floor: f,
          x: bx + bw - bayW * 0.45, z: bz + reserveD + 2,
          w: bayW * 0.45, d: usableD - 4, vastu: req.zone,
        });
        continue;
      }

      // pick a bay and band
      const bayIndex = pickBay(req.type, bays, rng, placedCount);
      // try to honor vastu zone by mapping zone -> bay/band
      let band = req.zone === "SW" || req.zone === "S" || req.zone === "W" ? "rear" : "front";
      if (req.type === "master") band = "rear";
      if (req.type === "kitchen") band = "rear";
      if (req.type === "living" || req.type === "dining") band = "front";
      if (req.type === "pooja") band = "front";

      const bandZ = band === "front" ? bz + reserveD : bz + reserveD + frontBandD;
      const bandD = band === "front" ? frontBandD : rearBandD;
      const roomW = bayW;
      const roomD = bandD;
      const roomX = bx + bayIndex * bayW;
      const roomZ = bandZ;

      const assignedZone = zones ? nearestZone(roomX + roomW / 2, roomZ + roomD / 2, zones) : undefined;

      rooms.push({
        id: rid(),
        type: req.type,
        label: req.label,
        floor: f,
        x: round(roomX, 2),
        z: round(roomZ, 2),
        w: round(roomW, 2),
        d: round(roomD, 2),
        vastu: vastu.enabled ? assignedZone?.zone ?? req.zone : undefined,
      });
      placedCount++;
    }
  }

  // circulation validation notes
  notes.push(...validateLayout(rooms, plot));
  if (vastu.enabled) notes.push("Vastu preferences applied — review structural & ventilation constraints.");

  return {
    rooms,
    floors: floorsToBuild,
    unit: plot.unit,
    plotW: plot.width,
    plotD: plot.length,
    setbacks: { front: plot.setbackFront, rear: plot.setbackRear, sides: plot.setbackSides },
    notes,
  };
}

function pickBay(type: RoomType, bays: number, rng: () => number, placed: number): number {
  // stagger placements across bays
  if (bays === 2) return placed % 2;
  return placed % bays;
}

function nearestZone(
  cx: number,
  cz: number,
  zones: { zone: string; x: number; z: number; w: number; d: number }[]
) {
  let best = zones[0];
  let bestDist = Infinity;
  for (const z of zones) {
    const dx = cx - (z.x + z.w / 2);
    const dz = cz - (z.z + z.d / 2);
    const d = dx * dx + dz * dz;
    if (d < bestDist) {
      bestDist = d;
      best = z;
    }
  }
  return best;
}

function validateLayout(rooms: Room[], plot: PlotConfig): string[] {
  const notes: string[] = [];
  const hasStair = rooms.some((r) => r.type === "staircase");
  if (plot.floors > 1 && !hasStair) notes.push("Warning: multi-floor plan missing staircase.");
  const baths = rooms.filter((r) => r.type === "bath").length;
  const beds = rooms.filter((r) => r.type === "master" || r.type === "bedroom").length;
  if (beds > 0 && baths === 0) notes.push("Note: add at least one bathroom for bedrooms.");
  const minDoor = 0.9;
  rooms.forEach((r) => {
    if (r.w < minDoor + 1.2 && r.d < minDoor + 1.2) {
      notes.push(`Warning: ${r.label} may be too small for door clearance.`);
    }
  });
  notes.push(`Total rooms placed: ${rooms.length} across ${plot.floors} floor(s).`);
  return notes;
}

// ---------- Structural layout (preliminary) ----------
export function generateStructure(plot: PlotConfig, fp: FloorPlanResult): StructureConfig {
  const bw = plot.width - plot.setbackSides * 2;
  const bd = plot.length - plot.setbackFront - plot.setbackRear;
  // place columns on a grid: 4 along width, 3 along depth
  const cols: { x: number; z: number; size: number }[] = [];
  const colsX = 4;
  const colsZ = 3;
  for (let i = 0; i < colsX; i++) {
    for (let j = 0; j < colsZ; j++) {
      cols.push({
        x: round(plot.setbackSides + (bw * i) / (colsX - 1), 2),
        z: round(plot.setbackFront + (bd * j) / (colsZ - 1), 2),
        size: 0.45,
      });
    }
  }
  // beams along grid lines
  const beams: { x: number; z: number; length: number; axis: "x" | "z" }[] = [];
  for (let j = 0; j < colsZ; j++) {
    beams.push({
      x: cols[0].x,
      z: cols[j * colsX].z,
      length: round(bw, 2),
      axis: "x",
    });
  }
  for (let i = 0; i < colsX; i++) {
    beams.push({
      x: cols[i].x,
      z: cols[0].z,
      length: round(bd, 2),
      axis: "z",
    });
  }
  return {
    columns: cols,
    beams,
    slabThicknessMm: 125,
    notes:
      "Preliminary structural grid for conceptual review only. Final member sizing, reinforcement & foundations require a qualified structural engineer.",
  };
}

// ---------- helpers ----------
let _id = 0;
function rid(): string {
  _id += 1;
  return `r${_id}`;
}
function round(n: number, d = 2): number {
  const f = Math.pow(10, d);
  return Math.round(n * f) / f;
}

export function roomArea(r: Room): number {
  return round(r.w * r.d, 1);
}

export const ROOM_LIBRARY: { type: RoomType; label: string; defaultArea: number; icon: string }[] = [
  { type: "master", label: "Master Bedroom", defaultArea: 180, icon: "bed" },
  { type: "bedroom", label: "Bedroom", defaultArea: 130, icon: "bed" },
  { type: "living", label: "Living Room", defaultArea: 220, icon: "sofa" },
  { type: "dining", label: "Dining Room", defaultArea: 120, icon: "utensils" },
  { type: "kitchen", label: "Kitchen", defaultArea: 90, icon: "chef-hat" },
  { type: "bath", label: "Bathroom", defaultArea: 40, icon: "bath" },
  { type: "pooja", label: "Pooja Room", defaultArea: 35, icon: "sparkles" },
  { type: "study", label: "Study Room", defaultArea: 80, icon: "book" },
  { type: "guest", label: "Guest Room", defaultArea: 110, icon: "user" },
  { type: "balcony", label: "Balcony", defaultArea: 50, icon: "trees" },
  { type: "utility", label: "Utility", defaultArea: 45, icon: "wrench" },
  { type: "storage", label: "Storage", defaultArea: 40, icon: "package" },
  { type: "staircase", label: "Staircase", defaultArea: 60, icon: "stairs" },
  { type: "parking", label: "Parking", defaultArea: 160, icon: "car" },
  { type: "garden", label: "Garden", defaultArea: 120, icon: "trees" },
  { type: "terrace", label: "Terrace", defaultArea: 200, icon: "sun" },
];

export function defaultRoomSpecs(): RoomSpec[] {
  return [
    { type: "master", label: "Master Bedroom", count: 1, minArea: 180 },
    { type: "bedroom", label: "Bedroom", count: 2, minArea: 130 },
    { type: "living", label: "Living Room", count: 1, minArea: 220 },
    { type: "kitchen", label: "Kitchen", count: 1, minArea: 90 },
    { type: "dining", label: "Dining", count: 1, minArea: 120 },
    { type: "bath", label: "Bathroom", count: 2, minArea: 40 },
    { type: "pooja", label: "Pooja Room", count: 1, minArea: 35 },
    { type: "staircase", label: "Staircase", count: 1, minArea: 60 },
    { type: "parking", label: "Parking", count: 1, minArea: 160 },
    { type: "garden", label: "Garden", count: 1, minArea: 120 },
  ];
}
