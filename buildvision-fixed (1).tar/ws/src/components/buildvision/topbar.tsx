"use client";

import { useAppStore } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Compass, Save, Sparkles, ChevronRight } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import type { ViewKey } from "@/lib/types";
import { MobileNav } from "./mobile-nav";

const TITLES: Record<ViewKey, { title: string; sub: string }> = {
  login: { title: "", sub: "" },
  dashboard: { title: "Dashboard", sub: "Overview of your design workspace" },
  plot: { title: "Plot Information", sub: "Enter land dimensions & site constraints" },
  design: { title: "AI Design Generator", sub: "Generate multiple house design concepts" },
  floorplan: { title: "2D Floor Plan", sub: "Editable room arrangements & circulation" },
  viewer3d: { title: "3D Building Viewer", sub: "Interactive 360° model inspection" },
  vastu: { title: "Vastu Shastra Planning", sub: "Optional direction-based room zoning" },
  materials: { title: "Materials & Colour Library", sub: "Apply palettes with live 3D preview" },
  soil: { title: "Soil & Foundation Planning", sub: "Geotechnical data & foundation guidance" },
  structure: { title: "Structural Plan", sub: "Preliminary column & beam layout" },
  history: { title: "Projects & Version History", sub: "Reopen, compare & restore designs" },
  exports: { title: "Export & Share", sub: "Download drawings & share with engineers" },
};

export function Topbar() {
  const view = useAppStore((s) => s.view);
  const project = useAppStore((s) => s.project);
  const setView = useAppStore((s) => s.setView);
  const plot = useAppStore((s) => s.plot);
  const design = useAppStore((s) => s.design);
  const vastu = useAppStore((s) => s.vastu);
  const materials = useAppStore((s) => s.materials);
  const soil = useAppStore((s) => s.soil);
  const structure = useAppStore((s) => s.structure);
  const setProjects = useAppStore((s) => s.setProjects);
  const projects = useAppStore((s) => s.projects);
  const loadProject = useAppStore((s) => s.loadProject);
  const setUser = useAppStore((s) => s.setUser);

  const meta = TITLES[view];

  async function saveProject() {
    const name = project?.name ?? `Plot ${plot.length}×${plot.width} ${plot.unit}`;
    const payload = {
      name,
      plot, design, vastu, materials, soil, structure,
      conceptImg: design.palette === "terracotta-brown" ? "/concepts/modern-villa.jpg" : project?.conceptImg,
    };
    try {
      let res;
      if (project?.id) {
        res = await fetch(`/api/projects/${project.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...payload, versionNote: "Manual save" }),
        });
      } else {
        res = await fetch("/api/projects", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Save failed", description: data.error, variant: "destructive" });
        return;
      }
      // refresh projects list
      const list = await fetch("/api/projects", { cache: "no-store" });
      const ld = await list.json();
      if (ld.projects) {
        setProjects(ld.projects);
        loadProject(data.project);
      }
      toast({ title: "Project saved", description: `${data.project.name} — version snapshot stored` });
    } catch (e: any) {
      toast({ title: "Save failed", description: e.message, variant: "destructive" });
    }
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
    useAppStore.getState().resetSession();
  }

  const showSave = !["dashboard", "history", "exports", "login"].includes(view);
  // Track which steps are configured for the breadcrumb status
  const steps = [
    { label: "Plot", done: plot.plotArea > 0, view: "plot" as ViewKey },
    { label: "Design", done: !!design.conceptText || design.designSeed > 0, view: "design" as ViewKey },
    { label: "3D", done: view === "viewer3d" || view === "floorplan", view: "viewer3d" as ViewKey },
    { label: "Vastu", done: vastu.enabled, view: "vastu" as ViewKey },
  ];

  return (
    <header className="sticky top-0 z-30 border-b border-border/60 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex items-center gap-4 px-4 sm:px-6 h-16">
        <MobileNav />
        <div className="hidden md:flex items-center gap-2 lg:hidden">
          <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground grid place-items-center">
            <Compass className="w-4 h-4" />
          </div>
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h1 className="text-base sm:text-lg font-semibold tracking-tight truncate">{meta.title}</h1>
            {project && (
              <Badge variant="secondary" className="hidden sm:inline-flex">{project.name}</Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground truncate">{meta.sub}</p>
        </div>

        {/* breadcrumb steps */}
        <div className="hidden xl:flex items-center gap-1 text-xs">
          {steps.map((s, i) => (
            <div key={s.label} className="flex items-center gap-1">
              <button
                onClick={() => setView(s.view)}
                className={`px-2 py-1 rounded-md transition-colors ${
                  s.done ? "text-foreground hover:bg-muted" : "text-muted-foreground/60"
                }`}
              >
                <span className={s.done ? "text-primary font-medium" : ""}>{i + 1}.</span> {s.label}
              </button>
              {i < steps.length - 1 && <ChevronRight className="w-3 h-3 text-muted-foreground/40" />}
            </div>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {showSave && (
            <Button size="sm" variant="outline" onClick={saveProject} className="gap-1.5">
              <Save className="w-4 h-4" /> <span className="hidden sm:inline">Save</span>
            </Button>
          )}
          <Button size="sm" onClick={() => setView("design")} className="gap-1.5">
            <Sparkles className="w-4 h-4" /> <span className="hidden sm:inline">Generate</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
