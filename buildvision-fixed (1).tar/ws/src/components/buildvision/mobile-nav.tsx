"use client";

import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetClose } from "@/components/ui/sheet";
import { Menu, Compass } from "lucide-react";
import { NavList, UserBar } from "./sidebar";

export function MobileNav() {
  const [open, setOpen] = useState(false);
  const user = useAppStore((s) => s.user);
  const setUser = useAppStore((s) => s.setUser);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
    useAppStore.getState().resetSession();
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden h-9 w-9" aria-label="Open menu">
          <Menu className="w-5 h-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-72 p-0 flex flex-col bg-sidebar">
        <div className="p-5 border-b border-sidebar-border flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-primary text-primary-foreground grid place-items-center shadow">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold text-sm leading-none tracking-tight">BuildVision 360°</p>
              <p className="text-[10px] text-muted-foreground mt-1">AI Architectural Studio</p>
            </div>
          </div>
          <SheetClose asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">✕</Button>
          </SheetClose>
        </div>
        <div className="flex-1 flex flex-col overflow-hidden">
          <NavList onNavigate={() => setOpen(false)} />
        </div>
        <UserBar name={user?.name} role={user?.role} onLogout={logout} />
      </SheetContent>
    </Sheet>
  );
}
