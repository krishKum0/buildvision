"use client";

import { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Environment, ContactShadows, Grid, GizmoHelper, GizmoViewport, Sky } from "@react-three/drei";
import * as THREE from "three";
import type { FloorPlanResult, MaterialsConfig, RoomType } from "@/lib/types";

const WALL_HEIGHT = 9.5;
const WALL_THICK = 0.35;
const SLAB_THICK = 0.4;
const DOOR_GAP = 3.2;
const WIN_H = 2.8;
const WIN_W = 3.2;

const ROOM_COLORS_3D: Record<RoomType, string> = {
  master: "#d9b98a", bedroom: "#e0c79a", living: "#cdbfa0", dining: "#d8c8a0",
  kitchen: "#c79a6b", bath: "#bcd0d6", pooja: "#e6c46b", study: "#c2c8d4",
  guest: "#d0c0cc", balcony: "#bcd0a8", utility: "#b8b6ae", storage: "#a89e8e",
  staircase: "#9a948a", parking: "#a6a6a0", garden: "#7fa866", terrace: "#b8b0a0",
};

interface SceneProps {
  floorPlan: FloorPlanResult;
  materials: MaterialsConfig;
  activeFloor: number;
  showWalls: boolean;
  showRoof: boolean;
  showInterior: boolean;
  orbitAutoRotate: boolean;
}

export function HouseScene(props: SceneProps) {
  return (
    <Canvas shadows camera={{ position: [60, 48, 70], fov: 42 }} dpr={[1, 1.6]} gl={{ antialias: true }}>
      <color attach="background" args={["#eef0ea"]} />
      <fog attach="fog" args={["#eef0ea", 120, 320]} />
      <ambientLight intensity={0.55} />
      <directionalLight
        position={[60, 80, 40]}
        intensity={1.6}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-near={1}
        shadow-camera-far={300}
        shadow-camera-left={-90}
        shadow-camera-right={90}
        shadow-camera-top={90}
        shadow-camera-bottom={-90}
      />
      <hemisphereLight args={["#fff6e0", "#b9a989", 0.5]} />
      <Sky sunPosition={[60, 80, 40]} turbidity={6} rayleigh={1.5} />
      <House {...props} />
      <ContactShadows position={[0, 0.02, 0]} opacity={0.4} scale={300} blur={2.2} far={50} />
      <Grid
        position={[0, 0.01, 0]}
        args={[400, 400]}
        cellSize={5}
        cellThickness={0.6}
        cellColor="#9a8460"
        sectionSize={20}
        sectionThickness={1}
        sectionColor="#b0703b"
        fadeDistance={260}
        infiniteGrid
      />
      <OrbitControls
        enableDamping
        dampingFactor={0.08}
        minDistance={20}
        maxDistance={220}
        maxPolarAngle={Math.PI / 2.05}
        autoRotate={props.orbitAutoRotate}
        autoRotateSpeed={0.7}
        target={[0, WALL_HEIGHT * (props.floorPlan.floors) / 2, 0]}
      />
      <Environment preset="sunset" />
      <GizmoHelper alignment="bottom-right" margin={[70, 70]}>
        <GizmoViewport axisColors={["#b45309", "#3b7a3b", "#6c4a2f"]} labelColor="white" />
      </GizmoHelper>
    </Canvas>
  );
}

function House({ floorPlan, materials, activeFloor, showWalls, showRoof, showInterior }: Omit<SceneProps, "orbitAutoRotate">) {
  const { plotW, plotD, setbacks } = floorPlan;
  // Center the plot around origin
  const ox = -plotW / 2;
  const oz = -plotD / 2;
  const buildX = ox + setbacks.sides;
  const buildZ = oz + setbacks.front;
  const buildW = plotW - setbacks.sides * 2;
  const buildD = plotD - setbacks.front - setbacks.rear;

  const floors = floorPlan.floors;

  return (
    <group>
      {/* Plot ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[plotW, plotD]} />
        <meshStandardMaterial color="#8a9a6a" roughness={1} />
      </mesh>
      <mesh position={[0, 0.05, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[buildW, buildD]} />
        <meshStandardMaterial color={materials.floorTile} roughness={0.9} />
      </mesh>

      {/* Setback boundary marker */}
      <SetbackFence x={buildX} z={buildZ} w={buildW} d={buildD} />

      {/* Floors */}
      {Array.from({ length: floors }).map((_, f) => {
        const yBase = f * WALL_HEIGHT;
        const visible = activeFloor === -1 || activeFloor === f;
        const dim = activeFloor !== -1 && activeFloor !== f;
        return (
          <group key={f} visible={visible}>
            <FloorLevel
              floor={f}
              yBase={yBase}
              rooms={floorPlan.rooms.filter((r) => r.floor === f)}
              buildX={buildX} buildZ={buildZ} buildW={buildW} buildD={buildD}
              materials={materials}
              showWalls={showWalls}
              showInterior={showInterior}
              isTop={f === floors - 1}
              showRoof={showRoof && f === floors - 1}
              dim={dim}
            />
          </group>
        );
      })}
    </group>
  );
}

function SetbackFence({ x, z, w, d }: { x: number; z: number; w: number; d: number }) {
  const h = 0.6;
  const t = 0.15;
  return (
    <group>
      {/* dashed boundary posts */}
      {Array.from({ length: Math.round(w / 4) }).map((_, i) => (
        <mesh key={`px${i}`} position={[x + (i * 4) + 2, h / 2, z]} castShadow>
          <boxGeometry args={[0.2, h, 0.2]} />
          <meshStandardMaterial color="#7a6a4a" />
        </mesh>
      ))}
      {Array.from({ length: Math.round(d / 4) }).map((_, i) => (
        <mesh key={`pz${i}`} position={[x, h / 2, z + (i * 4) + 2]} castShadow>
          <boxGeometry args={[0.2, h, 0.2]} />
          <meshStandardMaterial color="#7a6a4a" />
        </mesh>
      ))}
    </group>
  );
}

function FloorLevel({
  floor, yBase, rooms, buildX, buildZ, buildW, buildD, materials, showWalls, showInterior, isTop, showRoof, dim,
}: {
  floor: number; yBase: number; rooms: any[]; buildX: number; buildZ: number;
  buildW: number; buildD: number; materials: MaterialsConfig;
  showWalls: boolean; showInterior: boolean; isTop: boolean; showRoof: boolean; dim?: boolean;
}) {
  const matRef = useRef<THREE.MeshStandardMaterial>(null);
  useFrame(() => {
    if (matRef.current) {
      matRef.current.opacity = dim ? 0.12 : 1;
      matRef.current.transparent = !!dim;
    }
  });
  return (
    <group>
      {/* Floor slab */}
      <mesh position={[buildX + buildW / 2, yBase, buildZ + buildD / 2]} receiveShadow castShadow>
        <boxGeometry args={[buildW, SLAB_THICK, buildD]} />
        <meshStandardMaterial ref={matRef} color={materials.floorTile} roughness={0.85} />
      </mesh>

      {/* Rooms: floor tiles + walls + windows */}
      {rooms.map((r) => (
        <Room3D
          key={r.id}
          room={r}
          yBase={yBase}
          materials={materials}
          showWalls={showWalls}
          showInterior={showInterior}
          dim={dim}
        />
      ))}

      {/* Roof on top floor */}
      {isTop && showRoof && (
        <Roof yTop={yBase + WALL_HEIGHT} buildX={buildX} buildZ={buildZ} buildW={buildW} buildD={buildD} color={materials.exteriorPaint} />
      )}
    </group>
  );
}

function Room3D({ room, yBase, materials, showWalls, showInterior, dim }: {
  room: any; yBase: number; materials: MaterialsConfig;
  showWalls: boolean; showInterior: boolean; dim?: boolean;
}) {
  const cx = room.x + room.w / 2;
  const cz = room.z + room.d / 2;
  const floorColor = ROOM_COLORS_3D[room.type as RoomType] ?? materials.floorTile;

  if (room.type === "parking" || room.type === "garden" || room.type === "terrace") {
    // Open areas: just a floor with low parapet / hedge
    return (
      <group>
        <mesh position={[cx, yBase + SLAB_THICK / 2 + 0.05, cz]} receiveShadow>
          <boxGeometry args={[room.w, 0.1, room.d]} />
          <meshStandardMaterial color={room.type === "garden" ? "#7fa866" : "#9a9690"} roughness={1} />
        </mesh>
        {room.type === "garden" &&
          Array.from({ length: Math.max(2, Math.round(room.w / 6)) }).map((_, i) => (
            <mesh key={i} position={[room.x + (i + 0.5) * (room.w / Math.max(2, Math.round(room.w / 6))), yBase + 0.6, room.z + room.d * 0.5]} castShadow>
              <sphereGeometry args={[0.7, 8, 8]} />
              <meshStandardMaterial color="#5a8a4a" roughness={1} />
            </mesh>
          ))}
        {room.type === "parking" && (
          <mesh position={[cx, yBase + 0.5, cz]} castShadow>
            <boxGeometry args={[2, 1.2, 4]} />
            <meshStandardMaterial color="#5a6066" metalness={0.4} roughness={0.4} />
          </mesh>
        )}
      </group>
    );
  }

  return (
    <group>
      {/* room floor tile */}
      {showInterior && (
        <mesh position={[cx, yBase + SLAB_THICK / 2 + 0.02, cz]} receiveShadow>
          <boxGeometry args={[room.w - 0.1, 0.08, room.d - 0.1]} />
          <meshStandardMaterial color={floorColor} roughness={0.85} />
        </mesh>
      )}

      {/* walls */}
      {showWalls && (
        <group>
          {/* outer 4 walls with door gap on one side */}
          <WallSegment cx={cx} cz={cz} w={room.w} d={room.d} side="north" y={yBase + WALL_HEIGHT / 2} color={materials.walls} hasWindow />
          <WallSegment cx={cx} cz={cz} w={room.w} d={room.d} side="south" y={yBase + WALL_HEIGHT / 2} color={materials.walls} hasDoor />
          <WallSegment cx={cx} cz={cz} w={room.w} d={room.d} side="east" y={yBase + WALL_HEIGHT / 2} color={materials.walls} hasWindow />
          <WallSegment cx={cx} cz={cz} w={room.w} d={room.d} side="west" y={yBase + WALL_HEIGHT / 2} color={materials.walls} />
        </group>
      )}

      {/* simple furniture hints */}
      {showInterior && room.type === "master" && (
        <BedGroup x={cx} z={cz - room.d / 2 + 2.5} y={yBase + SLAB_THICK / 2} />
      )}
      {showInterior && room.type === "living" && (
        <SofaGroup x={cx} z={cz - room.d / 2 + 3} y={yBase + SLAB_THICK / 2} color={materials.furniture} />
      )}
    </group>
  );
}

function WallSegment({ cx, cz, w, d, side, y, color, hasDoor, hasWindow }: {
  cx: number; cz: number; w: number; d: number; side: "north" | "south" | "east" | "west";
  y: number; color: string; hasDoor?: boolean; hasWindow?: boolean;
}) {
  // walls are thin boxes; door gap in the middle
  const t = WALL_THICK;
  let geom: [number, number, number] = [w, WALL_HEIGHT, t];
  let pos: [number, number, number] = [cx, y, cz - d / 2];
  if (side === "south") { geom = [w, WALL_HEIGHT, t]; pos = [cx, y, cz + d / 2]; }
  if (side === "east") { geom = [t, WALL_HEIGHT, d]; pos = [cx + w / 2, y, cz]; }
  if (side === "west") { geom = [t, WALL_HEIGHT, d]; pos = [cx - w / 2, y, cz]; }

  // door gap: split into two segments if hasDoor and wall is long enough
  const segments = useMemo(() => {
    if (!hasDoor) return [{ offset: 0, length: 1 }];
    if (side === "north" || side === "south") {
      const half = w / 2;
      const gap = Math.min(DOOR_GAP, w * 0.4);
      const segLen = (w - gap) / 2;
      return [
        { offset: -half + segLen / 2, length: segLen / w },
        { offset: half - segLen / 2, length: segLen / w },
      ];
    } else {
      const half = d / 2;
      const gap = Math.min(DOOR_GAP, d * 0.4);
      const segLen = (d - gap) / 2;
      return [
        { offset: -half + segLen / 2, length: segLen / d },
        { offset: half - segLen / 2, length: segLen / d },
      ];
    }
  }, [hasDoor, side, w, d]);

  return (
    <group>
      {segments.map((s, i) => {
        if (side === "north" || side === "south") {
          const segW = s.length * w;
          return (
            <group key={i}>
              <mesh position={[cx + s.offset, y, pos[2]]} castShadow receiveShadow>
                <boxGeometry args={[segW, WALL_HEIGHT, t]} />
                <meshStandardMaterial color={color} roughness={0.95} />
              </mesh>
            </group>
          );
        } else {
          const segD = s.length * d;
          return (
            <mesh key={i} position={[pos[0], y, cz + s.offset]} castShadow receiveShadow>
              <boxGeometry args={[t, WALL_HEIGHT, segD]} />
              <meshStandardMaterial color={color} roughness={0.95} />
            </mesh>
          );
        }
      })}
      {/* window */}
      {hasWindow && (side === "north" || side === "east") && (
        <mesh position={[
          side === "north" ? cx : pos[0],
          y + 0.6,
          side === "north" ? pos[2] : cz,
        ]}>
          <boxGeometry args={[
            side === "north" ? WIN_W : t,
            WIN_H,
            side === "north" ? t : WIN_W,
          ]} />
          <meshStandardMaterial color="#cfe4ee" metalness={0.3} roughness={0.1} transparent opacity={0.55} />
        </mesh>
      )}
    </group>
  );
}

function Roof({ yTop, buildX, buildZ, buildW, buildD, color }: {
  yTop: number; buildX: number; buildZ: number; buildW: number; buildD: number; color: string;
}) {
  return (
    <group>
      {/* flat slab roof + parapet */}
      <mesh position={[buildX + buildW / 2, yTop + 0.3, buildZ + buildD / 2]} castShadow receiveShadow>
        <boxGeometry args={[buildW, 0.6, buildD]} />
        <meshStandardMaterial color={color} roughness={0.9} />
      </mesh>
      {/* parapet */}
      <Parapet x={buildX} z={buildZ} w={buildW} d={buildD} y={yTop + 0.9} />
      {/* water tank */}
      <mesh position={[buildX + buildW - 3, yTop + 1.8, buildZ + 3]} castShadow>
        <cylinderGeometry args={[1.4, 1.4, 2.2, 16]} />
        <meshStandardMaterial color="#8aa0b0" roughness={0.7} />
      </mesh>
      <mesh position={[buildX + buildW - 3, yTop + 2.9, buildZ + 3]} castShadow>
        <cylinderGeometry args={[1.45, 1.45, 0.2, 16]} />
        <meshStandardMaterial color="#5a6770" roughness={0.6} />
      </mesh>
    </group>
  );
}

function Parapet({ x, z, w, d, y }: { x: number; z: number; w: number; d: number; y: number }) {
  const t = 0.3;
  const h = 1;
  return (
    <group>
      <mesh position={[x + w / 2, y, z - t / 2]} castShadow>
        <boxGeometry args={[w, h, t]} /><meshStandardMaterial color="#d8cdb6" />
      </mesh>
      <mesh position={[x + w / 2, y, z + d + t / 2 - t]} castShadow>
        <boxGeometry args={[w, h, t]} /><meshStandardMaterial color="#d8cdb6" />
      </mesh>
      <mesh position={[x - t / 2, y, z + d / 2]} castShadow>
        <boxGeometry args={[t, h, d]} /><meshStandardMaterial color="#d8cdb6" />
      </mesh>
      <mesh position={[x + w - t / 2 + t, y, z + d / 2]} castShadow>
        <boxGeometry args={[t, h, d]} /><meshStandardMaterial color="#d8cdb6" />
      </mesh>
    </group>
  );
}

function BedGroup({ x, z, y }: { x: number; z: number; y: number }) {
  return (
    <group position={[x, y, z]}>
      <mesh position={[0, 0.6, 0]} castShadow>
        <boxGeometry args={[4.5, 0.6, 6]} />
        <meshStandardMaterial color="#b9a986" roughness={0.9} />
      </mesh>
      <mesh position={[0, 1.0, -2]} castShadow>
        <boxGeometry args={[4.5, 0.8, 0.6]} />
        <meshStandardMaterial color="#9a8560" roughness={0.9} />
      </mesh>
      <mesh position={[-1.3, 1.0, 2.4]} castShadow>
        <boxGeometry args={[1, 0.4, 1]} />
        <meshStandardMaterial color="#8a7a5a" />
      </mesh>
      <mesh position={[1.3, 1.0, 2.4]} castShadow>
        <boxGeometry args={[1, 0.4, 1]} />
        <meshStandardMaterial color="#8a7a5a" />
      </mesh>
    </group>
  );
}

function SofaGroup({ x, z, y, color }: { x: number; z: number; y: number; color: string }) {
  return (
    <group position={[x, y, z]}>
      <mesh position={[0, 0.5, 0]} castShadow>
        <boxGeometry args={[6, 0.8, 2.2]} />
        <meshStandardMaterial color={color} roughness={0.95} />
      </mesh>
      <mesh position={[0, 1.1, -1]} castShadow>
        <boxGeometry args={[6, 1.2, 0.5]} />
        <meshStandardMaterial color={color} roughness={0.95} />
      </mesh>
    </group>
  );
}
