"use client";

import { useEffect, useMemo, useState } from "react";
import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FloorPlanCanvas } from "@/components/buildvision/floorplan/floor-plan-canvas";
import { generateStructure, roomArea } from "@/lib/geometry";
import { FileStack, AlertTriangle, Ruler, Boxes, Layers, HardHat, ArrowRight, RefreshCw } from "lucide-react";

export function StructureView() {
  const plot = useAppStore((s) => s.plot);
  const floorPlan = useAppStore((s) => s.floorPlan);
  const vastu = useAppStore((s) => s.vastu);
  const structure = useAppStore((s) => s.structure);
  const regenerate = useAppStore((s) => s.regenerate);
  const setView = useAppStore((s) => s.setView);
  const [activeFloor, setActiveFloor] = useState(0);
  const [showStruct, setShowStruct] = useState(true);

  useEffect(() => { if (!floorPlan) regenerate(); }, [floorPlan, regenerate]);

  const struct = useMemo(() => {
    if (!floorPlan) return structure;
    return generateStructure(plot, floorPlan);
  }, [plot, floorPlan, structure]);

  if (!floorPlan) return <div className="p-8">Generating…</div>;

  const totalBuilt = floorPlan.rooms.reduce((a, r) => a + roomArea(r), 0);
  const approxConcrete = (totalBuilt * plot.floors * 0.13).toFixed(1); // m³ rough
  const approxSteel = (Number(approxConcrete) * 78).toFixed(0); // kg rough

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-[1fr_360px] gap-6">
        <div className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="text-base flex items-center gap-2"><FileStack className="w-4 h-4 text-primary" /> Structural Grid Overlay</CardTitle>
                <CardDescription>Columns & beams over architectural plan — separate but coordinated.</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button size="sm" variant={showStruct ? "secondary" : "outline"} onClick={() => setShowStruct(!showStruct)}>
                  {showStruct ? "Hide grid" : "Show grid"}
                </Button>
                <Button size="sm" variant="outline" onClick={() => regenerate()} className="gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5" /> Recompute
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <FloorPlanCanvas floorPlan={floorPlan} vastu={vastu} activeFloor={activeFloor} showVastu={false} />
                {showStruct && <StructOverlay struct={struct} plot={plot} activeFloor={activeFloor} />}
              </div>
              {floorPlan.floors > 1 && (
                <div className="flex gap-1.5 mt-3">
                  {Array.from({ length: floorPlan.floors }).map((_, f) => (
                    <button key={f} onClick={() => setActiveFloor(f)}
                      className={`px-3 py-1 rounded-md text-xs border ${
                        activeFloor === f ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-muted"
                      }`}>Level {f + 1}</button>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="grid sm:grid-cols-3 gap-3">
            <StatCard icon={Boxes} label="Columns" value={`${struct.columns.length}`} sub="preliminary grid" />
            <StatCard icon={Layers} label="Beams" value={`${struct.beams.length}`} sub="grid lines" />
            <StatCard icon={Ruler} label="Slab" value={`${struct.slabThicknessMm}`} sub="mm thick" />
          </div>
        </div>

        <div className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Preliminary Quantity Estimate</CardTitle>
              <CardDescription>Rough indicative values only.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2.5 text-sm">
              <Row label="Built-up area" value={`${Math.round(totalBuilt * plot.floors).toLocaleString()} sq ${plot.unit}`} />
              <Row label="Concrete (est.)" value={`${approxConcrete} m³`} />
              <Row label="Steel (est.)" value={`${approxSteel} kg`} />
              <Row label="Floors" value={`${plot.floors}`} />
              <Row label="Foundation" value={struct.columns.length > 0 ? "Isolated (prelim.)" : "—"} />
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Structural Members</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {[
                { l: "Columns", n: struct.columns.length, d: "Preliminary grid positions" },
                { l: "Plinth beams", n: Math.round(struct.beams.length / 2), d: "Tie beams at plinth level" },
                { l: "Roof beams", n: Math.round(struct.beams.length / 2), d: "Along grid lines" },
                { l: "RC slab", n: struct.slabThicknessMm, d: "mm — typical two-way" },
                { l: "Lintels", n: "above openings", d: "Doors & windows" },
                { l: "Staircase", n: plot.floors > 1 ? 1 : 0, d: "Dog-legged (typ.)" },
              ].map((m) => (
                <div key={m.l} className="flex items-center justify-between text-xs">
                  <div>
                    <p className="font-medium">{m.l}</p>
                    <p className="text-muted-foreground">{m.d}</p>
                  </div>
                  <Badge variant="outline" className="text-[10px]">{m.n}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-destructive/30 bg-destructive/5">
            <CardContent className="p-3 flex gap-2">
              <HardHat className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
              <p className="text-[11px] text-muted-foreground">
                AI-generated structural layouts are <strong>not</strong> certified construction designs. Final member sizing, reinforcement, connections, foundations & safety checks must be completed or approved by a qualified structural engineer per applicable codes.
              </p>
            </CardContent>
          </Card>

          <Button className="w-full gap-1.5" onClick={() => setView("exports")}>
            Continue to export & share <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, sub }: { icon: any; label: string; value: string; sub: string }) {
  return (
    <Card className="border-border/60">
      <CardContent className="p-4 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary grid place-items-center">
          <Icon className="w-4 h-4" />
        </div>
        <div>
          <p className="text-lg font-semibold leading-none">{value}</p>
          <p className="text-[10px] text-muted-foreground mt-1">{label} · {sub}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

function StructOverlay({ struct, plot, activeFloor }: { struct: any; plot: any; activeFloor: number }) {
  // SVG overlay aligned to FloorPlanCanvas (same coordinate mapping)
  const pad = 44, vw = 760, vh = 560;
  const sc = Math.min((vw - pad * 2) / plot.width, (vh - pad * 2) / plot.length);
  const OX = (vw - plot.width * sc) / 2;
  const OY = (vh - plot.length * sc) / 2;
  return (
    <svg viewBox={`0 0 ${vw} ${vh}`} className="absolute inset-0 w-full h-full pointer-events-none">
      {struct.columns.map((c: any, i: number) => (
        <rect key={`c${i}`} x={OX + c.x * sc - 3} y={OY + c.z * sc - 3} width={6} height={6}
          fill="oklch(0.55 0.2 250)" stroke="white" strokeWidth={1} />
      ))}
      {struct.beams.map((b: any, i: number) => {
        if (b.axis === "x") {
          return <line key={`bx${i}`} x1={OX + b.x * sc} y1={OY + b.z * sc} x2={OX + (b.x + b.length) * sc} y2={OY + b.z * sc}
            stroke="oklch(0.4 0.18 250 / 0.6)" strokeWidth={2} strokeDasharray="3 3" />;
        }
        return <line key={`bz${i}`} x1={OX + b.x * sc} y1={OY + b.z * sc} x2={OX + b.x * sc} y2={OY + (b.z + b.length) * sc}
          stroke="oklch(0.4 0.18 250 / 0.6)" strokeWidth={2} strokeDasharray="3 3" />;
      })}
      <text x={vw - 110} y={20} className="fill-foreground" style={{ fontSize: 9, fontWeight: 600 }}>
        ▣ column  ┄ beam
      </text>
    </svg>
  );
}
