"use client";

import { useEffect, useMemo } from "react";
import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, Ruler, MapPin, Building2, Car, Trees, Compass, AlertTriangle } from "lucide-react";
import type { PlotConfig, RoadDirection, PlotShape, Unit } from "@/lib/types";

const ROAD_OPTS: { v: RoadDirection; label: string }[] = [
  { v: "N", label: "North" }, { v: "NE", label: "North-East" }, { v: "E", label: "East" },
  { v: "SE", label: "South-East" }, { v: "S", label: "South" }, { v: "SW", label: "South-West" },
  { v: "W", label: "West" }, { v: "NW", label: "North-West" },
];

const SHAPES: { v: PlotShape; label: string }[] = [
  { v: "rectangle", label: "Rectangle" }, { v: "square", label: "Square" },
  { v: "lshape", label: "L-Shape" }, { v: "irregular", label: "Irregular" },
];

export function PlotInputView() {
  const plot = useAppStore((s) => s.plot);
  const setPlot = useAppStore((s) => s.setPlot);
  const recomputePlot = useAppStore((s) => s.recomputePlot);
  const regenerate = useAppStore((s) => s.regenerate);
  const setView = useAppStore((s) => s.setView);

  useEffect(() => {
    recomputePlot();
  }, [plot.length, plot.width, plot.shape, plot.setbackFront, plot.setbackRear, plot.setbackSides, recomputePlot]);

  const fits = useMemo(() => plot.buildableArea > 0 && plot.buildableArea < plot.plotArea, [plot]);

  function update<K extends keyof PlotConfig>(k: K, v: PlotConfig[K]) {
    setPlot({ [k]: v } as Partial<PlotConfig>);
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-[1fr_1.1fr] gap-6">
        {/* Form */}
        <div className="space-y-6">
          <Tabs defaultValue="dimensions">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="dimensions" className="gap-1.5"><Ruler className="w-3.5 h-3.5" />Dimensions</TabsTrigger>
              <TabsTrigger value="site" className="gap-1.5"><MapPin className="w-3.5 h-3.5" />Site</TabsTrigger>
              <TabsTrigger value="regulations" className="gap-1.5"><Building2 className="w-3.5 h-3.5" />Setbacks</TabsTrigger>
            </TabsList>

            <TabsContent value="dimensions" className="space-y-5">
              <Card className="border-border/60">
                <CardContent className="p-5 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Length (along road depth)</Label>
                      <Input type="number" min={1} value={plot.length}
                        onChange={(e) => update("length", Number(e.target.value))} />
                    </div>
                    <div className="space-y-2">
                      <Label>Width</Label>
                      <Input type="number" min={1} value={plot.width}
                        onChange={(e) => update("width", Number(e.target.value))} />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Unit</Label>
                      <Select value={plot.unit} onValueChange={(v: Unit) => update("unit", v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ft">Feet (ft)</SelectItem>
                          <SelectItem value="m">Metres (m)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Plot shape</Label>
                      <Select value={plot.shape} onValueChange={(v: PlotShape) => update("shape", v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {SHAPES.map((s) => <SelectItem key={s.v} value={s.v}>{s.label}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Number of floors</Label>
                      <div className="flex items-center gap-3">
                        <Slider value={[plot.floors]} min={1} max={5} step={1}
                          onValueChange={(v) => update("floors", v[0])} className="flex-1" />
                        <span className="w-8 text-center font-medium">{plot.floors}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Road-facing direction</Label>
                      <Select value={plot.roadDirection} onValueChange={(v: RoadDirection) => update("roadDirection", v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {ROAD_OPTS.map((r) => <SelectItem key={r.v} value={r.v}>{r.label}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-3 grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-xs text-muted-foreground">Plot area</p>
                      <p className="font-semibold">{Math.round(plot.plotArea).toLocaleString()} sq {plot.unit}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Buildable area</p>
                      <p className="font-semibold">{Math.round(plot.buildableArea).toLocaleString()} sq {plot.unit}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="site" className="space-y-4">
              <Card className="border-border/60">
                <CardContent className="p-5 space-y-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Car className="w-4 h-4 text-primary" />
                      <div>
                        <p className="text-sm font-medium">Parking</p>
                        <p className="text-xs text-muted-foreground">Reserve covered parking at front</p>
                      </div>
                    </div>
                    <Switch checked={plot.parking} onCheckedChange={(v) => update("parking", v)} />
                  </div>
                  {plot.parking && (
                    <div className="space-y-2">
                      <Label>Required parking area (sq {plot.unit})</Label>
                      <Input type="number" min={0} value={plot.parkingArea}
                        onChange={(e) => update("parkingArea", Number(e.target.value))} />
                    </div>
                  )}
                  <div className="h-px bg-border" />
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Trees className="w-4 h-4 text-primary" />
                      <div>
                        <p className="text-sm font-medium">Garden / open space</p>
                        <p className="text-xs text-muted-foreground">Reserve rear garden strip</p>
                      </div>
                    </div>
                    <Switch checked={plot.garden} onCheckedChange={(v) => update("garden", v)} />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="regulations" className="space-y-4">
              <Card className="border-border/60">
                <CardContent className="p-5 space-y-4">
                  <div className="space-y-2">
                    <Label>Front setback (road side)</Label>
                    <Input type="number" min={0} value={plot.setbackFront}
                      onChange={(e) => update("setbackFront", Number(e.target.value))} />
                  </div>
                  <div className="space-y-2">
                    <Label>Rear setback</Label>
                    <Input type="number" min={0} value={plot.setbackRear}
                      onChange={(e) => update("setbackRear", Number(e.target.value))} />
                  </div>
                  <div className="space-y-2">
                    <Label>Side setbacks (each side)</Label>
                    <Input type="number" min={0} value={plot.setbackSides}
                      onChange={(e) => update("setbackSides", Number(e.target.value))} />
                  </div>
                  <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-3 flex gap-2">
                    <AlertTriangle className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                    <p className="text-xs text-muted-foreground">
                      Setbacks must follow local building regulations. Confirm with your local authority.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Live preview */}
        <div className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Compass className="w-4 h-4 text-primary" /> Plot Preview
                  </CardTitle>
                  <CardDescription>Live boundary & buildable footprint</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <PlotPreview plot={plot} />
            </CardContent>
          </Card>

          <div className="grid grid-cols-3 gap-3">
            <Stat label="Plot area" value={`${Math.round(plot.plotArea).toLocaleString()}`} unit={`sq ${plot.unit}`} />
            <Stat label="Buildable" value={`${Math.round(plot.buildableArea).toLocaleString()}`} unit={`sq ${plot.unit}`} />
            <Stat label="Floors" value={`${plot.floors}`} unit="storey" />
          </div>

          {fits ? (
            <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm flex items-start gap-2">
              <Compass className="w-4 h-4 text-primary shrink-0 mt-0.5" />
              <p className="text-muted-foreground">
                Buildable footprint fits within plot boundary. Continue to generate AI design concepts.
              </p>
            </div>
          ) : (
            <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
              <p className="text-muted-foreground">
                Setbacks exceed plot dimensions. Reduce setbacks or plot size.
              </p>
            </div>
          )}

          <div className="flex gap-3">
            <Button className="flex-1 gap-1.5" onClick={() => { regenerate(); setView("design"); }}>
              Generate AI designs <ArrowRight className="w-4 h-4" />
            </Button>
            <Button variant="outline" onClick={() => { regenerate(); setView("floorplan"); }}>
              View floor plan
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, unit }: { label: string; value: string; unit: string }) {
  return (
    <div className="rounded-lg border border-border/60 bg-card p-3">
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="text-lg font-semibold leading-tight">{value}</p>
      <p className="text-[10px] text-muted-foreground">{unit}</p>
    </div>
  );
}

function PlotPreview({ plot }: { plot: PlotConfig }) {
  // SVG, plot drawn with road at top
  const pad = 28;
  const vw = 360;
  const vh = 320;
  const scale = Math.min((vw - pad * 2) / plot.width, (vh - pad * 2) / plot.length);
  const pw = plot.width * scale;
  const ph = plot.length * scale;
  const ox = (vw - pw) / 2;
  const oy = (vh - ph) / 2;
  const sf = plot.setbackFront * scale;
  const sr = plot.setbackRear * scale;
  const ss = plot.setbackSides * scale;
  const bx = ox + ss;
  const by = oy + sf;
  const bw = pw - ss * 2;
  const bd = ph - sf - sr;

  return (
    <svg viewBox={`0 0 ${vw} ${vh}`} className="w-full h-auto bv-blueprint-grid rounded-lg border border-border/60">
      {/* plot boundary */}
      {plot.shape === "lshape" ? (
        <path d={`M ${ox} ${oy} L ${ox + pw} ${oy} L ${ox + pw} ${oy + ph * 0.55} L ${ox + pw * 0.55} ${oy + ph * 0.55} L ${ox + pw * 0.55} ${oy + ph} L ${ox} ${oy + ph} Z`}
          fill="oklch(0.9 0.03 70)" stroke="oklch(0.5 0.04 50)" strokeWidth={2} />
      ) : (
        <rect x={ox} y={oy} width={pw} height={ph} rx={2}
          fill="oklch(0.9 0.03 70)" stroke="oklch(0.5 0.04 50)" strokeWidth={2} />
      )}
      {/* buildable */}
      {bw > 0 && bd > 0 && (
        <rect x={bx} y={by} width={bw} height={bd} rx={1}
          fill="oklch(0.62 0.13 45 / 0.18)" stroke="oklch(0.62 0.13 45)" strokeWidth={1.5} strokeDasharray="4 3" />
      )}
      {/* parking reserve if on */}
      {plot.parking && bw > 0 && (
        <rect x={bx} y={by} width={bw} height={Math.min(plot.parkingArea / plot.width, plot.length * 0.4) * scale}
          fill="oklch(0.5 0.05 250 / 0.12)" stroke="oklch(0.5 0.05 250)" strokeWidth={1} strokeDasharray="2 2" />
      )}
      {/* garden reserve */}
      {plot.garden && bw > 0 && (
        <rect x={bx} y={by + bd - Math.min(plot.length * 0.18, 10) * scale} width={bw} height={Math.min(plot.length * 0.18, 10) * scale}
          fill="oklch(0.6 0.08 140 / 0.18)" stroke="oklch(0.5 0.1 140)" strokeWidth={1} strokeDasharray="2 2" />
      )}
      {/* road */}
      <line x1={ox - 6} y1={oy} x2={ox + pw + 6} y2={oy} stroke="oklch(0.4 0 0)" strokeWidth={6} strokeLinecap="round" opacity={0.4} />
      <text x={vw / 2} y={oy - 12} textAnchor="middle" className="fill-muted-foreground" style={{ fontSize: 10, fontWeight: 600 }}>
        ROAD · {roadLabel(plot.roadDirection)}
      </text>
      {/* dims */}
      <text x={ox + pw / 2} y={vh - 6} textAnchor="middle" className="fill-foreground" style={{ fontSize: 10 }}>
        Width {plot.width} {plot.unit}
      </text>
      <text x={6} y={oy + ph / 2} textAnchor="middle" transform={`rotate(-90 12 ${oy + ph / 2})`} className="fill-foreground" style={{ fontSize: 10 }}>
        Length {plot.length} {plot.unit}
      </text>
      {/* compass */}
      <g transform={`translate(${vw - 28} 28)`}>
        <circle r={14} fill="white" stroke="oklch(0.5 0.04 50)" strokeWidth={1} />
        <polygon points="0,-10 4,2 0,-2 -4,2" fill="oklch(0.6 0.13 45)" />
        <polygon points="0,10 4,-2 0,2 -4,-2" fill="oklch(0.5 0.02 50)" />
        <text y={-16} textAnchor="middle" style={{ fontSize: 8, fontWeight: 700 }} className="fill-foreground">N</text>
      </g>
    </svg>
  );
}

function roadLabel(d: RoadDirection) {
  return ROAD_OPTS.find((r) => r.v === d)?.label ?? d;
}
