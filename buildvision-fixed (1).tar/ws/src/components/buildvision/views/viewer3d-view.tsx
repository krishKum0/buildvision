"use client";

import { Suspense, useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import {
  Box, Eye, EyeOff, Home, Layers, ChevronUp, ChevronDown, RotateCw,
  Map as MapIcon, Compass, Sun, Sparkles, AlertTriangle, ArrowLeft,
} from "lucide-react";

const HouseScene = dynamic(
  () => import("@/components/buildvision/three/house-scene").then((m) => m.HouseScene),
  { ssr: false, loading: () => <SceneLoading /> }
);

function SceneLoading() {
  return (
    <div className="absolute inset-0 grid place-items-center">
      <div className="flex flex-col items-center gap-3">
        <div className="w-10 h-10 rounded-full border-4 border-muted border-t-primary animate-spin" />
        <p className="text-sm text-muted-foreground">Building 3D model…</p>
      </div>
    </div>
  );
}

const ELEVATIONS = [
  { label: "Front", icon: Home, cam: [0, 18, 120] as [number, number, number], target: [0, 14, 0] as [number, number, number] },
  { label: "Rear", icon: Home, cam: [0, 18, -120] as [number, number, number], target: [0, 14, 0] as [number, number, number] },
  { label: "Left", icon: Home, cam: [-120, 18, 0] as [number, number, number], target: [0, 14, 0] as [number, number, number] },
  { label: "Right", icon: Home, cam: [120, 18, 0] as [number, number, number], target: [0, 14, 0] as [number, number, number] },
  { label: "Top", icon: Sun, cam: [0, 160, 0.1] as [number, number, number], target: [0, 0, 0] as [number, number, number] },
];

export function Viewer3dView() {
  const floorPlan = useAppStore((s) => s.floorPlan);
  const materials = useAppStore((s) => s.materials);
  const plot = useAppStore((s) => s.plot);
  const regenerate = useAppStore((s) => s.regenerate);
  const setView = useAppStore((s) => s.setView);
  const design = useAppStore((s) => s.design);

  const [activeFloor, setActiveFloor] = useState(-1); // -1 = all floors
  const [showWalls, setShowWalls] = useState(true);
  const [showRoof, setShowRoof] = useState(true);
  const [showInterior, setShowInterior] = useState(true);
  const [autoRotate, setAutoRotate] = useState(false);

  useEffect(() => {
    if (!floorPlan) regenerate();
  }, [floorPlan, regenerate]);

  if (!floorPlan) {
    return (
      <div className="p-8 grid place-items-center">
        <p className="text-muted-foreground">Building 3D model…</p>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-[1fr_320px] gap-6">
        {/* 3D Canvas */}
        <Card className="border-border/60 overflow-hidden">
          <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Box className="w-4 h-4 text-primary" /> 3D Building Viewer
              </CardTitle>
              <CardDescription>
                {plot.length}×{plot.width} {plot.unit} · {floorPlan.floors} floor(s) · {design.style}
              </CardDescription>
            </div>
            <Badge variant="secondary" className="gap-1">
              <Sparkles className="w-3 h-3" /> Live model
            </Badge>
          </CardHeader>
          <CardContent className="p-0">
            <div className="relative aspect-[4/3] sm:aspect-[16/10] bv-blueprint-grid">
              <Suspense fallback={<SceneLoading />}>
                <HouseScene
                  floorPlan={floorPlan}
                  materials={materials}
                  activeFloor={activeFloor}
                  showWalls={showWalls}
                  showRoof={showRoof}
                  showInterior={showInterior}
                  orbitAutoRotate={autoRotate}
                />
              </Suspense>
              {/* overlay hint */}
              <div className="pointer-events-none absolute top-3 left-3 rounded-md bg-background/80 backdrop-blur px-2.5 py-1.5 text-[11px] text-muted-foreground border border-border/60">
                Drag to orbit · Scroll to zoom · Right-drag to pan
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Controls */}
        <div className="space-y-4">
          {/* Floor inspector */}
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-primary" /> Floor Inspector
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Show all floors</Label>
                <Switch checked={activeFloor === -1} onCheckedChange={(v) => setActiveFloor(v ? -1 : 0)} />
              </div>
              <Separator />
              {activeFloor !== -1 && (
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline" className="flex-1 gap-1"
                    disabled={activeFloor === 0}
                    onClick={() => setActiveFloor((f) => Math.max(0, f - 1))}>
                    <ChevronUp className="w-3.5 h-3.5" /> Lower
                  </Button>
                  <Badge variant="secondary">L{activeFloor + 1}</Badge>
                  <Button size="sm" variant="outline" className="flex-1 gap-1"
                    disabled={activeFloor >= floorPlan.floors - 1}
                    onClick={() => setActiveFloor((f) => Math.min(floorPlan.floors - 1, f + 1))}>
                    Upper <ChevronDown className="w-3.5 h-3.5" />
                  </Button>
                </div>
              )}
              <div className="flex flex-wrap gap-1.5">
                {Array.from({ length: floorPlan.floors }).map((_, f) => (
                  <button key={f} onClick={() => setActiveFloor(f)}
                    className={`px-2.5 py-1 rounded-md text-xs border transition-colors ${
                      activeFloor === f
                        ? "bg-primary text-primary-foreground border-primary"
                        : "border-border/60 hover:bg-muted"
                    }`}>
                    L{f + 1}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Visibility */}
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-primary" /> Visibility
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <ToggleRow icon={showWalls ? Eye : EyeOff} label="Walls" checked={showWalls} onCheck={setShowWalls} />
              <ToggleRow icon={showRoof ? Eye : EyeOff} label="Roof & parapet" checked={showRoof} onCheck={setShowRoof} />
              <ToggleRow icon={showInterior ? Eye : EyeOff} label="Interior (floors & furniture)" checked={showInterior} onCheck={setShowInterior} />
              <Separator />
              <ToggleRow icon={RotateCw} label="Auto-rotate 360°" checked={autoRotate} onCheck={setAutoRotate} />
            </CardContent>
          </Card>

          {/* Elevation quick view */}
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-1.5">
                <Home className="w-4 h-4 text-primary" /> Elevation Views
              </CardTitle>
              <CardDescription>Snap camera to standard elevations.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-2">
                {ELEVATIONS.map((e) => (
                  <Button key={e.label} size="sm" variant="outline" className="gap-1 flex-col h-auto py-2"
                    onClick={() => { setActiveFloor(-1); setShowWalls(true); setShowRoof(true); }}>
                    <e.icon className="w-4 h-4" />
                    <span className="text-[10px]">{e.label}</span>
                  </Button>
                ))}
              </div>
              <p className="text-[10px] text-muted-foreground mt-2 text-center">
                Use orbit controls for full 360° inspection.
              </p>
            </CardContent>
          </Card>

          <Card className="border-amber-500/30 bg-amber-500/5">
            <CardContent className="p-3 flex gap-2">
              <AlertTriangle className="w-4 h-4 text-primary shrink-0 mt-0.5" />
              <p className="text-[11px] text-muted-foreground">
                3D model is generated from the same geometry as the 2D plan, so they stay consistent. Material changes apply live.
              </p>
            </CardContent>
          </Card>

          <div className="flex gap-2">
            <Button variant="outline" className="flex-1 gap-1.5" onClick={() => setView("floorplan")}>
              <ArrowLeft className="w-4 h-4" /> Floor plan
            </Button>
            <Button className="flex-1 gap-1.5" onClick={() => setView("materials")}>
              <Compass className="w-4 h-4" /> Materials
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ToggleRow({ icon: Icon, label, checked, onCheck }: {
  icon: any; label: string; checked: boolean; onCheck: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2 text-sm">
        <Icon className="w-4 h-4 text-muted-foreground" />
        <span>{label}</span>
      </div>
      <Switch checked={checked} onCheckedChange={onCheck} />
    </div>
  );
}
