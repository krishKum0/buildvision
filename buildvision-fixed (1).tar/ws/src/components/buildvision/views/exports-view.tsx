"use client";

import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Download, FileText, Image as ImageIcon, Box, FileSpreadsheet, Share2, Package,
  AlertTriangle, HardHat, FileJson, ArrowRight, Send,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { roomArea } from "@/lib/geometry";

export function ExportsView() {
  const project = useAppStore((s) => s.project);
  const plot = useAppStore((s) => s.plot);
  const design = useAppStore((s) => s.design);
  const floorPlan = useAppStore((s) => s.floorPlan);
  const vastu = useAppStore((s) => s.vastu);
  const materials = useAppStore((s) => s.materials);
  const soil = useAppStore((s) => s.soil);
  const structure = useAppStore((s) => s.structure);
  const setView = useAppStore((s) => s.setView);

  if (!floorPlan) {
    return (
      <div className="p-8 max-w-3xl mx-auto">
        <Card className="border-dashed">
          <CardContent className="p-10 text-center space-y-3">
            <Download className="w-10 h-10 text-primary mx-auto" />
            <p className="font-medium">No design to export</p>
            <Button onClick={() => setView("design")} className="gap-1.5">Generate a design</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  function downloadJSON() {
    const pkg = { project, plot, design, floorPlan, vastu, materials, soil, structure,
      disclaimer: "Conceptual / preliminary — not certified for construction." };
    const blob = new Blob([JSON.stringify(pkg, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project?.name ?? "buildvision"}-project.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Project JSON exported" });
  }

  function downloadSummary() {
    const totalBuilt = floorPlan!.rooms.reduce((a, r) => a + roomArea(r), 0);
    const lines = [
      "AI BuildVision 360° — Project Summary",
      "======================================",
      `Project: ${project?.name ?? "Untitled"}`,
      `Status: ${project?.status ?? "draft"}`,
      `Generated: ${new Date().toLocaleString()}`,
      "",
      "PLOT",
      `  Shape: ${plot.shape}`,
      `  Dimensions: ${plot.length} × ${plot.width} ${plot.unit}`,
      `  Plot area: ${Math.round(plot.plotArea).toLocaleString()} sq ${plot.unit}`,
      `  Buildable area: ${Math.round(plot.buildableArea).toLocaleString()} sq ${plot.unit}`,
      `  Road facing: ${plot.roadDirection}`,
      `  Floors: ${plot.floors}`,
      `  Parking: ${plot.parking ? "Yes" : "No"} · Garden: ${plot.garden ? "Yes" : "No"}`,
      "",
      "DESIGN",
      `  Style: ${design.style}`,
      `  Roof: ${design.roof}`,
      `  Palette: ${design.palette}`,
      `  Seed: ${design.designSeed}`,
      "",
      "FLOOR PLAN",
      `  Floors: ${floorPlan!.floors}`,
      `  Total rooms: ${floorPlan!.rooms.length}`,
      `  Built area: ${Math.round(totalBuilt).toLocaleString()} sq ${plot.unit}`,
      ...floorPlan!.rooms.map((r) => `  - ${r.label}: ${r.w}×${r.d} ${floorPlan!.unit} (${r.vastu ?? "-"})`),
      "",
      "VASTU",
      `  Enabled: ${vastu.enabled}`,
      "",
      "MATERIALS",
      `  Walls: ${materials.walls} · Exterior: ${materials.exteriorPaint}`,
      `  Floor tile: ${materials.floorTile} · Bedroom: ${materials.bedroomFloor}`,
      `  Kitchen: ${materials.kitchenCabinet} · Bath: ${materials.bathroomTile}`,
      "",
      "SOIL & FOUNDATION",
      `  Report: ${soil.hasReport ? "Yes" : "No"}`,
      `  Bearing: ${soil.bearingCapacityKPa} kPa · Water table: ${soil.waterTableDepth} m`,
      `  Foundation: ${soil.foundationType || "—"}`,
      "",
      "STRUCTURE",
      `  Columns: ${structure.columns.length} · Beams: ${structure.beams.length}`,
      `  Slab: ${structure.slabThicknessMm} mm`,
      "",
      "DISCLAIMER",
      "  AI-generated concepts. Final structural sizing, reinforcement,",
      "  foundations & safety checks must be approved by a qualified engineer.",
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project?.name ?? "buildvision"}-summary.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Summary exported", description: "Text file downloaded" });
  }

  function downloadSVG() {
    const svg = document.querySelector("svg.bv-blueprint-grid");
    if (!svg) {
      toast({ title: "Open floor plan first", description: "Go to Floor Plan to export the drawing", variant: "destructive" });
      setView("floorplan");
      return;
    }
    const data = new XMLSerializer().serializeToString(svg);
    const blob = new Blob([data], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project?.name ?? "buildvision"}-floorplan.svg`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Floor plan SVG exported" });
  }

  function share() {
    const text = `AI BuildVision 360° project: ${project?.name}\n${plot.length}×${plot.width} ${plot.unit} · ${floorPlan!.rooms.length} rooms · ${plot.floors} floor(s)`;
    if (navigator.share) {
      navigator.share({ title: "AI BuildVision 360°", text });
    } else {
      navigator.clipboard.writeText(text);
      toast({ title: "Copied to clipboard" });
    }
  }

  const EXPORTS = [
    { icon: FileText, title: "Floor plan (SVG)", desc: "Dimensioned 2D plan drawing", action: downloadSVG, fmt: "SVG", concept: false },
    { icon: FileText, title: "Project summary (TXT)", desc: "Full text report of plot, design & engineering", action: downloadSummary, fmt: "TXT", concept: true },
    { icon: FileJson, title: "Project data (JSON)", desc: "Complete machine-readable design package", action: downloadJSON, fmt: "JSON", concept: true },
    { icon: ImageIcon, title: "Design concept image", desc: "Pre-rendered elevation concept (JPG)", action: () => { window.open(design.palette === "terracotta-brown" ? "/concepts/modern-villa.jpg" : "/concepts/contemporary-glass.jpg", "_blank"); }, fmt: "JPG", concept: true },
    { icon: Package, title: "Material schedule", desc: "Colour & finish list", action: () => { const t = Object.entries(materials).map(([k, v]) => `${k}: ${v}`).join("\n"); const b = new Blob([t], { type: "text/plain" }); const u = URL.createObjectURL(b); const a = document.createElement("a"); a.href = u; a.download = "materials.txt"; a.click(); URL.revokeObjectURL(u); toast({ title: "Materials exported" }); }, fmt: "TXT", concept: true },
    { icon: Box, title: "3D model (GLB)", desc: "Interactive 3D building file", action: () => toast({ title: "GLB export", description: "Coming soon — use the 3D viewer to inspect live" }), fmt: "GLB", concept: true },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <Card className="border-border/60 bg-gradient-to-br from-primary/5 to-transparent">
        <CardContent className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold flex items-center gap-2"><Download className="w-5 h-5 text-primary" /> Export & Share</h2>
            <p className="text-sm text-muted-foreground mt-1">Download drawings & share project packages with your civil engineer.</p>
          </div>
          <Badge variant="secondary" className="capitalize gap-1">
            <AlertTriangle className="w-3 h-3" /> {project?.status ?? "draft"}
          </Badge>
        </CardContent>
      </Card>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {EXPORTS.map((e) => (
          <Card key={e.title} className="border-border/60 hover:shadow-md transition-shadow">
            <CardContent className="p-5 flex flex-col gap-3 h-full">
              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary grid place-items-center">
                  <e.icon className="w-5 h-5" />
                </div>
                <Badge variant="outline" className="text-[10px]">{e.fmt}</Badge>
              </div>
              <div>
                <p className="font-medium text-sm">{e.title}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{e.desc}</p>
              </div>
              {e.concept && (
                <p className="text-[10px] text-muted-foreground/80 bg-muted/40 rounded p-1.5">Conceptual / preliminary</p>
              )}
              <Button size="sm" variant="outline" className="mt-auto gap-1.5 w-full" onClick={e.action}>
                <Download className="w-3.5 h-3.5" /> Download
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border/60">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-1.5"><Share2 className="w-4 h-4 text-primary" /> Share with engineer</CardTitle>
          <CardDescription>Send a quick project brief to your civil engineer for review.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col sm:flex-row gap-3">
          <Button onClick={share} className="gap-1.5 flex-1"><Send className="w-4 h-4" /> Share project brief</Button>
          <Button variant="outline" onClick={() => setView("structure")} className="gap-1.5 flex-1">
            Open engineering package <ArrowRight className="w-4 h-4" />
          </Button>
        </CardContent>
      </Card>

      <Separator />

      <Card className="border-amber-500/30 bg-amber-500/5">
        <CardContent className="p-4 flex gap-3">
          <HardHat className="w-5 h-5 text-primary shrink-0 mt-0.5" />
          <div className="text-sm text-muted-foreground space-y-1">
            <p className="font-medium text-foreground">Construction readiness</p>
            <p>All construction-related exports are marked <strong>conceptual</strong> or <strong>preliminary</strong> until reviewed and approved by a qualified structural / geotechnical engineer. Do not use AI-generated layouts directly for construction.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
