"use client";

import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import { Compass, Ruler, Box, Sparkles, Loader2, Mail, Lock, User as UserIcon } from "lucide-react";

export function LoginView() {
  const setUser = useAppStore((s) => s.setUser);
  const setView = useAppStore((s) => s.setView);
  const [mode, setMode] = useState<"login" | "register">("login");
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "homeowner" });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const payload =
        mode === "login"
          ? { email: form.email, password: form.password }
          : { name: form.name, email: form.email, password: form.password, role: form.role };
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Error", description: data.error ?? "Failed", variant: "destructive" });
        return;
      }
      toast({ title: mode === "login" ? "Welcome back" : "Account created", description: data.user.name });
      setUser(data.user);
      setView("dashboard");
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  async function demoLogin() {
    setLoading(true);
    try {
      // try login first; if fails, register
      const email = "demo@buildvision360.ai";
      const password = "demo123";
      let res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      if (!res.ok) {
        res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: "Demo Designer", email, password, role: "homeowner" }),
        });
      }
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Error", description: data.error, variant: "destructive" });
        return;
      }
      setUser(data.user);
      setView("dashboard");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <main className="flex-1 grid lg:grid-cols-2">
        {/* Brand / hero side */}
        <section className="relative hidden lg:flex flex-col justify-between p-10 overflow-hidden bv-grain"
          style={{ background: "linear-gradient(135deg, oklch(0.95 0.02 70), oklch(0.86 0.06 55))" }}>
          <div className="absolute inset-0 bv-blueprint-grid opacity-60" />
          <div className="relative">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-primary text-primary-foreground grid place-items-center shadow-lg">
                <Compass className="w-6 h-6" />
              </div>
              <div>
                <p className="font-semibold tracking-tight text-lg leading-none">AI BuildVision 360°</p>
                <p className="text-xs text-muted-foreground">Generative 3D House Design & Construction Planning</p>
              </div>
            </div>
          </div>

          <div className="relative space-y-6">
            <h1 className="text-4xl xl:text-5xl font-bold leading-tight tracking-tight text-foreground">
              Turn your plot dimensions into a <span className="text-primary">customisable 3D home</span>.
            </h1>
            <p className="text-muted-foreground text-lg max-w-md">
              AI-generated floor plans, interactive 360° building models, Vastu-aware zoning, material libraries,
              soil data and preliminary structural planning — in one digital workspace.
            </p>
            <div className="grid grid-cols-2 gap-3 max-w-md">
              {[
                { icon: Ruler, t: "Plot-driven generation" },
                { icon: Box, t: "360° 3D viewer" },
                { icon: Sparkles, t: "AI design concepts" },
                { icon: Compass, t: "Vastu planning" },
              ].map((f) => (
                <div key={f.t} className="flex items-center gap-2.5 rounded-lg bg-card/80 backdrop-blur p-3 border border-border/60">
                  <f.icon className="w-4 h-4 text-primary shrink-0" />
                  <span className="text-sm font-medium">{f.t}</span>
                </div>
              ))}
            </div>
          </div>

          <p className="relative text-xs text-muted-foreground/80 max-w-md">
            Concept designs are AI-generated and validated; qualified professionals verify engineering before construction.
          </p>
        </section>

        {/* Form side */}
        <section className="flex items-center justify-center p-6 sm:p-10">
          <Card className="w-full max-w-md border-border/60 shadow-xl">
            <CardHeader className="space-y-2">
              <div className="flex items-center gap-2 lg:hidden mb-2">
                <div className="w-9 h-9 rounded-lg bg-primary text-primary-foreground grid place-items-center">
                  <Compass className="w-5 h-5" />
                </div>
                <span className="font-semibold">AI BuildVision 360°</span>
              </div>
              <CardTitle className="text-2xl">Sign in to your workspace</CardTitle>
              <CardDescription>Access your saved projects, design history and exports.</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={mode} onValueChange={(v) => setMode(v as any)}>
                <TabsList className="grid grid-cols-2 mb-6">
                  <TabsTrigger value="login">Sign in</TabsTrigger>
                  <TabsTrigger value="register">Create account</TabsTrigger>
                </TabsList>

                <TabsContent value="login">
                  <form onSubmit={submit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input id="email" type="email" required placeholder="you@example.com"
                          className="pl-9" value={form.email}
                          onChange={(e) => setForm({ ...form, email: e.target.value })} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input id="password" type="password" required placeholder="••••••••"
                          className="pl-9" value={form.password}
                          onChange={(e) => setForm({ ...form, password: e.target.value })} />
                      </div>
                    </div>
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />} Sign in
                    </Button>
                  </form>
                </TabsContent>

                <TabsContent value="register">
                  <form onSubmit={submit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full name</Label>
                      <div className="relative">
                        <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input id="name" required placeholder="Your name" className="pl-9"
                          value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="remail">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input id="remail" type="email" required placeholder="you@example.com"
                          className="pl-9" value={form.email}
                          onChange={(e) => setForm({ ...form, email: e.target.value })} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="rpassword">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input id="rpassword" type="password" required minLength={6} placeholder="min 6 chars"
                          className="pl-9" value={form.password}
                          onChange={(e) => setForm({ ...form, password: e.target.value })} />
                      </div>
                    </div>
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />} Create account
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border/60" /></div>
                <div className="relative flex justify-center"><span className="bg-card px-3 text-xs text-muted-foreground">or</span></div>
              </div>
              <Button variant="outline" className="w-full" onClick={demoLogin} disabled={loading}>
                {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
                Continue with demo account
              </Button>
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  );
}
