"use client";

import { Suspense, useState } from "react";
import dynamic from "next/dynamic";
import { useAppStore, MATERIAL_PRESETS } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Palette, Box, CheckCircle2, Sun, Moon, Eye, ArrowRight } from "lucide-react";
import type { MaterialsConfig } from "@/lib/types";

const HouseScene = dynamic(
  () => import("@/components/buildvision/three/house-scene").then((m) => m.HouseScene),
  { ssr: false, loading: () => <div className="absolute inset-0 grid place-items-center text-sm text-muted-foreground">Loading preview…</div> }
);

const COLOR_FIELDS: { key: keyof MaterialsConfig; label: string; group: string }[] = [
  { key: "walls", label: "Interior walls", group: "Interior" },
  { key: "ceiling", label: "Ceiling", group: "Interior" },
  { key: "floorTile", label: "Floor tiles", group: "Interior" },
  { key: "bedroomFloor", label: "Bedroom flooring", group: "Interior" },
  { key: "kitchenCabinet", label: "Kitchen cabinets", group: "Interior" },
  { key: "bathroomTile", label: "Bathroom tiles", group: "Interior" },
  { key: "doorFinish", label: "Door finish", group: "Interior" },
  { key: "furniture", label: "Furniture", group: "Interior" },
  { key: "exteriorPaint", label: "Exterior paint", group: "Exterior" },
];

export function MaterialsView() {
  const materials = useAppStore((s) => s.materials);
  const setMaterials = useAppStore((s) => s.setMaterials);
  const applyPreset = useAppStore((s) => s.applyPreset);
  const floorPlan = useAppStore((s) => s.floorPlan);
  const setView = useAppStore((s) => s.setView);
  const [activePreset, setActivePreset] = useState<string | null>(null);

  function setColor(key: keyof MaterialsConfig, color: string) {
    setMaterials({ [key]: color } as Partial<MaterialsConfig>);
  }

  if (!floorPlan) {
    return (
      <div className="p-8 max-w-3xl mx-auto">
        <Card className="border-dashed">
          <CardContent className="p-10 text-center space-y-3">
            <Palette className="w-10 h-10 text-primary mx-auto" />
            <p className="font-medium">Generate a design first</p>
            <p className="text-sm text-muted-foreground">Material selection previews on your 3D model.</p>
            <Button onClick={() => setView("design")} className="gap-1.5"><Box className="w-4 h-4" /> Generate design</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-[1fr_380px] gap-6">
        {/* 3D preview */}
        <Card className="border-border/60 overflow-hidden">
          <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Box className="w-4 h-4 text-primary" /> Live 3D Material Preview
              </CardTitle>
              <CardDescription>Changes apply instantly to walls, floors & furniture.</CardDescription>
            </div>
            <Badge variant="secondary" className="gap-1"><Eye className="w-3 h-3" /> Real-time</Badge>
          </CardHeader>
          <CardContent className="p-0">
            <div className="relative aspect-[4/3] sm:aspect-[16/10] bv-blueprint-grid">
              <Suspense fallback={<div className="absolute inset-0 grid place-items-center text-sm text-muted-foreground">Loading preview…</div>}>
                <HouseScene
                  floorPlan={floorPlan}
                  materials={materials}
                  activeFloor={-1}
                  showWalls={true}
                  showRoof={true}
                  showInterior={true}
                  orbitAutoRotate={false}
                />
              </Suspense>
            </div>
          </CardContent>
        </Card>

        {/* Controls */}
        <div className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-1.5"><Palette className="w-4 h-4 text-primary" /> Material Presets</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {MATERIAL_PRESETS.map((p) => {
                const active = activePreset === p.id;
                return (
                  <button key={p.id} onClick={() => { applyPreset(p.id); setActivePreset(p.id); }}
                    className={`w-full flex items-center gap-3 rounded-md border p-2.5 transition-colors text-left ${
                      active ? "border-primary bg-primary/5" : "border-border/60 hover:bg-muted"
                    }`}>
                    <div className="flex shrink-0">
                      {p.swatch.map((c) => (
                        <span key={c} className="w-5 h-8 -ml-1 first:ml-0 rounded-sm border border-white/40"
                          style={{ background: c }} />
                      ))}
                    </div>
                    <span className="text-sm font-medium flex-1">{p.label}</span>
                    {active && <CheckCircle2 className="w-4 h-4 text-primary" />}
                  </button>
                );
              })}
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Custom Colour Library</CardTitle>
              <CardDescription>Fine-tune individual surfaces.</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="Interior">
                <TabsList className="grid grid-cols-2 mb-4">
                  <TabsTrigger value="Interior">Interior</TabsTrigger>
                  <TabsTrigger value="Exterior">Exterior</TabsTrigger>
                </TabsList>
                <TabsContent value="Interior" className="space-y-3">
                  {COLOR_FIELDS.filter((f) => f.group === "Interior").map((f) => (
                    <ColorRow key={f.key} label={f.label} value={materials[f.key] as string}
                      onChange={(c) => setColor(f.key, c)} />
                  ))}
                </TabsContent>
                <TabsContent value="Exterior" className="space-y-3">
                  {COLOR_FIELDS.filter((f) => f.group === "Exterior").map((f) => (
                    <ColorRow key={f.key} label={f.label} value={materials[f.key] as string}
                      onChange={(c) => setColor(f.key, c)} />
                  ))}
                  <div>
                    <Label className="text-xs">Lighting</Label>
                    <div className="grid grid-cols-3 gap-1.5 mt-1.5">
                      {(["warm", "neutral", "cool"] as const).map((l) => (
                        <button key={l} onClick={() => setMaterials({ lighting: l })}
                          className={`flex items-center justify-center gap-1 py-2 rounded-md text-xs border capitalize ${
                            materials.lighting === l ? "border-primary bg-primary/5 text-primary" : "border-border hover:bg-muted"
                          }`}>
                          {l === "warm" ? <Sun className="w-3 h-3" /> : <Moon className="w-3 h-3" />} {l}
                        </button>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Button className="w-full gap-1.5" onClick={() => setView("soil")}>
            Continue to soil & foundation <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function ColorRow({ label, value, onChange }: { label: string; value: string; onChange: (c: string) => void }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <Label className="text-xs flex-1">{label}</Label>
      <div className="flex items-center gap-2">
        <span className="text-[10px] text-muted-foreground font-mono uppercase">{value}</span>
        <input type="color" value={value} onChange={(e) => onChange(e.target.value)}
          className="w-8 h-8 rounded-md border border-border cursor-pointer bg-transparent" />
      </div>
    </div>
  );
}
