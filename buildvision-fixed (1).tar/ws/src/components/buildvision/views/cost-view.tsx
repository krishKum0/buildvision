"use client";

import { useEffect, useMemo, useState } from "react";
import { useAppStore } from "@/lib/store";
import { roomArea } from "@/lib/geometry";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calculator, Download, AlertTriangle } from "lucide-react";
import type { RoomType } from "@/lib/types";

// Indicative defaults only — every number is editable below.
const TIERS = {
  economy: { label: "Economy", rate: 1500 },
  standard: { label: "Standard", rate: 2000 },
  premium: { label: "Premium", rate: 3000 },
} as const;
type Tier = keyof typeof TIERS;

// Share of total construction cost per work package (sums to 100).
const PACKAGES: { key: string; label: string; pct: number }[] = [
  { key: "found", label: "Excavation & foundation", pct: 12 },
  { key: "rcc", label: "RCC structure (columns, beams, slabs)", pct: 28 },
  { key: "masonry", label: "Masonry & plastering", pct: 12 },
  { key: "floor", label: "Flooring & tiling", pct: 10 },
  { key: "doors", label: "Doors & windows", pct: 7 },
  { key: "elec", label: "Electrical", pct: 6 },
  { key: "plumb", label: "Plumbing & sanitary", pct: 7 },
  { key: "paint", label: "Painting & finishes", pct: 5 },
  { key: "wood", label: "Kitchen & woodwork", pct: 6 },
  { key: "ext", label: "External works & miscellaneous", pct: 7 },
];

// How much of each room type counts as built-up (covered) area.
const BUILTUP_FACTOR: Partial<Record<RoomType, number>> = {
  garden: 0,
  terrace: 0.25,
  balcony: 0.5,
  parking: 0.6,
};

const inr = (n: number) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(Math.round(n));

export function CostView() {
  const plot = useAppStore((s) => s.plot);
  const floorPlan = useAppStore((s) => s.floorPlan);
  const regenerate = useAppStore((s) => s.regenerate);
  const [tier, setTier] = useState<Tier>("standard");
  const [rate, setRate] = useState<number>(TIERS.standard.rate);
  const [contingency, setContingency] = useState(5);
  const [regional, setRegional] = useState(1);

  useEffect(() => { if (!floorPlan) regenerate(); }, [floorPlan, regenerate]);

  const calc = useMemo(() => {
    if (!floorPlan) return null;
    const toSqft = plot.unit === "m" ? 10.7639 : 1;
    let builtSqft = 0;
    for (const r of floorPlan.rooms) {
      builtSqft += roomArea(r) * (BUILTUP_FACTOR[r.type] ?? 1) * toSqft;
    }
    const base = builtSqft * rate * regional;
    const contingencyAmt = (base * contingency) / 100;
    const rows = PACKAGES.map((p) => ({ ...p, amount: (base * p.pct) / 100 }));
    return { builtSqft, base, contingencyAmt, total: base + contingencyAmt, rows };
  }, [floorPlan, plot.unit, rate, regional, contingency]);

  if (!floorPlan || !calc) return <div className="p-8">Generating…</div>;

  function pickTier(t: Tier) {
    setTier(t);
    setRate(TIERS[t].rate);
  }

  function downloadCsv() {
    if (!calc) return;
    const lines = [
      "Work package,Share %,Amount (INR)",
      ...calc.rows.map((r) => `"${r.label}",${r.pct},${Math.round(r.amount)}`),
      `"Contingency (${contingency}%)",,${Math.round(calc.contingencyAmt)}`,
      `"TOTAL",,${Math.round(calc.total)}`,
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "buildvision-cost-estimate.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  const num = (v: string, fallback: number) => {
    const n = Number(v);
    return Number.isFinite(n) && n >= 0 ? n : fallback;
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-[360px_1fr] gap-6">
        <Card className="border-border/60 h-fit">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Calculator className="w-4 h-4 text-primary" /> Cost Assumptions
            </CardTitle>
            <CardDescription>Pick a finish level, then fine-tune any number.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(TIERS) as Tier[]).map((t) => (
                <button
                  key={t}
                  onClick={() => pickTier(t)}
                  className={`px-2 py-2 rounded-md text-xs border ${
                    tier === t ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-muted"
                  }`}
                >
                  {TIERS[t].label}
                </button>
              ))}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="rate">Rate (₹ per sq ft built-up)</Label>
              <Input id="rate" type="number" min={0} value={rate} onChange={(e) => setRate(num(e.target.value, rate))} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="regional">Local cost multiplier</Label>
              <Input id="regional" type="number" min={0.5} max={2} step={0.05} value={regional}
                onChange={(e) => setRegional(num(e.target.value, regional))} />
              <p className="text-[11px] text-muted-foreground">1.00 = base rate. Raise for metro cities or hilly sites.</p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cont">Contingency (%)</Label>
              <Input id="cont" type="number" min={0} max={30} value={contingency}
                onChange={(e) => setContingency(num(e.target.value, contingency))} />
            </div>
            <div className="flex gap-2 rounded-md border border-amber-500/30 bg-amber-500/10 p-3 text-[11px] leading-relaxed">
              <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
              <span>
                Indicative estimate for early planning only. Land, approvals, furniture and site-specific
                work are excluded. Get a contractor quote or BOQ before budgeting.
              </span>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <div className="grid sm:grid-cols-3 gap-3">
            <Stat label="Built-up area" value={`${Math.round(calc.builtSqft).toLocaleString("en-IN")} sq ft`} />
            <Stat label="Construction cost" value={inr(calc.base)} />
            <Stat label="Total with contingency" value={inr(calc.total)} highlight />
          </div>

          <Card className="border-border/60">
            <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
              <CardTitle className="text-base">Cost breakdown</CardTitle>
              <Button size="sm" variant="outline" onClick={downloadCsv} className="gap-1.5">
                <Download className="w-3.5 h-3.5" /> CSV
              </Button>
            </CardHeader>
            <CardContent className="space-y-3">
              {calc.rows.map((r) => (
                <div key={r.key} className="space-y-1">
                  <div className="flex justify-between text-sm gap-3">
                    <span className="truncate">{r.label}</span>
                    <span className="tabular-nums font-medium">{inr(r.amount)}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div className="h-full bg-primary" style={{ width: `${r.pct * 3}%` }} />
                  </div>
                </div>
              ))}
              <div className="flex justify-between text-sm pt-2 border-t">
                <span>Contingency ({contingency}%)</span>
                <span className="tabular-nums font-medium">{inr(calc.contingencyAmt)}</span>
              </div>
              <div className="flex justify-between text-base font-semibold">
                <span>Total</span>
                <span className="tabular-nums">{inr(calc.total)}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <Card className={`border-border/60 ${highlight ? "bg-primary/5 border-primary/30" : ""}`}>
      <CardContent className="p-4">
        <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</p>
        <p className="text-lg font-semibold mt-1 tabular-nums">{value}</p>
      </CardContent>
    </Card>
  );
}
