"use client";

import { useMemo } from "react";
import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Plus, Ruler, Sparkles, Box, Compass, FileStack, Layers, ArrowRight,
  Building2, Map as MapIcon, History, HardHat, ShieldCheck,
} from "lucide-react";
import { roomArea } from "@/lib/geometry";

const PIPELINE = [
  { icon: Ruler, label: "Plot Input", view: "plot" as const, desc: "Enter dimensions & constraints" },
  { icon: Sparkles, label: "AI Generator", view: "design" as const, desc: "Generate design concepts" },
  { icon: MapIcon, label: "2D Floor Plan", view: "floorplan" as const, desc: "Inspect & edit rooms" },
  { icon: Box, label: "3D Viewer", view: "viewer3d" as const, desc: "360° building model" },
  { icon: Compass, label: "Vastu", view: "vastu" as const, desc: "Direction zoning" },
  { icon: Layers, label: "Soil", view: "soil" as const, desc: "Foundation data" },
  { icon: FileStack, label: "Structure", view: "structure" as const, desc: "Column & beam plan" },
];

export function DashboardView() {
  const projects = useAppStore((s) => s.projects);
  const newProject = useAppStore((s) => s.newProject);
  const loadProject = useAppStore((s) => s.loadProject);
  const setView = useAppStore((s) => s.setView);
  const user = useAppStore((s) => s.user);

  const stats = useMemo(() => {
    const generated = projects.filter((p) => p.status === "generated").length;
    const reviewed = projects.filter((p) => p.status === "reviewed").length;
    const totalArea = projects.reduce((a, p) => a + (p.plot?.plotArea ?? 0), 0);
    return { total: projects.length, generated, reviewed, totalArea };
  }, [projects]);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-2xl border border-border/60 bv-grain"
        style={{ background: "linear-gradient(120deg, oklch(0.93 0.04 65), oklch(0.86 0.06 50))" }}>
        <div className="absolute inset-0 bv-blueprint-grid opacity-50" />
        <div className="relative p-6 sm:p-8 grid lg:grid-cols-[1.4fr_1fr] gap-6 items-center">
          <div className="space-y-4">
            <Badge className="bg-primary/15 text-primary border-primary/20 hover:bg-primary/15">
              <Sparkles className="w-3 h-3 mr-1" /> Generative AI Studio
            </Badge>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
              Welcome back, {user?.name?.split(" ")[0]}.
            </h2>
            <p className="text-muted-foreground max-w-lg">
              Start a new project from your plot dimensions, or reopen a saved design. AI BuildVision
              turns land measurements into editable 2D floor plans, interactive 3D models, Vastu-aware
              zoning, and preliminary structural plans.
            </p>
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => newProject()} className="gap-1.5">
                <Plus className="w-4 h-4" /> Start new project
              </Button>
              <Button variant="outline" onClick={() => setView("history")} className="gap-1.5">
                <History className="w-4 h-4" /> Open project
              </Button>
            </div>
          </div>
          <div className="relative rounded-xl overflow-hidden border border-border/60 shadow-lg aspect-[4/3] hidden lg:block">
            { }
            <img src="/concepts/hero-aerial.jpg" alt="Aerial residential plot" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            <div className="absolute bottom-3 left-3 text-white">
              <p className="text-xs font-medium opacity-90">Sample site — aerial concept</p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Projects", value: stats.total, icon: Building2, color: "text-primary" },
          { label: "Generated", value: stats.generated, icon: Sparkles, color: "text-primary" },
          { label: "Reviewed", value: stats.reviewed, icon: ShieldCheck, color: "text-primary" },
          { label: "Total plot area", value: `${Math.round(stats.totalArea).toLocaleString()} sq ft`, icon: MapIcon, color: "text-primary" },
        ].map((s) => (
          <Card key={s.label} className="border-border/60">
            <CardContent className="p-5 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 grid place-items-center">
                <s.icon className={`w-5 h-5 ${s.color}`} />
              </div>
              <div className="min-w-0">
                <p className="text-xl font-semibold leading-none">{s.value}</p>
                <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </section>

      {/* Pipeline */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold">Design Pipeline</h3>
            <p className="text-sm text-muted-foreground">Follow the workflow from plot to export.</p>
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {PIPELINE.map((step, i) => (
            <button key={step.label} onClick={() => (i === 0 ? newProject() : setView(step.view))}
              className="group text-left">
              <Card className="border-border/60 hover:border-primary/40 hover:shadow-md transition-all h-full">
                <CardContent className="p-4 flex flex-col gap-3 h-full">
                  <div className="flex items-center justify-between">
                    <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary grid place-items-center">
                      <step.icon className="w-4.5 h-4.5" />
                    </div>
                    <span className="text-xs font-semibold text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
                  </div>
                  <div>
                    <p className="font-medium text-sm">{step.label}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{step.desc}</p>
                  </div>
                  <div className="mt-auto flex items-center text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                    Open <ArrowRight className="w-3 h-3 ml-1" />
                  </div>
                </CardContent>
              </Card>
            </button>
          ))}
        </div>
      </section>

      {/* Recent projects */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold">Recent Projects</h3>
            <p className="text-sm text-muted-foreground">Reopen and continue editing.</p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setView("history")} className="gap-1">
            View all <ArrowRight className="w-3.5 h-3.5" />
          </Button>
        </div>
        {projects.length === 0 ? (
          <Card className="border-dashed border-border/60">
            <CardContent className="p-10 flex flex-col items-center text-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/10 text-primary grid place-items-center">
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <p className="font-medium">No projects yet</p>
                <p className="text-sm text-muted-foreground">Start by entering your plot dimensions.</p>
              </div>
              <Button onClick={() => newProject()} className="gap-1.5">
                <Plus className="w-4 h-4" /> New project
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {projects.slice(0, 6).map((p) => {
              const totalRooms = p.floorPlan?.rooms?.length ?? 0;
              const totalArea = p.floorPlan?.rooms?.reduce((a, r) => a + roomArea(r), 0) ?? 0;
              return (
                <Card key={p.id} className="border-border/60 hover:shadow-md transition-shadow cursor-pointer overflow-hidden"
                  onClick={() => loadProject(p)}>
                  <div className="aspect-[16/9] relative bg-muted overflow-hidden">
                    {p.conceptImg ? (
                       
                      <img src={p.conceptImg} alt={p.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full grid place-items-center bg-gradient-to-br from-primary/10 to-primary/5">
                        <Building2 className="w-10 h-10 text-primary/40" />
                      </div>
                    )}
                    <Badge className="absolute top-2 right-2 capitalize" variant="secondary">{p.status}</Badge>
                  </div>
                  <CardContent className="p-4 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-medium truncate">{p.name}</p>
                      <span className="text-xs text-muted-foreground shrink-0">{p.plot.floors}F</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {p.plot.length}×{p.plot.width} {p.plot.unit} · {Math.round(p.plot.plotArea).toLocaleString()} sq {p.plot.unit}
                    </p>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{totalRooms} rooms</span>
                      <span>·</span>
                      <span>{Math.round(totalArea).toLocaleString()} sq {p.plot.unit} built</span>
                    </div>
                    <Progress value={p.status === "exported" ? 100 : p.status === "reviewed" ? 80 : p.status === "generated" ? 55 : 25} className="h-1.5" />
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </section>

      <section className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 flex items-start gap-3">
        <HardHat className="w-5 h-5 text-primary shrink-0 mt-0.5" />
        <p className="text-sm text-muted-foreground">
          <span className="font-medium text-foreground">Engineering disclaimer:</span> AI BuildVision 360°
          produces conceptual designs and preliminary layouts. All structural member sizing, reinforcement,
          foundations and safety checks must be completed or approved by a qualified structural / geotechnical
          engineer before construction.
        </p>
      </section>
    </div>
  );
}
