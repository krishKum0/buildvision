"use client";

import { useEffect, useState } from "react";
import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { FloorPlanCanvas } from "@/components/buildvision/floorplan/floor-plan-canvas";
import { Compass, RotateCw, Sparkles, AlertTriangle, ArrowRight, Map as MapIcon } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { VASTU_RULES } from "@/lib/geometry";

const ZONE_POS: Record<string, { angle: number; label: string }> = {
  N: { angle: 0, label: "N" },
  NE: { angle: 45, label: "NE" },
  E: { angle: 90, label: "E" },
  SE: { angle: 135, label: "SE" },
  S: { angle: 180, label: "S" },
  SW: { angle: 225, label: "SW" },
  W: { angle: 270, label: "W" },
  NW: { angle: 315, label: "NW" },
};

export function VastuView() {
  const plot = useAppStore((s) => s.plot);
  const vastu = useAppStore((s) => s.vastu);
  const setVastu = useAppStore((s) => s.setVastu);
  const floorPlan = useAppStore((s) => s.floorPlan);
  const regenerate = useAppStore((s) => s.regenerate);
  const setView = useAppStore((s) => s.setView);
  const [activeFloor, setActiveFloor] = useState(0);
  const [suggestions, setSuggestions] = useState<any[]>([]);

  useEffect(() => {
    if (!floorPlan) regenerate();
  }, [floorPlan, regenerate]);

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/vastu-suggest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ roadDirection: plot.roadDirection, rooms: ["master", "kitchen", "pooja", "living", "guest", "study", "bedroom", "utility"] }),
      });
      const data = await res.json();
      if (data.suggestions) {
        setSuggestions(data.suggestions);
        setVastu({ suggestions: data.suggestions });
      }
    })();
     
  }, [plot.roadDirection]);

  if (!floorPlan) return <div className="p-8">Generating…</div>;

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-[1fr_360px] gap-6">
        {/* Compass + plan */}
        <div className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  <Compass className="w-4 h-4 text-primary" /> Vastu Compass Overlay
                </CardTitle>
                <CardDescription>Rotate the compass to match your true plot orientation.</CardDescription>
              </div>
              <Switch checked={vastu.enabled} onCheckedChange={(v) => { setVastu({ enabled: v }); regenerate(); }} />
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-[200px_1fr] gap-6 items-center">
                <CompassDial rotation={vastu.rotation} road={plot.roadDirection} />
                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs flex items-center gap-1.5"><RotateCw className="w-3.5 h-3.5" /> Compass rotation</Label>
                      <span className="text-xs font-medium">{vastu.rotation}°</span>
                    </div>
                    <Slider value={[vastu.rotation]} min={0} max={345} step={15}
                      onValueChange={(v) => setVastu({ rotation: v[0] })} />
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="rounded-md bg-muted/40 p-2">
                      <p className="text-muted-foreground">Road faces</p>
                      <p className="font-medium">{roadLabel(plot.roadDirection)}</p>
                    </div>
                    <div className="rounded-md bg-muted/40 p-2">
                      <p className="text-muted-foreground">Status</p>
                      <p className="font-medium">{vastu.enabled ? "Active" : "Off"}</p>
                    </div>
                  </div>
                  <Button size="sm" variant="outline" className="w-full gap-1.5"
                    onClick={() => { setVastu({ rotation: 0 }); regenerate(); toast({ title: "Vastu realigned", description: "Floor plan regenerated" }); }}>
                    <Sparkles className="w-3.5 h-3.5" /> Reset & regenerate
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-1.5"><MapIcon className="w-4 h-4 text-primary" /> Floor Plan with Vastu Zones</CardTitle>
            </CardHeader>
            <CardContent>
              <FloorPlanCanvas floorPlan={floorPlan} vastu={vastu} activeFloor={activeFloor} showVastu={vastu.enabled} />
              {floorPlan.floors > 1 && (
                <div className="flex gap-1.5 mt-3">
                  {Array.from({ length: floorPlan.floors }).map((_, f) => (
                    <button key={f} onClick={() => setActiveFloor(f)}
                      className={`px-3 py-1 rounded-md text-xs border ${
                        activeFloor === f ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-muted"
                      }`}>Level {f + 1}</button>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Suggestions */}
        <div className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Vastu Room Placement Guide</CardTitle>
              <CardDescription>Optional & configurable. Never overrides safety or regulations.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2.5">
              {Object.entries(VASTU_RULES).map(([zone, v]) => (
                <div key={zone} className="flex items-center gap-3 rounded-md border border-border/60 p-2.5">
                  <div className="w-9 h-9 rounded-md bg-primary/10 text-primary grid place-items-center font-bold text-xs shrink-0">
                    {zone}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium capitalize">{v.room}</p>
                    <p className="text-[11px] text-muted-foreground leading-tight">{v.note}</p>
                  </div>
                  <Badge variant="outline" className="text-[10px]">{v.direction}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-amber-500/30 bg-amber-500/5">
            <CardContent className="p-3 flex gap-2">
              <AlertTriangle className="w-4 h-4 text-primary shrink-0 mt-0.5" />
              <p className="text-[11px] text-muted-foreground">
                Vastu guidance must not override structural safety, natural ventilation, accessibility, fire safety, or applicable building regulations.
              </p>
            </CardContent>
          </Card>

          <Button className="w-full gap-1.5" onClick={() => setView("materials")}>
            Continue to materials <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function CompassDial({ rotation, road }: { rotation: number; road: string }) {
  return (
    <div className="relative w-[200px] h-[200px] mx-auto">
      <div className="absolute inset-0 rounded-full border-4 border-border/60 bg-card bv-grain"
        style={{ transform: `rotate(${rotation}deg)`, transition: "transform 0.3s" }}>
        <svg viewBox="0 0 200 200" className="w-full h-full">
          {Object.entries(ZONE_POS).map(([key, val]) => {
            const rad = (val.angle - 90) * (Math.PI / 180);
            const x = 100 + Math.cos(rad) * 72;
            const y = 100 + Math.sin(rad) * 72;
            return (
              <g key={key}>
                <line x1={100} y1={100} x2={x} y2={y} stroke="oklch(0.8 0.02 50)" strokeWidth={0.5} />
                <text x={100 + Math.cos(rad) * 88} y={100 + Math.sin(rad) * 88}
                  textAnchor="middle" dominantBaseline="middle" className="fill-foreground"
                  style={{ fontSize: 12, fontWeight: 700 }}>{val.label}</text>
              </g>
            );
          })}
          <circle cx={100} cy={100} r={30} fill="none" stroke="oklch(0.7 0.02 50)" strokeWidth={1} />
          {/* road indicator on the road-facing direction */}
          {(() => {
            const angle = (ZONE_POS[road]?.angle ?? 0) - 90;
            const rad = angle * (Math.PI / 180);
            const x = 100 + Math.cos(rad) * 96;
            const y = 100 + Math.sin(rad) * 96;
            return <circle cx={x} cy={y} r={6} fill="oklch(0.5 0.05 250)" stroke="white" strokeWidth={1.5} />;
          })()}
          {/* needle */}
          <polygon points="100,40 106,100 100,108 94,100" fill="oklch(0.6 0.13 45)" />
          <polygon points="100,160 106,100 100,92 94,100" fill="oklch(0.4 0.02 50)" />
          <circle cx={100} cy={100} r={5} fill="white" stroke="oklch(0.3 0.02 50)" />
        </svg>
      </div>
      <p className="absolute -bottom-1 left-1/2 -translate-x-1/2 text-[10px] text-muted-foreground bg-card px-2">road ●</p>
    </div>
  );
}

const ROAD_LABEL: Record<string, string> = {
  N: "North", NE: "North-East", E: "East", SE: "South-East",
  S: "South", SW: "South-West", W: "West", NW: "North-West",
};
function roadLabel(d: string) { return ROAD_LABEL[d] ?? d; }
