"use client";

import { useEffect, useState } from "react";
import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  History, Plus, Search, Building2, Clock, Copy, Trash2, FileStack, ArrowRight, RotateCcw,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import type { Project } from "@/lib/types";
import { roomArea } from "@/lib/geometry";

export function HistoryView() {
  const projects = useAppStore((s) => s.projects);
  const setProjects = useAppStore((s) => s.setProjects);
  const loadProject = useAppStore((s) => s.loadProject);
  const setView = useAppStore((s) => s.setView);
  const newProject = useAppStore((s) => s.newProject);
  const user = useAppStore((s) => s.user);
  const [q, setQ] = useState("");
  const [versionsFor, setVersionsFor] = useState<string | null>(null);
  const [versions, setVersions] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/projects", { cache: "no-store" });
      const data = await res.json();
      if (data.projects) setProjects(data.projects);
    })();
  }, [setProjects, user?.id]);

  async function openVersions(p: Project) {
    setVersionsFor(p.id);
    const res = await fetch(`/api/projects/${p.id}`, { cache: "no-store" });
    const data = await res.json();
    setVersions(data.versions ?? []);
  }

  async function deleteProject(id: string) {
    const res = await fetch(`/api/projects/${id}`, { method: "DELETE" });
    if (res.ok) {
      setProjects(projects.filter((p) => p.id !== id));
      toast({ title: "Project deleted" });
    }
  }

  async function duplicateProject(p: Project) {
    const res = await fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: `${p.name} (copy)`,
        plot: p.plot, design: p.design, vastu: p.vastu,
        materials: p.materials, soil: p.soil, structure: p.structure, conceptImg: p.conceptImg,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      const list = await fetch("/api/projects", { cache: "no-store" });
      const ld = await list.json();
      if (ld.projects) setProjects(ld.projects);
      toast({ title: "Duplicated", description: data.project.name });
    }
  }

  async function renameProject(p: Project, name: string) {
    const res = await fetch(`/api/projects/${p.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, versionNote: "Renamed" }),
    });
    if (res.ok) {
      const list = await fetch("/api/projects", { cache: "no-store" });
      const ld = await list.json();
      if (ld.projects) setProjects(ld.projects);
    }
  }

  const filtered = projects.filter((p) => p.name.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2"><History className="w-5 h-5 text-primary" /> Projects & Version History</h2>
          <p className="text-sm text-muted-foreground">Reopen, compare, duplicate or restore earlier design versions.</p>
        </div>
        <Button onClick={() => newProject()} className="gap-1.5"><Plus className="w-4 h-4" /> New project</Button>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search projects…" className="pl-9" />
      </div>

      {filtered.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="p-12 text-center space-y-3">
            <Building2 className="w-10 h-10 text-muted-foreground mx-auto" />
            <p className="font-medium">No projects found</p>
            <p className="text-sm text-muted-foreground">Start your first design from the plot input.</p>
            <Button onClick={() => newProject()} className="gap-1.5"><Plus className="w-4 h-4" /> New project</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((p) => {
            const totalArea = p.floorPlan?.rooms?.reduce((a, r) => a + roomArea(r), 0) ?? 0;
            return (
              <Card key={p.id} className="border-border/60 overflow-hidden">
                <div className="grid sm:grid-cols-[160px_1fr_auto] gap-0">
                  <div className="relative bg-muted h-32 sm:h-full">
                    {p.conceptImg ? (
                       
                      <img src={p.conceptImg} alt={p.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full grid place-items-center bg-gradient-to-br from-primary/10 to-primary/5">
                        <Building2 className="w-8 h-8 text-primary/40" />
                      </div>
                    )}
                    <Badge className="absolute top-2 left-2 capitalize" variant="secondary">{p.status}</Badge>
                  </div>
                  <CardContent className="p-4 flex flex-col gap-2">
                    <input
                      defaultValue={p.name}
                      onBlur={(e) => { if (e.target.value !== p.name) renameProject(p, e.target.value); }}
                      className="font-semibold text-base bg-transparent border-none focus:outline-none focus:ring-1 focus:ring-primary rounded px-1 -mx-1"
                    />
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><Building2 className="w-3 h-3" /> {p.plot.length}×{p.plot.width} {p.plot.unit}</span>
                      <span className="flex items-center gap-1"><FileStack className="w-3 h-3" /> {p.floorPlan?.rooms?.length ?? 0} rooms</span>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {new Date(p.updatedAt).toLocaleDateString()}</span>
                      <span>{p.plot.floors} floor(s)</span>
                      <span>{Math.round(totalArea).toLocaleString()} sq {p.plot.unit} built</span>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-auto">
                      <Button size="sm" onClick={() => { loadProject(p); }} className="gap-1.5">
                        Open <ArrowRight className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => openVersions(p)} className="gap-1.5">
                        <History className="w-3.5 h-3.5" /> Versions
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => duplicateProject(p)} className="gap-1.5">
                        <Copy className="w-3.5 h-3.5" /> Duplicate
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => deleteProject(p.id)} className="gap-1.5 text-destructive hover:text-destructive">
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </CardContent>
                </div>

                {versionsFor === p.id && (
                  <div className="border-t border-border/60 bg-muted/30 p-4">
                    <p className="text-sm font-medium mb-3 flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-primary" /> Version history ({versions.length})
                    </p>
                    <div className="space-y-2 max-h-64 overflow-y-auto bv-scroll">
                      {versions.map((v) => (
                        <div key={v.id} className="flex items-center justify-between rounded-md bg-card border border-border/60 p-2.5">
                          <div className="min-w-0">
                            <p className="text-sm font-medium">v{v.version} — {v.note}</p>
                            <p className="text-[11px] text-muted-foreground">{new Date(v.createdAt).toLocaleString()}</p>
                          </div>
                          <Button size="sm" variant="ghost" className="gap-1"
                            onClick={() => {
                              const snap = JSON.parse(v.snapshot);
                              const restored: Project = { ...p, ...snap };
                              loadProject(restored);
                              toast({ title: `Restored v${v.version}`, description: "Working copy updated. Save to persist." });
                            }}>
                            <RotateCcw className="w-3.5 h-3.5" /> Restore
                          </Button>
                        </div>
                      ))}
                      {versions.length === 0 && <p className="text-xs text-muted-foreground">No versions recorded.</p>}
                    </div>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
