"use client";

import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Sparkles, Loader2, ArrowRight, Wand2, CheckCircle2, AlertTriangle, Palette } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import type { HouseStyle, MaterialPalette } from "@/lib/types";

interface Concept {
  id: string;
  name: string;
  style: HouseStyle;
  roof: "flat" | "sloped" | "terrace";
  palette: MaterialPalette;
  seed: number;
  conceptImg: string;
  blurb: string;
  highlights: string[];
  structuralNote: string;
}

export function DesignGeneratorView() {
  const plot = useAppStore((s) => s.plot);
  const vastu = useAppStore((s) => s.vastu);
  const setVastu = useAppStore((s) => s.setVastu);
  const setDesign = useAppStore((s) => s.setDesign);
  const design = useAppStore((s) => s.design);
  const regenerate = useAppStore((s) => s.regenerate);
  const setView = useAppStore((s) => s.setView);
  const setProject = useAppStore((s) => s.setProject);
  const project = useAppStore((s) => s.project);

  const [concepts, setConcepts] = useState<Concept[]>([]);
  const [loading, setLoading] = useState(false);
  const [count, setCount] = useState(3);
  const [selected, setSelected] = useState<string | null>(null);

  async function generate() {
    if (plot.plotArea <= 0) {
      toast({ title: "Plot invalid", description: "Enter plot dimensions first.", variant: "destructive" });
      setView("plot");
      return;
    }
    setLoading(true);
    setConcepts([]);
    setSelected(null);
    try {
      const res = await fetch("/api/generate-design", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plot, count, vastuEnabled: vastu.enabled }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Generation failed", description: data.error, variant: "destructive" });
        return;
      }
      setConcepts(data.concepts);
      toast({ title: "Concepts ready", description: `${data.concepts.length} AI design alternatives generated` });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  function applyConcept(c: Concept) {
    setSelected(c.id);
    setDesign({
      style: c.style,
      roof: c.roof,
      palette: c.palette,
      designSeed: c.seed,
      conceptText: c.blurb,
    });
    useAppStore.getState().applyPreset(c.palette);
    regenerate();
    toast({ title: `${c.name} applied`, description: "Floor plan & 3D model updated. Save to store version." });
  }

  async function saveAsProject() {
    setProject({ ...(project ?? ({} as any)), name: project?.name ?? `Plot ${plot.length}×${plot.width} ${plot.unit}` });
    setView("floorplan");
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Config bar */}
      <Card className="border-border/60">
        <CardContent className="p-5 flex flex-col lg:flex-row lg:items-end gap-5">
          <div className="flex-1 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-primary" /> AI House Design Generator
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Constrained geometric generation (not just images) — each concept produces an editable floor plan & 3D model.
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-6">
              <div className="space-y-2">
                <Label className="text-xs">Number of concepts</Label>
                <div className="flex items-center gap-3 w-48">
                  <Slider value={[count]} min={1} max={4} step={1} onValueChange={(v) => setCount(v[0])} />
                  <span className="w-6 text-center font-medium">{count}</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Switch checked={vastu.enabled} onCheckedChange={(v) => setVastu({ enabled: v })} id="vastu" />
                <Label htmlFor="vastu" className="text-sm">Apply Vastu preferences</Label>
              </div>
            </div>
          </div>
          <Button size="lg" onClick={generate} disabled={loading} className="gap-2">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
            {loading ? "Generating…" : "Generate concepts"}
          </Button>
        </CardContent>
      </Card>

      {/* Plot context summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
        <Summary label="Plot" value={`${plot.length}×${plot.width} ${plot.unit}`} />
        <Summary label="Area" value={`${Math.round(plot.plotArea).toLocaleString()} sq ${plot.unit}`} />
        <Summary label="Floors" value={`${plot.floors}`} />
        <Summary label="Road" value={roadLabel(plot.roadDirection)} />
      </div>

      {/* Concepts grid */}
      {loading && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: count }).map((_, i) => (
            <Card key={i} className="border-border/60 overflow-hidden">
              <div className="aspect-[16/10] bg-muted animate-pulse" />
              <CardContent className="p-4 space-y-3">
                <div className="h-4 bg-muted rounded animate-pulse w-2/3" />
                <div className="h-3 bg-muted rounded animate-pulse w-full" />
                <div className="h-3 bg-muted rounded animate-pulse w-5/6" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {!loading && concepts.length === 0 && (
        <Card className="border-dashed border-border/60">
          <CardContent className="p-12 flex flex-col items-center text-center gap-4">
            <div className="w-14 h-14 rounded-full bg-primary/10 text-primary grid place-items-center">
              <Wand2 className="w-7 h-7" />
            </div>
            <div>
              <p className="font-medium text-lg">Generate your first design concepts</p>
              <p className="text-sm text-muted-foreground max-w-md mt-1">
                The AI produces multiple room arrangements, elevations, roof designs, stair & balcony layouts,
                interior furnishing concepts and material combinations — all tied to your plot dimensions.
              </p>
            </div>
            <Button onClick={generate} className="gap-2"><Sparkles className="w-4 h-4" /> Generate now</Button>
          </CardContent>
        </Card>
      )}

      {concepts.length > 0 && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {concepts.map((c) => {
            const isSel = selected === c.id;
            return (
              <Card key={c.id} className={`border-border/60 overflow-hidden flex flex-col transition-all ${
                isSel ? "ring-2 ring-primary border-primary" : "hover:shadow-lg"
              }`}>
                <div className="relative aspect-[16/10] bg-muted">
                  { }
                  <img src={c.conceptImg} alt={c.name} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute top-2 left-2 flex gap-1.5">
                    <Badge className="capitalize bg-white/90 text-foreground">{c.style}</Badge>
                    <Badge variant="secondary" className="bg-white/90 text-foreground capitalize">{c.roof}</Badge>
                  </div>
                  {isSel && (
                    <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-primary text-primary-foreground grid place-items-center">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                  )}
                  <div className="absolute bottom-2 left-2 right-2 text-white">
                    <p className="font-semibold text-sm leading-tight">{c.name}</p>
                  </div>
                </div>
                <CardContent className="p-4 flex-1 flex flex-col gap-3">
                  <p className="text-xs text-muted-foreground leading-relaxed">{c.blurb}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {c.highlights.slice(0, 4).map((h, i) => (
                      <Badge key={i} variant="outline" className="text-[10px] font-normal">{h}</Badge>
                    ))}
                  </div>
                  <div className="mt-auto space-y-2">
                    <div className="flex items-center gap-2 text-xs">
                      <Palette className="w-3.5 h-3.5 text-primary" />
                      <span className="capitalize">{c.palette.replace("-", " & ")}</span>
                      <span className="text-muted-foreground">· seed {c.seed}</span>
                    </div>
                    <div className="flex items-start gap-1.5 text-[11px] text-muted-foreground bg-muted/40 rounded p-2">
                      <AlertTriangle className="w-3 h-3 text-primary shrink-0 mt-0.5" />
                      <span>{c.structuralNote}</span>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" className="flex-1 gap-1.5" variant={isSel ? "secondary" : "default"} onClick={() => applyConcept(c)}>
                        {isSel ? <><CheckCircle2 className="w-3.5 h-3.5" /> Applied</> : <>Apply concept <ArrowRight className="w-3.5 h-3.5" /></>}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {selected && (
        <Card className="border-primary/40 bg-primary/5">
          <CardContent className="p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between">
            <div>
              <p className="font-medium flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-primary" /> Design concept applied</p>
              <p className="text-sm text-muted-foreground mt-0.5">Floor plan & 3D model regenerated with style “{design.style}”. Explore them now or save a version.</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={saveAsProject} className="gap-1.5">Save & open floor plan</Button>
              <Button onClick={() => setView("viewer3d")} className="gap-1.5">Open 3D viewer <ArrowRight className="w-4 h-4" /></Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Summary({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border/60 bg-card p-3">
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  );
}

const ROAD_LABEL: Record<string, string> = {
  N: "North", NE: "North-East", E: "East", SE: "South-East",
  S: "South", SW: "South-West", W: "West", NW: "North-West",
};
function roadLabel(d: string) {
  return ROAD_LABEL[d] ?? d;
}
