"use client";

import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Layers, FileText, AlertTriangle, FlaskConical, Droplets, Building, Plus, Trash2, ArrowRight, CheckCircle2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import type { SoilLayer } from "@/lib/types";

const FOUNDATION_TYPES = [
  { v: "isolated", label: "Isolated footings" },
  { v: "combined", label: "Combined footings" },
  { v: "strip", label: "Strip foundation" },
  { v: "raft", label: "Raft foundation" },
  { v: "pile", label: "Pile foundation" },
];

export function SoilView() {
  const soil = useAppStore((s) => s.soil);
  const setSoil = useAppStore((s) => s.setSoil);
  const setView = useAppStore((s) => s.setView);
  const [result, setResult] = useState<{ foundationType: string; note: string; disclaimer: string } | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  function addLayer() {
    const layer: SoilLayer = { name: "Layer", depthFrom: 0, depthTo: 1, bearingKPa: 150, color: "#c9a86b" };
    setSoil({ layers: [...soil.layers, layer] });
  }
  function updateLayer(i: number, patch: Partial<SoilLayer>) {
    const layers = [...soil.layers];
    layers[i] = { ...layers[i], ...patch };
    setSoil({ layers });
  }
  function removeLayer(i: number) {
    setSoil({ layers: soil.layers.filter((_, idx) => idx !== i) });
  }

  async function analyze() {
    if (!soil.hasReport) {
      toast({ title: "Report required", description: "Enter geotechnical data first.", variant: "destructive" });
      return;
    }
    setAnalyzing(true);
    try {
      const res = await fetch("/api/soil-analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          layers: soil.layers,
          bearingCapacityKPa: soil.bearingCapacityKPa,
          waterTableDepth: soil.waterTableDepth,
        }),
      });
      const data = await res.json();
      setResult(data);
      setSoil({ foundationType: data.foundationType, notes: data.note });
      toast({ title: "Foundation guidance", description: data.foundationType });
    } finally {
      setAnalyzing(false);
    }
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-[1fr_360px] gap-6">
        {/* Report input */}
        <div className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="text-base flex items-center gap-2"><FlaskConical className="w-4 h-4 text-primary" /> Soil Information Module</CardTitle>
                <CardDescription>Upload or enter geotechnical investigation data.</CardDescription>
              </div>
              <Button size="sm" variant={soil.hasReport ? "secondary" : "default"} onClick={() => setSoil({ hasReport: !soil.hasReport })}>
                {soil.hasReport ? "Report added" : "Add report"}
              </Button>
            </CardHeader>
            {soil.hasReport && (
              <CardContent className="space-y-5">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Site / location</Label>
                    <Input value={soil.location} placeholder="Plot address / site reference"
                      onChange={(e) => setSoil({ location: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <Label>Groundwater table depth ({soil.location ? "m" : "m"})</Label>
                    <Input type="number" min={0} value={soil.waterTableDepth}
                      onChange={(e) => setSoil({ waterTableDepth: Number(e.target.value) })} />
                  </div>
                  <div className="space-y-2">
                    <Label>Soil bearing capacity (kPa)</Label>
                    <Input type="number" min={0} value={soil.bearingCapacityKPa}
                      onChange={(e) => setSoil({ bearingCapacityKPa: Number(e.target.value) })} />
                  </div>
                  <div className="space-y-2">
                    <Label>Settlement (mm)</Label>
                    <Input type="number" min={0} value={soil.settlementMm}
                      onChange={(e) => setSoil({ settlementMm: Number(e.target.value) })} />
                  </div>
                </div>

                <Separator />

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-sm flex items-center gap-1.5"><Layers className="w-4 h-4 text-primary" /> Soil layers</Label>
                    <Button size="sm" variant="outline" onClick={addLayer} className="gap-1"><Plus className="w-3.5 h-3.5" /> Add layer</Button>
                  </div>
                  <div className="space-y-2">
                    {soil.layers.length === 0 && (
                      <p className="text-xs text-muted-foreground py-3 text-center">No layers yet. Add from a geotechnical report.</p>
                    )}
                    {soil.layers.map((l, i) => (
                      <div key={i} className="grid grid-cols-[1fr_70px_70px_90px_36px] gap-2 items-center">
                        <Input value={l.name} placeholder="Soil type" onChange={(e) => updateLayer(i, { name: e.target.value })} />
                        <Input type="number" value={l.depthFrom} placeholder="from" onChange={(e) => updateLayer(i, { depthFrom: Number(e.target.value) })} />
                        <Input type="number" value={l.depthTo} placeholder="to" onChange={(e) => updateLayer(i, { depthTo: Number(e.target.value) })} />
                        <Input type="number" value={l.bearingKPa} placeholder="kPa" onChange={(e) => updateLayer(i, { bearingKPa: Number(e.target.value) })} />
                        <Button size="icon" variant="ghost" onClick={() => removeLayer(i)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </div>
                    ))}
                  </div>
                  {soil.layers.length > 0 && <SoilColumn layers={soil.layers} />}
                </div>

                <Button onClick={analyze} disabled={analyzing} className="w-full gap-2">
                  <FlaskConical className="w-4 h-4" /> {analyzing ? "Analyzing…" : "Get foundation guidance"}
                </Button>
              </CardContent>
            )}
            {!soil.hasReport && (
              <CardContent>
                <div className="text-center py-8 space-y-3">
                  <FileText className="w-10 h-10 text-muted-foreground mx-auto" />
                  <p className="text-sm text-muted-foreground">No geotechnical report yet. Add one to get foundation guidance.</p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>

        {/* Guidance */}
        <div className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-1.5"><Building className="w-4 h-4 text-primary" /> Foundation Guidance</CardTitle>
              <CardDescription>Preliminary — for professional evaluation.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {result ? (
                <>
                  <div className="rounded-md bg-primary/10 border border-primary/30 p-3">
                    <p className="text-xs text-muted-foreground">Recommended type</p>
                    <p className="font-semibold text-base">{result.foundationType}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">{result.note}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {FOUNDATION_TYPES.map((t) => (
                      <Badge key={t.v} variant="outline" className="text-[10px]">{t.label}</Badge>
                    ))}
                  </div>
                </>
              ) : (
                <p className="text-xs text-muted-foreground py-4 text-center">Run analysis to view foundation guidance.</p>
              )}
            </CardContent>
          </Card>

          <Card className="border-destructive/30 bg-destructive/5">
            <CardContent className="p-3 flex gap-2">
              <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
              <p className="text-[11px] text-muted-foreground">
                The website must <strong>not</strong> guess soil type or bearing capacity from a plot address. Always use a real geotechnical report. Final foundation type, sizing & reinforcement must be approved by a qualified engineer.
              </p>
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-1.5"><Droplets className="w-4 h-4 text-primary" /> Quick checks</CardTitle>
            </CardHeader>
            <CardContent className="space-y-1.5 text-xs">
              <CheckRow ok={soil.bearingCapacityKPa >= 150} label="Bearing ≥ 150 kPa (isolated footings OK)" />
              <CheckRow ok={soil.waterTableDepth === 0 || soil.waterTableDepth >= 2} label="Water table ≥ 2 m (low risk)" />
              <CheckRow ok={soil.layers.length > 0} label="Soil layers documented" />
              <CheckRow ok={soil.settlementMm <= 25} label="Settlement within tolerable range" />
            </CardContent>
          </Card>

          <Button className="w-full gap-1.5" onClick={() => setView("structure")}>
            Continue to structural plan <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function CheckRow({ ok, label }: { ok: boolean; label: string }) {
  return (
    <div className="flex items-center gap-2">
      {ok ? <CheckCircle2 className="w-3.5 h-3.5 text-primary" /> : <AlertTriangle className="w-3.5 h-3.5 text-muted-foreground" />}
      <span className={ok ? "text-foreground" : "text-muted-foreground"}>{label}</span>
    </div>
  );
}

function SoilColumn({ layers }: { layers: SoilLayer[] }) {
  const maxDepth = Math.max(...layers.map((l) => l.depthTo), 5);
  return (
    <div className="mt-3 flex gap-1 h-32 rounded-md overflow-hidden border border-border/60">
      {layers.map((l, i) => {
        const h = (l.depthTo - l.depthFrom) / maxDepth * 100;
        return (
          <div key={i} className="flex-1 relative" style={{ background: l.color, height: "100%" }}>
            <div className="absolute inset-x-0 bottom-0 p-1 text-[9px] text-white font-medium leading-tight"
              style={{ height: `${Math.max(h, 12)}%` }}>
              {l.name}<br />{l.bearingKPa}kPa
            </div>
          </div>
        );
      })}
    </div>
  );
}
