"use client";

import { useEffect, useState } from "react";
import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { FloorPlanCanvas, RoomLegend, roomArea } from "@/components/buildvision/floorplan/floor-plan-canvas";
import { Box, Compass, Layers, RefreshCw, ArrowRight, Info, ChevronLeft, ChevronRight, Map as MapIcon } from "lucide-react";
import { roomArea as roomAreaFn } from "@/lib/geometry";

export function FloorplanView() {
  const plot = useAppStore((s) => s.plot);
  const design = useAppStore((s) => s.design);
  const vastu = useAppStore((s) => s.vastu);
  const setVastu = useAppStore((s) => s.setVastu);
  const floorPlan = useAppStore((s) => s.floorPlan);
  const regenerate = useAppStore((s) => s.regenerate);
  const setView = useAppStore((s) => s.setView);
  const newProject = useAppStore((s) => s.newProject);

  const [activeFloor, setActiveFloor] = useState(0);
  const [showVastu, setShowVastu] = useState(true);
  const [selected, setSelected] = useState<string | null>(null);

  useEffect(() => {
    if (!floorPlan) regenerate();
  }, [floorPlan, regenerate]);

  if (!floorPlan) {
    return (
      <div className="p-8 grid place-items-center">
        <p className="text-muted-foreground">Generating floor plan…</p>
      </div>
    );
  }

  const roomsOnFloor = floorPlan.rooms.filter((r) => r.floor === activeFloor);
  const selectedRoom = floorPlan.rooms.find((r) => r.id === selected);
  const totalBuilt = floorPlan.rooms.reduce((a, r) => a + roomAreaFn(r), 0);

  // If no project started and user came directly, offer to start
  if (plot.plotArea === 0) {
    return (
      <div className="p-8 max-w-3xl mx-auto">
        <Card className="border-dashed">
          <CardContent className="p-10 text-center space-y-4">
            <MapIcon className="w-10 h-10 text-primary mx-auto" />
            <p className="font-medium">Start a project to view floor plans</p>
            <p className="text-sm text-muted-foreground">Enter your plot dimensions first.</p>
            <Button onClick={() => newProject()} className="gap-1.5"><Compass className="w-4 h-4" /> New project</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-[1fr_340px] gap-6">
        {/* Canvas + controls */}
        <div className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  <MapIcon className="w-4 h-4 text-primary" /> Floor Plan — Level {activeFloor + 1}
                </CardTitle>
                <CardDescription>
                  {plot.length}×{plot.width} {plot.unit} · {Math.round(plot.plotArea).toLocaleString()} sq {plot.unit} plot
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button size="icon" variant="outline" disabled={activeFloor === 0} onClick={() => setActiveFloor((f) => Math.max(0, f - 1))}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Badge variant="secondary">Floor {activeFloor + 1} / {floorPlan.floors}</Badge>
                <Button size="icon" variant="outline" disabled={activeFloor >= floorPlan.floors - 1} onClick={() => setActiveFloor((f) => Math.min(floorPlan.floors - 1, f + 1))}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <FloorPlanCanvas floorPlan={floorPlan} vastu={vastu} activeFloor={activeFloor}
                showVastu={showVastu && vastu.enabled}
                selectedRoomId={selected} onSelectRoom={setSelected} />
              <div className="flex flex-wrap items-center justify-between gap-3 mt-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Switch id="vastu-overlay" checked={showVastu} onCheckedChange={setShowVastu} disabled={!vastu.enabled} />
                    <Label htmlFor="vastu-overlay" className="text-xs flex items-center gap-1">
                      <Compass className="w-3.5 h-3.5" /> Vastu zones
                    </Label>
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={() => { regenerate(); setActiveFloor(0); setSelected(null); }} className="gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5" /> Regenerate layout
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Room Legend</CardTitle>
            </CardHeader>
            <CardContent>
              <RoomLegend />
            </CardContent>
          </Card>
        </div>

        {/* Side panel */}
        <div className="space-y-4">
          {selectedRoom ? (
            <Card className="border-primary/40">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">{selectedRoom.label}</CardTitle>
                <CardDescription className="capitalize">{selectedRoom.type} · Floor {selectedRoom.floor + 1}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="grid grid-cols-2 gap-3">
                  <Metric label="Width" value={`${selectedRoom.w.toFixed(1)} ${plot.unit}`} />
                  <Metric label="Depth" value={`${selectedRoom.d.toFixed(1)} ${plot.unit}`} />
                  <Metric label="Area" value={`${roomArea(selectedRoom).toLocaleString()} sq ${plot.unit}`} />
                  <Metric label="Vastu zone" value={selectedRoom.vastu ?? "—"} />
                </div>
                <div className="rounded-md bg-muted/50 p-3 text-xs text-muted-foreground space-y-1">
                  <p className="flex items-center gap-1.5"><Info className="w-3 h-3" /> Door clearance & ventilation checked during layout.</p>
                  <p className="flex items-center gap-1.5"><Layers className="w-3 h-3" /> Slab thickness ≈ 125 mm (preliminary).</p>
                </div>
                <Button variant="outline" size="sm" className="w-full" onClick={() => setSelected(null)}>Deselect room</Button>
              </CardContent>
            </Card>
          ) : (
            <Card className="border-border/60">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Select a room</CardTitle>
                <CardDescription>Click any room on the plan to inspect its dimensions, doors, windows & finishes.</CardDescription>
              </CardHeader>
              <CardContent className="text-xs text-muted-foreground">
                The same geometry drives the 3D model — edits stay consistent between 2D and 3D.
              </CardContent>
            </Card>
          )}

          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Layout Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2.5 text-sm">
              <Row label="Rooms on floor" value={`${roomsOnFloor.length}`} />
              <Row label="Total rooms" value={`${floorPlan.rooms.length}`} />
              <Row label="Built area" value={`${Math.round(totalBuilt).toLocaleString()} sq ${plot.unit}`} />
              <Row label="Plot area" value={`${Math.round(plot.plotArea).toLocaleString()} sq ${plot.unit}`} />
              <Row label="Efficiency" value={`${Math.round((totalBuilt / plot.plotArea) * 100)}%`} />
              <Row label="Style" value={design.style} className="capitalize" />
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-1.5"><Info className="w-3.5 h-3.5 text-primary" /> Validation Notes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-1.5">
              {floorPlan.notes.map((n, i) => (
                <p key={i} className="text-xs text-muted-foreground flex gap-1.5">
                  <span className="text-primary">•</span> {n}
                </p>
              ))}
            </CardContent>
          </Card>

          <Button className="w-full gap-1.5" onClick={() => setView("viewer3d")}>
            <Box className="w-4 h-4" /> Open 3D viewer <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-muted/40 p-2.5">
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="font-medium text-sm">{value}</p>
    </div>
  );
}

function Row({ label, value, className }: { label: string; value: string; className?: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className={`font-medium ${className ?? ""}`}>{value}</span>
    </div>
  );
}
