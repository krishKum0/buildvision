"use client";

import { useEffect } from "react";
import { useAppStore } from "@/lib/store";
import { Sidebar } from "./sidebar";
import { Topbar } from "./topbar";
import { Footer } from "./footer";
import { MobileNav } from "./mobile-nav";
import { DashboardView } from "./views/dashboard-view";
import { PlotInputView } from "./views/plot-input-view";
import { DesignGeneratorView } from "./views/design-generator-view";
import { FloorplanView } from "./views/floorplan-view";
import { Viewer3dView } from "./views/viewer3d-view";
import { VastuView } from "./views/vastu-view";
import { MaterialsView } from "./views/materials-view";
import { SoilView } from "./views/soil-view";
import { StructureView } from "./views/structure-view";
import { CostView } from "./views/cost-view";
import { HistoryView } from "./views/history-view";
import { ExportsView } from "./views/exports-view";

export function AppShell() {
  const view = useAppStore((s) => s.view);
  const setProjects = useAppStore((s) => s.setProjects);
  const user = useAppStore((s) => s.user);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/projects", { cache: "no-store" });
        const data = await res.json();
        if (data.projects) setProjects(data.projects);
      } catch {
        /* ignore */
      }
    })();
  }, [setProjects, user?.id]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <div className="flex-1 flex w-full">
        <Sidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <Topbar />
          <main className="flex-1 overflow-y-auto bv-scroll">
            {(view === "dashboard" || view === "login") && <DashboardView />}
            {view === "plot" && <PlotInputView />}
            {view === "design" && <DesignGeneratorView />}
            {view === "floorplan" && <FloorplanView />}
            {view === "viewer3d" && <Viewer3dView />}
            {view === "vastu" && <VastuView />}
            {view === "materials" && <MaterialsView />}
            {view === "soil" && <SoilView />}
            {view === "structure" && <StructureView />}
            {view === "cost" && <CostView />}
            {view === "history" && <HistoryView />}
            {view === "exports" && <ExportsView />}
          </main>
        </div>
      </div>
      <Footer />
    </div>
  );
}
