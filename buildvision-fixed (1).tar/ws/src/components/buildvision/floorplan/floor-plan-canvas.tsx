"use client";

import { useMemo, useState } from "react";
import type { FloorPlanResult, Room, RoomType, VastuConfig } from "@/lib/types";
import { buildVastuZones, VASTU_RULES, roomArea } from "@/lib/geometry";
import { cn } from "@/lib/utils";

const ROOM_COLORS: Record<RoomType, string> = {
  master: "oklch(0.62 0.13 45 / 0.85)",
  bedroom: "oklch(0.7 0.1 60 / 0.8)",
  living: "oklch(0.65 0.09 150 / 0.7)",
  dining: "oklch(0.7 0.08 95 / 0.75)",
  kitchen: "oklch(0.6 0.13 30 / 0.85)",
  bath: "oklch(0.55 0.06 230 / 0.7)",
  pooja: "oklch(0.75 0.16 70 / 0.9)",
  study: "oklch(0.6 0.05 250 / 0.65)",
  guest: "oklch(0.65 0.07 320 / 0.6)",
  balcony: "oklch(0.7 0.08 140 / 0.5)",
  utility: "oklch(0.5 0.03 250 / 0.5)",
  storage: "oklch(0.45 0.02 50 / 0.5)",
  staircase: "oklch(0.4 0.01 50 / 0.6)",
  parking: "oklch(0.45 0.04 250 / 0.4)",
  garden: "oklch(0.6 0.1 140 / 0.55)",
  terrace: "oklch(0.6 0.05 200 / 0.35)",
};

const ROOM_LABELS: Record<RoomType, string> = {
  master: "Master BR", bedroom: "Bedroom", living: "Living", dining: "Dining",
  kitchen: "Kitchen", bath: "Bath", pooja: "Pooja", study: "Study",
  guest: "Guest", balcony: "Balcony", utility: "Utility", storage: "Storage",
  staircase: "Stairs", parking: "Parking", garden: "Garden", terrace: "Terrace",
};

interface Props {
  floorPlan: FloorPlanResult;
  vastu?: VastuConfig;
  activeFloor: number;
  selectedRoomId?: string | null;
  onSelectRoom?: (id: string | null) => void;
  showVastu?: boolean;
  className?: string;
}

export function FloorPlanCanvas({
  floorPlan, vastu, activeFloor, selectedRoomId, onSelectRoom, showVastu, className,
}: Props) {
  const [hover, setHover] = useState<string | null>(null);

  const { width, depth, ox, oy, scale, rooms, zones } = useMemo(() => {
    const fp = floorPlan;
    const pad = 44;
    const vw = 760;
    const vh = 560;
    const sc = Math.min((vw - pad * 2) / fp.plotW, (vh - pad * 2) / fp.plotD);
    const OX = (vw - fp.plotW * sc) / 2;
    const OY = (vh - fp.plotD * sc) / 2;
    const rs = fp.rooms.filter((r) => r.floor === activeFloor);
    const zs = vastu?.enabled
      ? buildVastuZones({
          length: fp.plotD, width: fp.plotW, shape: "rectangle", unit: fp.unit,
          setbackFront: 0, setbackRear: 0, setbackSides: 0,
        } as any)
      : [];
    return { width: vw, depth: vh, ox: OX, oy: OY, scale: sc, rooms: rs, zones: zs };
  }, [floorPlan, activeFloor, vastu]);

  function rx(r: Room) { return ox + r.x * scale; }
  function ry(r: Room) { return oy + r.z * scale; }
  function rw(r: Room) { return r.w * scale; }
  function rh(r: Room) { return r.d * scale; }

  return (
    <svg viewBox={`0 0 ${width} ${depth}`} className={cn("w-full h-auto bv-blueprint-grid rounded-lg border border-border/60", className)}>
      {/* Vastu zones */}
      {showVastu && zones.map((z) => {
        const rule = VASTU_RULES[z.zone];
        if (!rule) return null;
        return (
          <g key={z.zone} opacity={0.18}>
            <rect x={ox + z.x * scale} y={oy + z.z * scale} width={z.w * scale} height={z.d * scale}
              fill={zoneColor(z.zone)} stroke="none" />
            <text x={ox + (z.x + z.w / 2) * scale} y={oy + (z.z + z.d / 2) * scale}
              textAnchor="middle" dominantBaseline="middle"
              className="fill-foreground" style={{ fontSize: 10, fontWeight: 700, opacity: 0.5 }}>
              {z.zone}
            </text>
          </g>
        );
      })}

      {/* plot boundary */}
      <rect x={ox} y={oy} width={floorPlan.plotW * scale} height={floorPlan.plotD * scale}
        fill="none" stroke="oklch(0.35 0.02 50)" strokeWidth={2.5} />

      {/* setbacks label */}
      <text x={ox + (floorPlan.plotW * scale) / 2} y={oy - 10} textAnchor="middle"
        className="fill-muted-foreground" style={{ fontSize: 10, fontWeight: 600 }}>
        ROAD — front setback {floorPlan.setbacks.front}{floorPlan.unit}
      </text>

      {/* rooms */}
      {rooms.map((r) => {
        const isSel = selectedRoomId === r.id;
        const isHover = hover === r.id;
        const color = ROOM_COLORS[r.type] ?? "oklch(0.7 0.02 50)";
        return (
          <g key={r.id} onMouseEnter={() => setHover(r.id)} onMouseLeave={() => setHover(null)}
            onClick={() => onSelectRoom?.(isSel ? null : r.id)} style={{ cursor: "pointer" }}>
            <rect x={rx(r)} y={ry(r)} width={rw(r)} height={rh(r)}
              fill={color} stroke={isSel ? "oklch(0.3 0.05 30)" : "oklch(0.35 0.04 40)"}
              strokeWidth={isSel ? 2.5 : 1.2} rx={1} />
            {isHover && (
              <rect x={rx(r)} y={ry(r)} width={rw(r)} height={rh(r)}
                fill="oklch(0 0 0 / 0.06)" stroke="none" pointerEvents="none" />
            )}
            {/* door swing on a wall (decorative, on the room facing corridor) */}
            {r.type !== "garden" && r.type !== "parking" && r.type !== "terrace" && (
              <path d={`M ${rx(r) + 4} ${ry(r) + rh(r) - 4} m 0 0 a 6 6 0 0 1 6 6`} fill="none"
                stroke="oklch(0.3 0.04 40)" strokeWidth={1} />
            )}
            {/* windows (small marks on outer walls) */}
            {r.type !== "staircase" && r.type !== "utility" && r.type !== "storage" && (
              <line x1={rx(r) + rw(r) * 0.3} y1={ry(r)} x2={rx(r) + rw(r) * 0.7} y2={ry(r)}
                stroke="white" strokeWidth={2.5} opacity={0.9} />
            )}
            <text x={rx(r) + rw(r) / 2} y={ry(r) + rh(r) / 2 - 4} textAnchor="middle"
              dominantBaseline="middle" className="fill-foreground"
              style={{ fontSize: Math.min(11, rw(r) / 6), fontWeight: 600 }}>
              {ROOM_LABELS[r.type]}
            </text>
            <text x={rx(r) + rw(r) / 2} y={ry(r) + rh(r) / 2 + 8} textAnchor="middle"
              dominantBaseline="middle" className="fill-foreground/70"
              style={{ fontSize: 9 }}>
              {r.w.toFixed(0)}×{r.d.toFixed(0)} {floorPlan.unit}
            </text>
            {r.vastu && showVastu && (
              <text x={rx(r) + 4} y={ry(r) + 11} className="fill-foreground/60"
                style={{ fontSize: 8, fontWeight: 700 }}>{r.vastu}</text>
            )}
          </g>
        );
      })}

      {/* dimensions */}
      <text x={ox + (floorPlan.plotW * scale) / 2} y={oy + floorPlan.plotD * scale + 22}
        textAnchor="middle" className="fill-foreground" style={{ fontSize: 11, fontWeight: 600 }}>
        {floorPlan.plotW} {floorPlan.unit} wide
      </text>
      <text x={ox - 16} y={oy + (floorPlan.plotD * scale) / 2} textAnchor="middle"
        transform={`rotate(-90 ${ox - 16} ${oy + (floorPlan.plotD * scale) / 2})`}
        className="fill-foreground" style={{ fontSize: 11, fontWeight: 600 }}>
        {floorPlan.plotD} {floorPlan.unit} deep
      </text>

      {/* scale */}
      <g transform={`translate(${width - 90} ${depth - 22})`}>
        <line x1={0} y1={0} x2={60} y2={0} stroke="oklch(0.35 0.02 50)" strokeWidth={2} />
        <line x1={0} y1={-3} x2={0} y2={3} stroke="oklch(0.35 0.02 50)" strokeWidth={2} />
        <line x1={60} y1={-3} x2={60} y2={3} stroke="oklch(0.35 0.02 50)" strokeWidth={2} />
        <text x={30} y={-6} textAnchor="middle" className="fill-foreground" style={{ fontSize: 9 }}>
          {(60 / scale).toFixed(0)} {floorPlan.unit}
        </text>
      </g>
    </svg>
  );
}

function zoneColor(zone: string) {
  const map: Record<string, string> = {
    NE: "oklch(0.75 0.16 70)", N: "oklch(0.6 0.05 230)",
    E: "oklch(0.6 0.09 150)", SE: "oklch(0.6 0.13 30)",
    S: "oklch(0.6 0.1 20)", SW: "oklch(0.5 0.05 50)",
    W: "oklch(0.5 0.06 260)", NW: "oklch(0.55 0.08 200)",
  };
  return map[zone] ?? "oklch(0.7 0.02 50)";
}

export function RoomLegend() {
  return (
    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 text-xs">
      {Object.entries(ROOM_COLORS).map(([k, v]) => (
        <div key={k} className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-sm" style={{ background: v }} />
          <span className="text-muted-foreground">{ROOM_LABELS[k as RoomType]}</span>
        </div>
      ))}
    </div>
  );
}

export { ROOM_LABELS, roomArea };
