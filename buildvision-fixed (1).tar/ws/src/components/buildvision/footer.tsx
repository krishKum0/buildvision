"use client";

import { ShieldCheck, HardHat, Compass } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-auto border-t border-border/60 bg-sidebar/60">
      <div className="px-4 sm:px-6 py-3 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
        <div className="flex items-center gap-2">
          <Compass className="w-3.5 h-3.5 text-primary" />
          <span>AI BuildVision 360° — Generative architecture & preliminary planning</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-primary" />
            AI-generated concepts require professional verification
          </span>
          <span className="flex items-center gap-1.5">
            <HardHat className="w-3.5 h-3.5 text-primary" />
            Final designs must be approved by a qualified engineer
          </span>
        </div>
      </div>
    </footer>
  );
}
