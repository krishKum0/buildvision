"use client";

import { useEffect } from "react";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error(error); }, [error]);
  return (
    <div className="min-h-screen grid place-items-center bg-background p-6">
      <div className="max-w-md text-center space-y-4">
        <h1 className="text-2xl font-semibold">Something went wrong</h1>
        <p className="text-sm text-muted-foreground">
          The page hit an unexpected error. Your saved projects are safe — try again or reload.
        </p>
        <div className="flex justify-center gap-2">
          <button onClick={() => reset()} className="px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm">Try again</button>
          <button onClick={() => window.location.reload()} className="px-4 py-2 rounded-md border text-sm">Reload</button>
        </div>
      </div>
    </div>
  );
}
