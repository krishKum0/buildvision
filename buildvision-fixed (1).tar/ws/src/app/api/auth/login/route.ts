import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { setSessionCookie, verifyPassword } from "@/lib/auth";

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

// Simple in-memory brute-force guard: 8 failed attempts / 10 min per IP+email.
const attempts = new Map<string, { n: number; t: number }>();
const WINDOW = 10 * 60 * 1000;
const MAX_FAILS = 8;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid input" }, { status: 400 });
    }
    const { email, password } = parsed.data;
    const key = `${req.headers.get("x-forwarded-for") ?? "local"}|${email.toLowerCase()}`;
    const rec = attempts.get(key);
    if (rec && Date.now() - rec.t < WINDOW && rec.n >= MAX_FAILS) {
      return NextResponse.json({ error: "Too many attempts. Try again in a few minutes." }, { status: 429 });
    }
    const user = await db.user.findUnique({ where: { email: email.toLowerCase() } });
    if (!user || !verifyPassword(password, user.passwordHash)) {
      const r = attempts.get(key);
      attempts.set(key, r && Date.now() - r.t < WINDOW ? { n: r.n + 1, t: r.t } : { n: 1, t: Date.now() });
      return NextResponse.json({ error: "Invalid email or password" }, { status: 401 });
    }
    attempts.delete(key);
    await setSessionCookie(user.id);
    return NextResponse.json({
      user: { id: user.id, email: user.email, name: user.name, role: user.role },
    });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? "Server error" }, { status: 500 });
  }
}
