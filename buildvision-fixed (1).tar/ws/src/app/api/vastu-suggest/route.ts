import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { VASTU_RULES } from "@/lib/geometry";
import type { RoomType, RoadDirection } from "@/lib/types";

const ROAD_LABEL: Record<RoadDirection, string> = {
  N: "North", NE: "North-East", E: "East", SE: "South-East",
  S: "South", SW: "South-West", W: "West", NW: "North-West",
};

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const road: RoadDirection = body.roadDirection ?? "N";
  const requested: RoomType[] = body.rooms ?? ["master", "kitchen", "pooja", "living", "guest", "study", "bedroom", "utility"];
  const suggestions = Object.entries(VASTU_RULES)
    .filter(([, v]) => requested.includes(v.room))
    .map(([zone, v]) => ({ zone, direction: v.direction, room: v.room, note: v.note }));
  return NextResponse.json({
    roadDirection: road,
    roadLabel: ROAD_LABEL[road],
    suggestions,
    disclaimer:
      "Vastu guidance is optional and configurable. It must not override structural safety, ventilation, accessibility, fire safety, or applicable building regulations.",
  });
}
