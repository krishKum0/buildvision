import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import type { SoilLayer } from "@/lib/types";

// Preliminary foundation recommendation from soil-bearing capacity.
// NOTE: the website must NOT guess soil type or bearing capacity from an address.
export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const layers: SoilLayer[] = Array.isArray(body.layers) ? body.layers : [];
  const bearing = Number(body.bearingCapacityKPa ?? 0);
  const water = Number(body.waterTableDepth ?? 0);

  let foundationType = "Isolated footings";
  let note = "";
  if (bearing <= 0) {
    foundationType = "Requires geotechnical investigation";
    note = "Bearing capacity not provided. Do not assume soil type or bearing capacity from plot address.";
  } else if (bearing < 100) {
    foundationType = "Raft foundation";
    note = "Very low bearing capacity — a raft or piled foundation is likely; engineer must confirm.";
  } else if (bearing < 150) {
    foundationType = "Combined / Strip footings";
    note = "Low bearing capacity — combined or strip footings may be suitable; engineer to size.";
  } else if (bearing < 250) {
    foundationType = "Isolated footings";
    note = "Medium bearing capacity — isolated footings typical; verify settlement.";
  } else {
    foundationType = "Isolated footings (shallow)";
    note = "Good bearing capacity — shallow isolated footings likely adequate; engineer to confirm.";
  }
  if (water > 0 && water < 2) {
    note += " Shallow water table — consider waterproofing & dewatering during construction.";
  }
  if (layers.length === 0) {
    note += " No soil layers entered — request a geotechnical report before finalising foundations.";
  }
  return NextResponse.json({
    foundationType,
    note,
    layers,
    bearingCapacityKPa: bearing,
    waterTableDepth: water,
    disclaimer:
      "Preliminary foundation guidance for professional evaluation only. Final foundation type, sizing & reinforcement must be approved by a qualified structural / geotechnical engineer.",
  });
}
