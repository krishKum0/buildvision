import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { generateFloorPlan, generateStructure, computePlotArea, computeBuildableArea, defaultRoomSpecs } from "@/lib/geometry";
import type { PlotConfig, DesignConfig, VastuConfig, MaterialsConfig, SoilReport, StructureConfig } from "@/lib/types";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const projects = await db.project.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: "desc" },
  });
  const parsed = projects.map((p) => ({
    ...p,
    plot: JSON.parse(p.plot),
    design: JSON.parse(p.design),
    floorPlan: JSON.parse(p.floorPlan),
    vastu: JSON.parse(p.vastu),
    materials: JSON.parse(p.materials),
    soil: JSON.parse(p.soil),
    structure: JSON.parse(p.structure),
  }));
  return NextResponse.json({ projects: parsed });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const name: string = body.name ?? "Untitled Project";
  const plot: PlotConfig = body.plot;
  const design: DesignConfig = body.design ?? {
    style: "modern", roof: "flat", palette: "warm-wood",
    rooms: defaultRoomSpecs(), designSeed: Math.floor(Math.random() * 9999),
  };
  const vastu: VastuConfig = body.vastu ?? { enabled: true, rotation: 0, suggestions: [] };
  const materials: MaterialsConfig = body.materials;
  const soil: SoilReport = body.soil;
  const structure: StructureConfig = body.structure ?? { columns: [], beams: [], slabThicknessMm: 125, notes: "" };

  // server-side recompute of plot + floor plan ensures consistency
  plot.plotArea = computePlotArea(plot);
  plot.buildableArea = computeBuildableArea(plot);
  const floorPlan = generateFloorPlan(plot, design, vastu);
  const recomputedStruct = generateStructure(plot, floorPlan);

  const project = await db.project.create({
    data: {
      userId: user.id,
      name,
      plot: JSON.stringify(plot),
      design: JSON.stringify(design),
      floorPlan: JSON.stringify(floorPlan),
      vastu: JSON.stringify(vastu),
      materials: JSON.stringify(materials),
      soil: JSON.stringify(soil),
      structure: JSON.stringify(recomputedStruct),
      status: "generated",
      conceptImg: body.conceptImg ?? null,
    },
  });

  // snapshot version 1
  await db.projectVersion.create({
    data: {
      projectId: project.id,
      version: 1,
      note: "Initial generated design",
      snapshot: JSON.stringify({
        name, plot, design, floorPlan, vastu, materials, soil, structure: recomputedStruct,
      }),
    },
  });

  return NextResponse.json({
    project: {
      ...project,
      plot, design, floorPlan, vastu, materials, soil, structure: recomputedStruct,
    },
  });
}
