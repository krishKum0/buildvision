import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { generateFloorPlan, generateStructure, computePlotArea, computeBuildableArea } from "@/lib/geometry";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const p = await db.project.findUnique({ where: { id } });
  if (!p || p.userId !== user.id) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const versions = await db.projectVersion.findMany({
    where: { projectId: id }, orderBy: { version: "asc" },
  });
  return NextResponse.json({
    project: {
      ...p,
      plot: JSON.parse(p.plot),
      design: JSON.parse(p.design),
      floorPlan: JSON.parse(p.floorPlan),
      vastu: JSON.parse(p.vastu),
      materials: JSON.parse(p.materials),
      soil: JSON.parse(p.soil),
      structure: JSON.parse(p.structure),
    },
    versions: versions.map((v) => ({ id: v.id, version: v.version, note: v.note, createdAt: v.createdAt, snapshot: v.snapshot })),
  });
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const p = await db.project.findUnique({ where: { id } });
  if (!p || p.userId !== user.id) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const body = await req.json();
  const plot = body.plot ?? JSON.parse(p.plot);
  const design = body.design ?? JSON.parse(p.design);
  const vastu = body.vastu ?? JSON.parse(p.vastu);
  const materials = body.materials ?? JSON.parse(p.materials);
  const soil = body.soil ?? JSON.parse(p.soil);

  plot.plotArea = computePlotArea(plot);
  plot.buildableArea = computeBuildableArea(plot);
  const floorPlan = generateFloorPlan(plot, design, vastu);
  const structure = generateStructure(plot, floorPlan);

  const updated = await db.project.update({
    where: { id },
    data: {
      name: body.name ?? p.name,
      plot: JSON.stringify(plot),
      design: JSON.stringify(design),
      floorPlan: JSON.stringify(floorPlan),
      vastu: JSON.stringify(vastu),
      materials: JSON.stringify(materials),
      soil: JSON.stringify(soil),
      structure: JSON.stringify(structure),
      status: body.status ?? p.status,
      conceptImg: body.conceptImg ?? p.conceptImg,
    },
  });

  // create a new version snapshot
  const last = await db.projectVersion.findFirst({
    where: { projectId: id }, orderBy: { version: "desc" },
  });
  const v = (last?.version ?? 0) + 1;
  await db.projectVersion.create({
    data: {
      projectId: id, version: v,
      note: body.versionNote ?? `Revision ${v}`,
      snapshot: JSON.stringify({
        name: body.name ?? p.name, plot, design, floorPlan, vastu, materials, soil, structure,
      }),
    },
  });

  return NextResponse.json({
    project: {
      ...updated,
      plot, design, floorPlan, vastu, materials, soil, structure,
    },
  });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const p = await db.project.findUnique({ where: { id } });
  if (!p || p.userId !== user.id) return NextResponse.json({ error: "Not found" }, { status: 404 });
  await db.project.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
