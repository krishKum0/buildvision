import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AI BuildVision 360° — Generative 3D House Design & Construction Planning",
  description:
    "AI-powered architectural design platform that turns plot dimensions into editable 2D floor plans, interactive 360° 3D building models, Vastu-aware zoning, material libraries, soil data and preliminary structural planning.",
  keywords: ["AI architecture", "3D house design", "floor plan generator", "Vastu planning", "construction planning", "plot design", "structural engineering"],
  authors: [{ name: "AI BuildVision 360°" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "AI BuildVision 360°",
    description: "Generative AI-based 3D house design and construction planning.",
    siteName: "AI BuildVision 360°",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "AI BuildVision 360°",
    description: "Generative AI-based 3D house design and construction planning.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
