"use client";

import { useEffect } from "react";
import { useAppStore } from "@/lib/store";
import { LoginView } from "@/components/buildvision/views/login-view";
import { AppShell } from "@/components/buildvision/app-shell";

export default function Home() {
  const user = useAppStore((s) => s.user);
  const authLoading = useAppStore((s) => s.authLoading);
  const setUser = useAppStore((s) => s.setUser);
  const setAuthLoading = useAppStore((s) => s.setAuthLoading);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setAuthLoading(true);
      try {
        const res = await fetch("/api/auth/me", { cache: "no-store" });
        const data = await res.json();
        if (!cancelled) {
          setUser(data.user ?? null);
          if (data.user) useAppStore.getState().setView("dashboard");
        }
      } catch {
        if (!cancelled) setUser(null);
      } finally {
        if (!cancelled) setAuthLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [setUser, setAuthLoading]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-full border-4 border-muted border-t-primary animate-spin" />
          <p className="text-sm text-muted-foreground">Loading BuildVision 360°…</p>
        </div>
      </div>
    );
  }

  if (!user) return <LoginView />;
  return <AppShell />;
}
