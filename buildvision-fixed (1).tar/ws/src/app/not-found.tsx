import Link from "next/link";

export default function NotFound() {
  return (
    <div className="min-h-screen grid place-items-center bg-background p-6">
      <div className="text-center space-y-3">
        <p className="text-5xl font-semibold text-primary">404</p>
        <p className="text-sm text-muted-foreground">That page doesn’t exist.</p>
        <Link href="/" className="inline-block px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm">Back to BuildVision 360°</Link>
      </div>
    </div>
  );
}
